package net.mrwqlf.tagsistemi;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.ShulkerBox;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * TagSistemi: rutbe (tag), kit, yan tabela ve sohbet duzeni.
 * Para/AH/coin islerinden bagimsizdir; MarketAH yukluyse tabelada bakiyeyi gosterir,
 * MarketAH de AH ilan limitini buradan okur.
 */
public final class TagSistemi extends JavaPlugin implements Listener {

    private static final String ADMIN = "tagsistemi.admin";

    private Tabela tabela;
    private Kitler kitler;
    private NamespacedKey cubukAnahtar;

    // ------------------------------------------------------------------ yasam dongusu

    @Override
    public void onEnable() {
        eskiVeriyiTasi();
        saveDefaultConfig();
        cubukAnahtar = new NamespacedKey(this, "kit_cubugu");
        tabela = new Tabela(this);
        kitler = new Kitler(this);
        Bukkit.getPluginManager().registerEvents(this, this);

        int hiz = Math.max(10, getConfig().getInt("tabela.guncelleme", 20));
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) tabela.goster(p);
        }, 40L, hiz);

        // Suresi dolan rutbeleri dakikada bir temizle
        Bukkit.getScheduler().runTaskTimer(this, this::sureKontrol, 1200L, 1200L);
        // Otomatik kayit (5 dakikada bir)
        Bukkit.getScheduler().runTaskTimer(this, this::kaydet, 6000L, 6000L);

        getLogger().info("TagSistemi aktif. Rütbe sayısı: " + tabela.taglar().size());
    }

    @Override
    public void onDisable() {
        if (tabela != null) {
            for (Player p : Bukkit.getOnlinePlayers()) tabela.kaldir(p);
            tabela.kaydet();
        }
        if (kitler != null) kitler.kaydet();
    }

    private void kaydet() {
        tabela.kaydet();
        kitler.kaydet();
    }

    private void sureKontrol() {
        List<UUID> dolanlar = tabela.suresiDolanlariTemizle();
        if (dolanlar.isEmpty()) return;
        tabela.kaydet();
        for (UUID u : dolanlar) {
            Player p = Bukkit.getPlayer(u);
            if (p == null) continue;
            msj(p, "&eRütbenin süresi doldu.");
            tabela.kaldir(p);
            tabela.goster(p);
        }
    }

    // ------------------------------------------------------------------ MarketAH koprusu

    /**
     * MarketAH yukluyse oyuncunun bakiyesini biçimli metin olarak doner, yoksa null.
     * Iki eklenti birbirine derleme zamaninda bagli degildir (yansima ile okunur).
     */
    public String paraMetni(UUID uuid) {
        Plugin m = Bukkit.getPluginManager().getPlugin("MarketAH");
        if (m == null || !m.isEnabled()) return null;
        try {
            Object bakiye = m.getClass().getMethod("bakiye", UUID.class).invoke(m, uuid);
            Object metin = m.getClass().getMethod("bicim", double.class).invoke(m, (Double) bakiye);
            return metin == null ? null : metin.toString();
        } catch (ReflectiveOperationException | ClassCastException ex) {
            return null;
        }
    }

    /** GorevPass'ten oyuncunun pass seviyesini "3/20" biciminde okur; eklenti yoksa null. */
    public String passMetni(UUID uuid) {
        Plugin g = Bukkit.getPluginManager().getPlugin("GorevPass");
        if (g == null || !g.isEnabled()) return null;
        try {
            Object sev = g.getClass().getMethod("passSeviye", UUID.class).invoke(g, uuid);
            Object max = g.getClass().getMethod("passMaxFor", UUID.class).invoke(g, uuid);
            String metin = sev + "/" + max;
            try {
                Object prem = g.getClass().getMethod("passPremium", UUID.class).invoke(g, uuid);
                if (Boolean.TRUE.equals(prem)) metin += " &6★";
            } catch (ReflectiveOperationException ignored) {
            }
            return metin;
        } catch (ReflectiveOperationException ex) {
            return null;
        }
    }

    /**
     * MarketAH'in yansima ile cagirdigi deger: oyuncunun rutbesine bagli AH ilan limiti.
     * -1 = rutbe/limit yok, Integer.MAX_VALUE = sinirsiz (yetkili). Adini/imzasini degistirme.
     */
    public int ahLimiti(UUID uuid) {
        return tabela.ahLimiti(uuid);
    }

    // ------------------------------------------------------------------ eski veriyi tasima

    /**
     * Eklenti ayrilmadan once her sey plugins/MarketAH icindeydi.
     * Ilk acilista rutbeleri, tercihleri ve ayarlari yeni klasore kopyalar.
     */
    private void eskiVeriyiTasi() {
        File yeni = getDataFolder();
        File eski = new File(yeni.getParentFile(), "MarketAH");
        if (!eski.isDirectory()) return;
        if (!yeni.exists() && !yeni.mkdirs()) return;

        try {
            File eskiTag = new File(eski, "taglar.yml");
            File yeniTag = new File(yeni, "taglar.yml");
            if (eskiTag.exists() && !yeniTag.exists()) {
                Files.copy(eskiTag.toPath(), yeniTag.toPath(), StandardCopyOption.COPY_ATTRIBUTES);
                getLogger().info("taglar.yml MarketAH klasöründen taşındı.");
            }

            File eskiHasar = new File(eski, "hasar.yml");
            File yeniTercih = new File(yeni, "tercihler.yml");
            if (eskiHasar.exists() && !yeniTercih.exists()) {
                FileConfiguration h = YamlConfiguration.loadConfiguration(eskiHasar);
                FileConfiguration t = new YamlConfiguration();
                t.set("kapali", h.getStringList("kapali"));
                t.save(yeniTercih);
            }

            File eskiCfg = new File(eski, "config.yml");
            File yeniCfg = new File(yeni, "config.yml");
            if (eskiCfg.exists() && !yeniCfg.exists()) {
                saveDefaultConfig();
                FileConfiguration e = YamlConfiguration.loadConfiguration(eskiCfg);
                FileConfiguration y = YamlConfiguration.loadConfiguration(yeniCfg);
                for (String anahtar : e.getKeys(true)) {
                    boolean bizim = anahtar.startsWith("tabela.") || anahtar.startsWith("bayrak-")
                            || anahtar.startsWith("sohbet-") || anahtar.equals("rank-sohbette")
                            || anahtar.equals("rank-isim-oneki");
                    if (bizim && !e.isConfigurationSection(anahtar)) y.set(anahtar, e.get(anahtar));
                }
                y.save(yeniCfg);
                reloadConfig();
                getLogger().info("Tabela/sohbet ayarları MarketAH config'inden taşındı.");
            }
        } catch (IOException ex) {
            getLogger().warning("Eski veri taşınamadı: " + ex.getMessage());
        }
    }

    // ------------------------------------------------------------------ yardimcilar

    private static Component c(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s)
                .decoration(TextDecoration.ITALIC, false);
    }

    private void msj(CommandSender s, String metin) {
        s.sendMessage(c("&8[&6Rütbe&8] &r" + metin));
    }

    private void tabelayiYenile() {
        for (Player pl : Bukkit.getOnlinePlayers()) {
            tabela.kaldir(pl);
            tabela.goster(pl);
        }
    }

    /** 90061000 ms -> "1g 1s 1dk" */
    static String sure(long ms) {
        long g = ms / 86_400_000L;
        long s = (ms % 86_400_000L) / 3_600_000L;
        long dk = (ms % 3_600_000L) / 60_000L;
        if (g > 0) return g + "g " + s + "s " + dk + "dk";
        if (s > 0) return s + "s " + dk + "dk";
        return Math.max(1, dk) + "dk";
    }

    private long kitBeklemeMs() {
        return Math.max(1, getConfig().getInt("kit-bekleme-saat", 72)) * 3_600_000L;
    }

    private int varsayilanGun() {
        return Math.max(1, getConfig().getInt("rank-suresi-gun", 30));
    }

    /** Tag adi YAML anahtari oldugu icin sadece kucuk harf, rakam ve alt cizgi. */
    private static boolean gecerliAd(String ad) {
        return ad.matches("[a-z0-9_]{1,16}");
    }

    private static boolean ayrilmisAd(String ad) {
        return ad.equals("liste") || ad.equals("sil") || ad.equals("list") || ad.equals("delete");
    }

    private static int sayiOku(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (NumberFormatException e) {
            return Integer.MIN_VALUE;
        }
    }

    // ------------------------------------------------------------------ sohbet / giris

    @EventHandler
    public void onChat(AsyncChatEvent e) {
        if (!getConfig().getBoolean("rank-sohbette", true)) return;
        // sohbette de ayni duzen: [Bayrak] Tag Isim
        Component isim = tabela.bayrakliIsim(e.getPlayer());
        String ayirici = getConfig().getString("sohbet-ayirici", "&7: ");
        String mesajRengi = getConfig().getString("sohbet-mesaj-rengi", "&f");
        Component ayr = LegacyComponentSerializer.legacyAmpersand().deserialize(ayirici);
        // once rutbenin mesaj rengi, yoksa config'teki varsayilan
        var rutbeRengi = tabela.mesajRengi(e.getPlayer().getUniqueId());
        var renk = rutbeRengi != null
                ? rutbeRengi
                : LegacyComponentSerializer.legacyAmpersand().deserialize(mesajRengi + "x").color();

        e.renderer((source, sourceDisplayName, message, viewer) -> {
            Component govde = renk == null ? message : message.colorIfAbsent(renk);
            // kok notr: parcalar birbirinin rengini miras almaz
            return Component.empty().append(isim).append(ayr).append(govde);
        });
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Bukkit.getScheduler().runTaskLater(this, () -> tabela.goster(e.getPlayer()), 20L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        tabela.kaldir(e.getPlayer());
    }

    // ------------------------------------------------------------------ kit cubugu

    /** Cubuk yalnizca yetkililer icin calisir; baskasinin eline gecse bile hicbir sey yapmaz. */
    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (e.getHand() != EquipmentSlot.HAND) return;
        ItemStack el = e.getItem();
        if (el == null || el.getType() != Material.STICK) return;
        ItemMeta meta = el.getItemMeta();
        if (meta == null) return;
        String rutbe = meta.getPersistentDataContainer().get(cubukAnahtar, PersistentDataType.STRING);
        if (rutbe == null) return;

        e.setCancelled(true);                       // shulker acilmasin
        Player p = e.getPlayer();
        if (!p.hasPermission(ADMIN)) {
            msj(p, "&cBu çubuğu kullanma yetkin yok.");
            return;
        }
        Block blok = e.getClickedBlock();
        if (blok == null || !(blok.getState() instanceof ShulkerBox kutu)) {
            msj(p, "&cBu bir shulker kutusu değil. &7Çubukla bir shulker kutusuna sağ tıkla.");
            return;
        }
        if (!tabela.tagVar(rutbe) || Tabela.kaliciMi(rutbe)) {
            msj(p, "&cBu rütbe artık kit alamıyor: &f" + rutbe);
            return;
        }

        int adet = kitler.kaydetKit(rutbe, kutu.getInventory().getContents());
        if (adet == 0) {
            msj(p, "&cShulker kutusu boş, kit değişmedi.");
            return;
        }
        msj(p, "&a" + rutbe + " &akiti kaydedildi: &f" + adet + " &aeşya.");
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.2f);
        kitMenuAc(p, rutbe, true);
    }

    // ------------------------------------------------------------------ kit menusu

    private ItemStack buton(Material mat, String ad, String... lore) {
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        if (m != null) {
            m.displayName(c(ad));
            List<Component> l = new ArrayList<>();
            for (String s : lore) l.add(c(s));
            m.lore(l);
            it.setItemMeta(m);
        }
        return it;
    }

    private void kitMenuAc(Player p, String rutbe, boolean onizlemeZorla) {
        String k = rutbe.toLowerCase();
        boolean kendi = !onizlemeZorla && k.equals(tabela.tagAdi(p.getUniqueId()));

        KitMenu menu = new KitMenu(k, !kendi);
        Inventory inv = Bukkit.createInventory(menu, 54,
                c("&0&lKİT &8» &f" + k.toUpperCase(Locale.ROOT)));
        menu.setInventory(inv);

        List<ItemStack> esyalar = kitler.esyalar(k);
        for (int i = 0; i < esyalar.size() && i < 45; i++) inv.setItem(i, esyalar.get(i));

        ItemStack cam = buton(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 45; i < 54; i++) inv.setItem(i, cam);

        inv.setItem(45, buton(Material.BOOK, "&6" + k.toUpperCase(Locale.ROOT) + " &7kiti",
                "&7Eşya sayısı: &f" + esyalar.size(),
                "&7Bekleme: &f" + sure(kitBeklemeMs())));

        if (!kendi) {
            inv.setItem(49, buton(Material.PAPER, "&7Önizleme",
                    "&8Bu kiti sadece &f" + k.toUpperCase(Locale.ROOT) + " &8rütbesi alabilir."));
        } else {
            long kalan = kitler.kalanBekleme(p.getUniqueId(), k, kitBeklemeMs());
            if (kalan <= 0) {
                inv.setItem(49, buton(Material.EMERALD, "&a&lKİTİ AL",
                        "&7Tıkla ve kitini al.",
                        "&8Sonra &f" + sure(kitBeklemeMs()) + " &8beklersin."));
            } else {
                inv.setItem(49, buton(Material.CLOCK, "&e&lHenüz hazır değil",
                        "&7Kalan süre: &f" + sure(kalan)));
            }
        }
        p.openInventory(inv);
    }

    @EventHandler
    public void onKitDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof KitMenu) e.setCancelled(true);
    }

    @EventHandler
    public void onKitClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof KitMenu menu)) return;
        e.setCancelled(true);                                     // hicbir esya alinamaz / konamaz
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || !e.getClickedInventory().equals(e.getInventory())) return;
        if (e.getRawSlot() != 49 || menu.onizleme) return;
        kitAl(p, menu);
    }

    private void kitAl(Player p, KitMenu menu) {
        String k = menu.rutbe;
        UUID u = p.getUniqueId();

        // menu acikken rutbe bitmis ya da degismis olabilir
        if (!k.equals(tabela.tagAdi(u))) {
            msj(p, "&cBu kit artık rütbene ait değil.");
            p.closeInventory();
            return;
        }
        long kalan = kitler.kalanBekleme(u, k, kitBeklemeMs());
        if (kalan > 0) {
            msj(p, "&cKit henüz hazır değil. &7Kalan: &f" + sure(kalan));
            Bukkit.getScheduler().runTask(this, () -> kitMenuAc(p, k, false));
            return;
        }
        List<ItemStack> esyalar = kitler.esyalar(k);
        if (esyalar.isEmpty()) {
            msj(p, "&cBu rütbenin kiti henüz ayarlanmamış.");
            return;
        }

        // once zamani kaydet: hizli tiklamayla ikinci kez alinamasin
        kitler.alimKaydet(u, k, System.currentTimeMillis());
        kitler.kaydet();

        boolean yereDustu = false;
        for (ItemStack it : esyalar) {
            for (ItemStack artan : p.getInventory().addItem(it).values()) {
                Item d = p.getWorld().dropItem(p.getLocation(), artan);
                d.setOwner(u);                       // ilk dakikalarda sadece o alabilir
                yereDustu = true;
            }
        }
        msj(p, "&aKitini aldın! &7Bir sonraki: &f" + sure(kitBeklemeMs()) + " &7sonra.");
        if (yereDustu) msj(p, "&eEnvanterin dolu olduğu için bazı eşyalar yere düştü.");
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
        Bukkit.getScheduler().runTask(this, () -> kitMenuAc(p, k, false));
    }

    // ------------------------------------------------------------------ komutlar

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd,
                             @NotNull String label, @NotNull String[] args) {
        switch (cmd.getName().toLowerCase()) {
            case "tag" -> tagKomut(sender, args);
            case "rankkit" -> rankKitKomut(sender, args);
            case "rankah" -> rankAhKomut(sender, args);
            case "kit" -> kitKomut(sender, args);
            case "scoreboard" -> {
                if (!(sender instanceof Player p)) {
                    msj(sender, "&cBu komut sadece oyuncular için.");
                    return true;
                }
                boolean acik = tabela.degistir(p);
                msj(p, acik ? "&aTabela açıldı." : "&7Tabela kapatıldı.");
            }
            case "rank" -> {
                if (!(sender instanceof Player p)) {
                    msj(sender, "&cBu komut sadece oyuncular için.");
                    return true;
                }
                rankBilgi(p, args);
            }
            default -> {
                return false;
            }
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command cmd,
                                      @NotNull String alias, @NotNull String[] args) {
        if (!sender.hasPermission(ADMIN)) return List.of();
        String ad = cmd.getName().toLowerCase();
        List<String> adaylar = new ArrayList<>();
        if (ad.equals("tag")) {
            if (args.length == 1) {
                adaylar.addAll(List.of("list", "create", "delete", "give", "take", "color", "chatcolor", "reload"));
            } else if (args.length == 2 && List.of("sil", "renk", "mesajrenk", "delete", "color", "chatcolor").contains(args[0].toLowerCase())) {
                adaylar.addAll(tabela.taglar().keySet());
            } else if (args.length == 2 && List.of("ver", "al", "give", "take").contains(args[0].toLowerCase())) {
                for (Player p : Bukkit.getOnlinePlayers()) adaylar.add(p.getName());
            } else if (args.length == 3 && (args[0].equalsIgnoreCase("ver") || args[0].equalsIgnoreCase("give"))) {
                adaylar.addAll(tabela.taglar().keySet());
            }
        } else if (ad.equals("rankkit") || ad.equals("rankah") || ad.equals("kit")) {
            if (args.length == 1) {
                for (String k : tabela.taglar().keySet()) if (!Tabela.kaliciMi(k)) adaylar.add(k);
                if (ad.equals("rankkit")) adaylar.addAll(List.of("list", "delete"));
            } else if (args.length == 2 && ad.equals("rankkit") && (args[0].equalsIgnoreCase("sil") || args[0].equalsIgnoreCase("delete"))) {
                adaylar.addAll(tabela.taglar().keySet());
            }
        }
        String son = args.length == 0 ? "" : args[args.length - 1].toLowerCase();
        adaylar.removeIf(s -> !s.toLowerCase().startsWith(son));
        return adaylar;
    }

    // ---- /tag

    private void tagKomut(CommandSender sender, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("list") || args[0].equalsIgnoreCase("liste")) {
            msj(sender, "&7Tanımlı rütbeler (&f" + tabela.taglar().size() + "&7):");
            if (tabela.taglar().isEmpty()) msj(sender, "  &8(hiç rütbe yok)");
            for (var e : tabela.taglar().entrySet()) {
                String tur = e.getKey().equalsIgnoreCase("bugfounder") ? "&8(süresiz, AH: " + Tabela.BUGFOUNDER_AH + ")"
                        : Tabela.kaliciMi(e.getKey()) ? "&8(yetkili)" : "&8(süreli)";
                sender.sendMessage(c("  &8- &f" + e.getKey() + " &8-> &r" + e.getValue() + " " + tur));
            }
            if (sender.hasPermission(ADMIN)) {
                msj(sender, "&8/tag create <ad> <biçim> &7| &8/tag delete <ad>");
                msj(sender, "&8/tag give <oyuncu> <ad> [gün] &7| &8/tag take <oyuncu>");
                msj(sender, "&8/tag color <ad> <&renkkodu> &7- isim rengi");
                msj(sender, "&8/tag chatcolor <ad> <&renkkodu> &7- sohbet mesajı rengi");
                msj(sender, "&8/tag reload &7- ayarları yenile");
                msj(sender, "&8Örnek: &7/tag create vip &6&lVIP");
            }
            return;
        }
        if (!sender.hasPermission(ADMIN)) {
            msj(sender, "&cYetkin yok.");
            return;
        }

        switch (args[0].toLowerCase()) {
            case "create", "olustur", "oluştur", "ekle" -> {
                if (args.length < 3) {
                    msj(sender, "&cKullanım: /tag create <ad> <biçim>");
                    msj(sender, "&7Örnek: &f/tag create vip &6&lVIP");
                    return;
                }
                String ad = args[1].toLowerCase();
                if (!gecerliAd(ad) || ayrilmisAd(ad)) {
                    msj(sender, "&cRütbe adı sadece küçük harf, rakam ve _ içerebilir (en çok 16 karakter) "
                            + "ve &fliste&c / &fsil&c olamaz.");
                    return;
                }
                if (!tabela.tagVar(ad) && !Tabela.kaliciMi(ad)) {
                    int max = Math.max(1, getConfig().getInt("max-rank", 8));
                    if (tabela.sureliSayisi() >= max) {
                        msj(sender, "&cEn fazla &f" + max + " &csüreli rütbe olabilir. "
                                + "&7Birini silmeden yenisi eklenemez. &8(config: max-rank)");
                        return;
                    }
                }
                String bicim = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
                boolean yeni = tabela.tagOlustur(ad, bicim);
                tabela.kaydet();
                sender.sendMessage(c("&8[&6Rütbe&8] &a" + (yeni ? "Rütbe oluşturuldu" : "Rütbe güncellendi")
                        + ": &f" + ad + " &8-> &r" + bicim));
                tabelayiYenile();
            }
            case "chatcolor", "mesajrenk", "sohbetrenk" -> {
                if (args.length < 3) {
                    msj(sender, "&cKullanım: /tag chatcolor <ad> <&renkkodu>");
                    msj(sender, "&7Örnek: &f/tag chatcolor vip &e  &7(VIP'lerin mesajı sarı olur)");
                    return;
                }
                if (!tabela.tagMesajRenk(args[1], args[2])) {
                    msj(sender, "&cBöyle bir rütbe yok: &f" + args[1]);
                    return;
                }
                tabela.kaydet();
                sender.sendMessage(c("&8[&6Rütbe&8] &aMesaj rengi ayarlandı: &f"
                        + args[1].toLowerCase() + " &8-> " + args[2] + "örnek mesaj"));
            }
            case "color", "renk" -> {
                if (args.length < 3) {
                    msj(sender, "&cKullanım: /tag color <ad> <&renkkodu>");
                    msj(sender, "&7Örnek: &f/tag color vip &e  &7(isim sarı olur)");
                    return;
                }
                if (!tabela.tagRenk(args[1], args[2])) {
                    msj(sender, "&cBöyle bir rütbe yok: &f" + args[1]);
                    return;
                }
                tabela.kaydet();
                sender.sendMessage(c("&8[&6Rütbe&8] &aİsim rengi ayarlandı: &f"
                        + args[1].toLowerCase() + " &8-> " + args[2] + "örnek isim"));
                tabelayiYenile();
            }
            case "delete", "sil" -> {
                if (args.length < 2) {
                    msj(sender, "&cKullanım: /tag delete <ad>");
                    return;
                }
                int sonuc = tabela.tagSil(args[1]);
                if (sonuc == 0) {
                    kitler.kitSil(args[1]);
                    kaydet();
                    msj(sender, "&aRütbe silindi: &f" + args[1].toLowerCase()
                            + " &7(kiti ve sahipleri de temizlendi)");
                    tabelayiYenile();
                } else if (sonuc == 2) {
                    msj(sender, "&cYetkili rütbeler silinemez. &7Oyuncudan almak için: &f/tag take <oyuncu>");
                } else {
                    msj(sender, "&cBöyle bir rütbe yok.");
                }
            }
            case "give", "ver" -> {
                if (args.length < 3) {
                    msj(sender, "&cKullanım: /tag give <oyuncu> <ad> [gün]");
                    msj(sender, "&7Süreli rütbeler varsayılan &f" + varsayilanGun() + " &7gün sürer.");
                    return;
                }
                int gun = varsayilanGun();
                if (args.length > 3) {
                    gun = sayiOku(args[3]);
                    if (gun < 1 || gun > 3650) {
                        msj(sender, "&cGün 1 - 3650 arasında olmalı.");
                        return;
                    }
                }
                OfflinePlayer hedef = Bukkit.getOfflinePlayer(args[1]);
                long bitis = tabela.tagVer(hedef.getUniqueId(), args[2], gun);
                if (bitis < 0) {
                    msj(sender, "&cBöyle bir rütbe yok: &f" + args[2]);
                    return;
                }
                tabela.kaydet();
                String gorunum = tabela.taglar().get(args[2].toLowerCase());
                String sureMetni = bitis == 0 ? "&7(süresiz)" : "&7(&f" + sure(bitis - System.currentTimeMillis()) + "&7)";
                msj(sender, "&f" + args[1] + " &aartık &r" + gorunum + " " + sureMetni);
                Player hp = hedef.getPlayer();
                if (hp != null) {
                    tabela.kaldir(hp);
                    tabela.goster(hp);
                    msj(hp, "&aYeni rütben: &r" + gorunum + " " + sureMetni);
                }
            }
            case "take", "al", "sifirla" -> {
                if (args.length < 2) {
                    msj(sender, "&cKullanım: /tag take <oyuncu>");
                    return;
                }
                OfflinePlayer hedef = Bukkit.getOfflinePlayer(args[1]);
                tabela.tagAl(hedef.getUniqueId());
                tabela.kaydet();
                msj(sender, "&f" + args[1] + " &7oyuncusunun rütbesi kaldırıldı.");
                Player hp = hedef.getPlayer();
                if (hp != null) {
                    tabela.kaldir(hp);
                    tabela.goster(hp);
                }
            }
            case "reload", "yenile" -> {
                kaydet();
                reloadConfig();
                tabela.yukle();
                kitler.yukle();
                tabelayiYenile();
                msj(sender, "&aAyarlar yeniden yüklendi.");
            }
            default -> msj(sender, "&cBilinmeyen alt komut. &7/tag list");
        }
    }

    // ---- /rankkit

    private void rankKitKomut(CommandSender sender, String[] args) {
        if (!sender.hasPermission(ADMIN)) {
            msj(sender, "&cYetkin yok.");
            return;
        }
        if (args.length == 0) {
            msj(sender, "&8/rankkit <rütbe> &7- kit çubuğu verir (shulker'a sağ tıkla)");
            msj(sender, "&8/rankkit list &7- hangi rütbelerin kiti var");
            msj(sender, "&8/rankkit delete <rütbe> &7- kiti siler");
            return;
        }

        if (args[0].equalsIgnoreCase("list") || args[0].equalsIgnoreCase("liste")) {
            msj(sender, "&7Kit durumu:");
            boolean hic = true;
            for (String k : tabela.taglar().keySet()) {
                if (Tabela.kaliciMi(k)) continue;
                hic = false;
                sender.sendMessage(c("  &8- &f" + k + " &8: "
                        + (kitler.var(k) ? "&akit var &8(" + kitler.esyalar(k).size() + " eşya)" : "&7kit yok")));
            }
            if (hic) msj(sender, "  &8(süreli rütbe yok)");
            return;
        }

        if (args[0].equalsIgnoreCase("delete") || args[0].equalsIgnoreCase("sil")) {
            if (args.length < 2) {
                msj(sender, "&cKullanım: /rankkit delete <rütbe>");
                return;
            }
            if (!kitler.var(args[1])) {
                msj(sender, "&cBu rütbenin zaten kiti yok.");
                return;
            }
            kitler.kitSil(args[1]);
            kitler.kaydet();
            msj(sender, "&aKit silindi: &f" + args[1].toLowerCase());
            return;
        }

        if (!(sender instanceof Player p)) {
            msj(sender, "&cÇubuk vermek için oyunda olmalısın.");
            return;
        }
        String rutbe = args[0].toLowerCase();
        if (!tabela.tagVar(rutbe)) {
            msj(p, "&cBöyle bir rütbe yok: &f" + args[0] + " &7(/tag list)");
            return;
        }
        if (Tabela.kaliciMi(rutbe)) {
            msj(p, "&cYetkili rütbelerin kiti yoktur.");
            return;
        }

        ItemStack cubuk = new ItemStack(Material.STICK);
        ItemMeta m = cubuk.getItemMeta();
        m.displayName(c("&6&lKit Çubuğu &8(&f" + rutbe + "&8)"));
        m.lore(List.of(
                c("&7Bir &eshulker kutusuna &7sağ tıkla."),
                c("&7İçindeki eşyalar &f" + rutbe + " &7kiti olur."),
                c("&8Kit menüsünde gösterilir.")));
        m.setEnchantmentGlintOverride(true);
        m.getPersistentDataContainer().set(cubukAnahtar, PersistentDataType.STRING, rutbe);
        cubuk.setItemMeta(m);

        for (ItemStack artan : p.getInventory().addItem(cubuk).values()) {
            Item d = p.getWorld().dropItem(p.getLocation(), artan);
            d.setOwner(p.getUniqueId());
        }
        msj(p, "&aKit çubuğu verildi: &f" + rutbe + "&a. &7Bir shulker kutusunu yere koy, içine kiti diz ve çubukla sağ tıkla.");
    }

    // ---- /rankah

    private void rankAhKomut(CommandSender sender, String[] args) {
        if (!sender.hasPermission(ADMIN)) {
            msj(sender, "&cYetkin yok.");
            return;
        }
        if (args.length == 0) {
            msj(sender, "&7AH ilan limitleri &8(/rankah <rütbe> <sınır|reset>)");
            for (String k : tabela.taglar().keySet()) {
                if (Tabela.kaliciMi(k)) continue;
                Integer l = tabela.rankAhLimiti(k);
                sender.sendMessage(c("  &8- &f" + k + " &8: " + (l == null ? "&7ayarlanmamış" : "&a" + l)));
            }
            msj(sender, "&8Yetkili rütbeler sınırsızdır. &8BUGFOUNDER: AH hakkı sabit " + Tabela.BUGFOUNDER_AH + ".");
            return;
        }

        String rutbe = args[0].toLowerCase();
        if (!tabela.tagVar(rutbe)) {
            msj(sender, "&cBöyle bir rütbe yok: &f" + args[0] + " &7(/tag list)");
            return;
        }
        if (Tabela.kaliciMi(rutbe)) {
            msj(sender, rutbe.equalsIgnoreCase("bugfounder") ? "&eBUGFOUNDER AH hakkı sabit: " + Tabela.BUGFOUNDER_AH + "." : "&eYetkili rütbeler zaten sınırsız AH hakkına sahip.");
            return;
        }
        if (args.length == 1) {
            Integer l = tabela.rankAhLimiti(rutbe);
            msj(sender, "&f" + rutbe + " &7AH limiti: " + (l == null ? "&7ayarlanmamış" : "&a" + l));
            return;
        }

        if (args[1].equalsIgnoreCase("reset") || args[1].equalsIgnoreCase("sifirla") || args[1].equalsIgnoreCase("sıfırla")) {
            tabela.rankAhAyarla(rutbe, null);
            tabela.kaydet();
            msj(sender, "&f" + rutbe + " &7AH limiti kaldırıldı (varsayılan hak geçerli).");
            return;
        }
        int sinir = sayiOku(args[1]);
        if (sinir < 1 || sinir > 1000) {
            msj(sender, "&cSınır 1 - 1000 arasında bir sayı olmalı.");
            return;
        }
        tabela.rankAhAyarla(rutbe, sinir);
        tabela.kaydet();
        msj(sender, "&f" + rutbe + " &arütbesi artık AH'ye aynı anda &f" + sinir + " &ailan koyabilir.");
    }

    // ---- /kit

    private void kitKomut(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) {
            msj(sender, "&cBu komut sadece oyuncular için.");
            return;
        }
        if (args.length > 0) {
            // baska rutbenin kitini sadece yetkililer onizleyebilir
            if (!p.hasPermission(ADMIN)) {
                msj(p, "&cYetkin yok.");
                return;
            }
            String k = args[0].toLowerCase();
            if (!tabela.tagVar(k) || Tabela.kaliciMi(k)) {
                msj(p, "&cBöyle bir kitli rütbe yok.");
                return;
            }
            if (!kitler.var(k)) {
                msj(p, "&cBu rütbenin kiti henüz ayarlanmamış.");
                return;
            }
            kitMenuAc(p, k, true);
            return;
        }

        String tag = tabela.tagAdi(p.getUniqueId());
        if (tag == null) {
            msj(p, "&cKit alabilmek için bir rütben olmalı.");
            return;
        }
        if (Tabela.kaliciMi(tag)) {
            msj(p, "&7Yetkili rütbelerin kiti yoktur.");
            return;
        }
        if (!kitler.var(tag)) {
            msj(p, "&cRütbenin kiti henüz ayarlanmamış.");
            return;
        }
        kitMenuAc(p, tag, false);
    }

    // ---- /rank

    private void rankBilgi(Player p, String[] args) {
        if (args.length > 0) {
            OfflinePlayer hedef = Bukkit.getOfflinePlayer(args[0]);
            String t = tabela.tagAdi(hedef.getUniqueId());
            msj(p, "&f" + args[0] + " &7rütbesi: &r"
                    + (t == null ? "&7yok" : tabela.taglar().get(t)));
            return;
        }
        UUID u = p.getUniqueId();
        String t = tabela.tagAdi(u);
        msj(p, "&7Rütben: &r" + (t == null ? "&7yok" : tabela.taglar().get(t)));
        long kalan = tabela.kalanSure(u);
        if (kalan >= 0) msj(p, "&7Rütbenin bitmesine: &f" + sure(kalan));
        if (t != null && !Tabela.kaliciMi(t) && kitler.var(t)) {
            long bekle = kitler.kalanBekleme(u, t, kitBeklemeMs());
            msj(p, "&7Kit: " + (bekle <= 0 ? "&ahazır &8(/kit)" : "&e" + sure(bekle) + " sonra"));
        }
        msj(p, "&7Vuruş hasarın: &c" + Math.round(tabela.vurusHasari(p) * 10) / 10.0);
        String para = paraMetni(u);
        if (para != null) msj(p, "&7Paran: &a" + para);
    }
}
