package net.mrwqlf.tagsistemi;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

/** Kit menusunu taniyan envanter sahibi. */
public final class KitMenu implements InventoryHolder {

    /** Menu hangi rutbenin kitini gosteriyor */
    public final String rutbe;
    /** true = sadece onizleme (alma dugmesi yok) */
    public final boolean onizleme;

    private Inventory inv;

    public KitMenu(String rutbe, boolean onizleme) {
        this.rutbe = rutbe;
        this.onizleme = onizleme;
    }

    public void setInventory(Inventory inv) {
        this.inv = inv;
    }

    @Override
    public @NotNull Inventory getInventory() {
        return inv;
    }
}
