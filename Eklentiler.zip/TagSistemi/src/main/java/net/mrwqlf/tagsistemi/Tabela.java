package net.mrwqlf.tagsistemi;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Yan tabela (scoreboard), rutbe (tag) verisi ve isim duzeni. */
public final class Tabela {

    private static final DecimalFormat HASAR = new DecimalFormat("#,##0.#");

    private final TagSistemi plugin;
    private final File tercihDosya;

    private final Set<UUID> kapali = new HashSet<>();
    private final Map<UUID, Scoreboard> tabelalar = new HashMap<>();
    /** oyuncu -> kisisel tabelalarda kullanilan takim adi (16 karakter siniri icin) */
    private final Map<UUID, String> takimAdi = new HashMap<>();
    private int takimSayac = 0;

    /** oyuncuya elle verilen tag adi */
    private final Map<UUID, String> oyuncuTag = new HashMap<>();
    /** tag adi -> gorunum bicimi (& renk kodlariyla) */
    private final Map<String, String> tagTanim = new java.util.LinkedHashMap<>();
    /** tag adi -> ismin rengi (& kodu); yoksa irk rengi kullanilir */
    private final Map<String, String> tagRenk = new HashMap<>();
    /** tag adi -> sohbet mesaji rengi (& kodu) */
    private final Map<String, String> tagMesajRenk = new HashMap<>();
    private File tagDosya;

    /** Kalici (suresiz) yetkili taglar: kit yok, AH sinirsiz, sadece admin alinca gider. */
    public static final java.util.Set<String> YETKILI = java.util.Set.of("admin", "moderator", "rehber", "bugfounder");
    /** Sinirsiz AH hakki icin kullanilan deger (MarketAH da ayni degeri bekler). */
    public static final int SINIRSIZ = Integer.MAX_VALUE;
    /** BUGFOUNDER: tagi sureleri dolmaz ama yetkisi yok, AH'ye en fazla 6 ilan koyar. */
    public static final int BUGFOUNDER_AH = 6;

    /** tag adi -> AH'ye ayni anda koyabilecegi ilan sayisi (/rankah) */
    private final Map<String, Integer> ahLimit = new HashMap<>();
    /** oyuncu -> rutbe bitis zamani (epoch ms); yetkili taglarda kayit yoktur */
    private final Map<UUID, Long> oyuncuBitis = new HashMap<>();

    public Tabela(TagSistemi plugin) {
        this.plugin = plugin;
        this.tercihDosya = new File(plugin.getDataFolder(), "tercihler.yml");
        this.tagDosya = new File(plugin.getDataFolder(), "taglar.yml");
        yukle();
    }

    // ---------------------------------------------------------------- veri

    public void yukle() {
        kapali.clear();
        if (tercihDosya.exists()) {
            FileConfiguration cfg = YamlConfiguration.loadConfiguration(tercihDosya);
            for (String k : cfg.getStringList("kapali")) {
                try {
                    kapali.add(UUID.fromString(k));
                } catch (IllegalArgumentException ignored) {
                }
            }
        }

        oyuncuTag.clear();
        tagTanim.clear();
        tagRenk.clear();
        tagMesajRenk.clear();
        ahLimit.clear();
        oyuncuBitis.clear();
        if (tagDosya != null && tagDosya.exists()) {
            FileConfiguration tcfg = YamlConfiguration.loadConfiguration(tagDosya);
            ConfigurationSection ts = tcfg.getConfigurationSection("taglar");
            if (ts != null) for (String ad : ts.getKeys(false)) tagTanim.put(ad.toLowerCase(), ts.getString(ad, ad));
            ConfigurationSection rs = tcfg.getConfigurationSection("renkler");
            if (rs != null) for (String ad : rs.getKeys(false)) tagRenk.put(ad.toLowerCase(), rs.getString(ad, ""));
            ConfigurationSection ms = tcfg.getConfigurationSection("mesaj-renkleri");
            if (ms != null) for (String ad : ms.getKeys(false)) tagMesajRenk.put(ad.toLowerCase(), ms.getString(ad, ""));
            ConfigurationSection al = tcfg.getConfigurationSection("ah-limitleri");
            if (al != null) for (String ad : al.getKeys(false)) ahLimit.put(ad.toLowerCase(), al.getInt(ad));
            ConfigurationSection os = tcfg.getConfigurationSection("oyuncular");
            if (os != null) for (String u : os.getKeys(false)) {
                try {
                    UUID id = UUID.fromString(u);
                    if (os.isConfigurationSection(u)) {
                        // yeni bicim: oyuncular.<uuid>.tag / .bitis
                        oyuncuTag.put(id, os.getString(u + ".tag", "").toLowerCase());
                        long b = os.getLong(u + ".bitis", 0L);
                        if (b > 0) oyuncuBitis.put(id, b);
                    } else {
                        // eski bicim: oyuncular.<uuid>: tagadi (suresiz)
                        oyuncuTag.put(id, os.getString(u, "").toLowerCase());
                    }
                } catch (IllegalArgumentException ignored) {
                }
            }
        }

        yetkiliTaglariGarantile();
    }

    /**
     * 4 yetkili tagin var oldugundan emin olur. Eski surumdeki "yonetici" tagi "admin"e tasinir.
     * Daha once elle degistirilmis bicimlere dokunulmaz; sadece eski varsayilan renkler yenilenir.
     */
    private void yetkiliTaglariGarantile() {
        boolean degisti = false;

        // yonetici -> admin (oyuncular dahil)
        if (tagTanim.containsKey("yonetici") && !tagTanim.containsKey("admin")) {
            tagTanim.put("admin", tagTanim.remove("yonetici"));
            oyuncuTag.replaceAll((u, t) -> t.equals("yonetici") ? "admin" : t);
            degisti = true;
        }
        degisti |= varsayilanYaz("admin", "&c&lADMİN&r ", "&c&lYÖNETİCİ&r ");
        degisti |= varsayilanYaz("moderator", "&6&lMODERATÖR&r ", "&a&lMODERATÖR&r ");
        degisti |= varsayilanYaz("rehber", "&a&lREHBER&r ", "&b&lREHBER&r ");
        degisti |= varsayilanYaz("bugfounder", "&9&lBUGFOUNDER&r ", null);

        // yetkili taglarin AH hakki her zaman sinirsiz (kayit gerekmez, ama veriyi temiz tut)
        for (String y : YETKILI) ahLimit.remove(y);
        // yetkili tag sahiplerinde bitis tarihi olmaz
        oyuncuBitis.keySet().removeIf(u -> kaliciMi(oyuncuTag.get(u)));

        if (degisti) kaydet();
    }

    /** Tag yoksa varsayilanla olusturur; varsa ve eski varsayilana esitse yenisiyle degistirir. */
    private boolean varsayilanYaz(String ad, String yeni, String eskiVarsayilan) {
        String mevcut = tagTanim.get(ad);
        if (mevcut == null || (eskiVarsayilan != null && mevcut.equals(eskiVarsayilan))) {
            tagTanim.put(ad, yeni);
            return true;
        }
        return false;
    }

    public void kaydet() {
        FileConfiguration cfg = new YamlConfiguration();
        List<String> k = new ArrayList<>();
        for (UUID u : kapali) k.add(u.toString());
        cfg.set("kapali", k);

        FileConfiguration tcfg = new YamlConfiguration();
        for (Map.Entry<String, String> e : tagTanim.entrySet()) tcfg.set("taglar." + e.getKey(), e.getValue());
        for (Map.Entry<String, String> e : tagRenk.entrySet()) tcfg.set("renkler." + e.getKey(), e.getValue());
        for (Map.Entry<String, String> e : tagMesajRenk.entrySet()) tcfg.set("mesaj-renkleri." + e.getKey(), e.getValue());
        for (Map.Entry<String, Integer> e : ahLimit.entrySet()) tcfg.set("ah-limitleri." + e.getKey(), e.getValue());
        for (Map.Entry<UUID, String> e : oyuncuTag.entrySet()) {
            tcfg.set("oyuncular." + e.getKey() + ".tag", e.getValue());
            Long b = oyuncuBitis.get(e.getKey());
            if (b != null) tcfg.set("oyuncular." + e.getKey() + ".bitis", b);
        }

        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            tcfg.save(tagDosya);
            cfg.save(tercihDosya);
        } catch (IOException ex) {
            plugin.getLogger().warning("Veriler kaydedilemedi: " + ex.getMessage());
        }
    }

    /**
     * Rank onekini dondurur. Oyuncunun kendi isim/bayrak bilesenine
     * DOKUNMAZ - sadece onune eklenmek uzere hazirlanir.
     */
    public Component rankOnEk(Player p) {
        String tag = tagAdi(p.getUniqueId());
        if (tag == null) return Component.empty();
        return c(kalin(tagTanim.get(tag)) + "&r ");
    }

    /** Her tag kalin (bold) olur: her renk kodundan sonra &l eklenir (renk kodu kalinligi sifirladigi icin). */
    static String kalin(String metin) {
        String t = metin.strip();
        t = t.replaceAll("(?i)&([0-9a-f])", "&$1&l");
        return t.startsWith("&") ? t : "&l" + t;
    }

    /** Tabeladaki "Rank:" satirinda gosterilecek metin. */
    public String rankMetni(Player p) {
        String tag = tagAdi(p.getUniqueId());
        if (tag == null) return "&7yok";
        // tabelada parantez gosterilmez: [ ] karakterleri temizlenir
        return kalin(tagTanim.get(tag).replace("[", "").replace("]", ""));
    }

    /** Oyuncunun su an vurabilecegi hasar (silah + buyu + efekt dahil). */
    public double vurusHasari(Player p) {
        double taban = 1.0;
        var attr = p.getAttribute(org.bukkit.attribute.Attribute.ATTACK_DAMAGE);
        if (attr != null) taban = attr.getValue();

        var elde = p.getInventory().getItemInMainHand();
        int keskinlik = elde.getEnchantmentLevel(org.bukkit.enchantments.Enchantment.SHARPNESS);
        if (keskinlik > 0) taban += 1.0 + 0.5 * (keskinlik - 1);

        var guc = p.getPotionEffect(org.bukkit.potion.PotionEffectType.STRENGTH);
        if (guc != null) taban += 3.0 * (guc.getAmplifier() + 1);
        var zayiflik = p.getPotionEffect(org.bukkit.potion.PotionEffectType.WEAKNESS);
        if (zayiflik != null) taban -= 4.0 * (zayiflik.getAmplifier() + 1);

        return Math.max(0, taban);
    }

    /** Irk bayragini parantez icine alir: [⚑] */
    private Component parantezliBayrak(Component bayrak) {
        String duz = LegacyComponentSerializer.legacyAmpersand().serialize(bayrak);
        if (duz.isBlank()) return Component.empty();
        // irk eklentisinin prefix'indeki bosluklar kirpilir: [⚑ ] degil [⚑]
        Component temiz = LegacyComponentSerializer.legacyAmpersand().deserialize(duz.strip());
        String ac = plugin.getConfig().getString("bayrak-parantez-ac", "&8[");
        String kap = plugin.getConfig().getString("bayrak-parantez-kapa", "&8] ");
        return Component.empty().append(c(ac)).append(temiz).append(c(kap));
    }

    // ---------------------------------------------------------------- tag

    public boolean tagOlustur(String ad, String bicim) {
        return tagTanim.put(ad.toLowerCase(), bicim) == null;
    }

    /** Rutbeye sahip oyuncularin isim rengi. */
    public boolean tagRenk(String ad, String renkKodu) {
        if (!tagVar(ad)) return false;
        tagRenk.put(ad.toLowerCase(), renkKodu);
        return true;
    }

    /** Oyuncunun isim rengi: rutbe rengi varsa o, yoksa null (irk rengi kalir). */
    public NamedTextColor isimRengi(UUID uuid) {
        String tag = tagAdi(uuid);
        if (tag == null) return null;
        return kodaRenk(tagRenk.get(tag));
    }

    /** Rutbeye sahip oyuncularin sohbet mesaji rengi. */
    public boolean tagMesajRenk(String ad, String renkKodu) {
        if (!tagVar(ad)) return false;
        tagMesajRenk.put(ad.toLowerCase(), renkKodu);
        return true;
    }

    /** Oyuncunun sohbet mesaji rengi; rutbesi/rengi yoksa null. */
    public NamedTextColor mesajRengi(UUID uuid) {
        String tag = tagAdi(uuid);
        if (tag == null) return null;
        return kodaRenk(tagMesajRenk.get(tag));
    }

    private NamedTextColor kodaRenk(String kod) {
        if (kod == null || kod.isBlank()) return null;
        Component ornek = c(kod + "x");
        return ornek.color() == null ? null : NamedTextColor.nearestTo(ornek.color());
    }

    /** Yetkili (kalici) tag mi? null-guvenli (Set.of null kabul etmez). */
    public static boolean kaliciMi(String ad) {
        return ad != null && YETKILI.contains(ad.toLowerCase());
    }

    /** Tag siler. Yetkili taglar silinemez. 0 = silindi, 1 = yok, 2 = yetkili tag. */
    public int tagSil(String ad) {
        String k = ad.toLowerCase();
        if (kaliciMi(k)) return 2;
        if (tagTanim.remove(k) == null) return 1;
        tagRenk.remove(k);
        tagMesajRenk.remove(k);
        ahLimit.remove(k);
        for (java.util.Iterator<Map.Entry<UUID, String>> it = oyuncuTag.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<UUID, String> e = it.next();
            if (e.getValue().equals(k)) {
                oyuncuBitis.remove(e.getKey());
                it.remove();
            }
        }
        return 0;
    }

    public boolean tagVar(String ad) {
        return tagTanim.containsKey(ad.toLowerCase());
    }

    public Map<String, String> taglar() {
        return tagTanim;
    }

    /** Suresiz (yetkili) olmayan rutbelerin sayisi. */
    public int sureliSayisi() {
        int n = 0;
        for (String k : tagTanim.keySet()) if (!kaliciMi(k)) n++;
        return n;
    }

    /**
     * Rutbeyi verir. Yetkili taglar suresizdir. Sureli rutbede ayni rutbe tekrar verilirse
     * kalan surenin USTUNE eklenir.
     *
     * @return bitis zamani (epoch ms), 0 = suresiz, -1 = boyle bir rutbe yok
     */
    public long tagVer(UUID uuid, String ad, int gun) {
        String k = ad.toLowerCase();
        if (!tagVar(k)) return -1;

        String eskiTag = oyuncuTag.get(uuid);
        Long eskiBitis = oyuncuBitis.get(uuid);
        oyuncuTag.put(uuid, k);

        if (kaliciMi(k)) {
            oyuncuBitis.remove(uuid);
            return 0;
        }
        long simdi = System.currentTimeMillis();
        long baz = simdi;
        if (k.equals(eskiTag) && eskiBitis != null && eskiBitis > simdi) baz = eskiBitis;
        long bitis = baz + gun * 86_400_000L;
        oyuncuBitis.put(uuid, bitis);
        return bitis;
    }

    public void tagAl(UUID uuid) {
        oyuncuTag.remove(uuid);
        oyuncuBitis.remove(uuid);
    }

    /** Oyuncunun gecerli tag adi; yoksa ya da suresi dolduysa null. */
    public String tagAdi(UUID uuid) {
        String t = oyuncuTag.get(uuid);
        if (t == null || !tagTanim.containsKey(t)) return null;
        Long b = oyuncuBitis.get(uuid);
        if (b != null && System.currentTimeMillis() >= b) return null;
        return t;
    }

    /** Kalan sure (ms); suresiz ya da rutbesiz ise -1. */
    public long kalanSure(UUID uuid) {
        if (tagAdi(uuid) == null) return -1;
        Long b = oyuncuBitis.get(uuid);
        return b == null ? -1 : Math.max(0, b - System.currentTimeMillis());
    }

    /** Suresi dolan rutbeleri kaldirir ve etkilenen oyunculari doner. */
    public List<UUID> suresiDolanlariTemizle() {
        long simdi = System.currentTimeMillis();
        List<UUID> dolanlar = new ArrayList<>();
        for (java.util.Iterator<Map.Entry<UUID, Long>> it = oyuncuBitis.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<UUID, Long> e = it.next();
            if (e.getValue() <= simdi) {
                oyuncuTag.remove(e.getKey());
                dolanlar.add(e.getKey());
                it.remove();
            }
        }
        return dolanlar;
    }

    // ---------------------------------------------------------------- AH limiti

    /**
     * MarketAH'in yansima ile cagirdigi deger: oyuncunun rutbesine bagli ilan limiti.
     * -1 = rutbe ya da limit yok, SINIRSIZ = yetkili. Adini/imzasini degistirme.
     */
    public int ahLimiti(UUID uuid) {
        String t = tagAdi(uuid);
        if (t == null) return -1;
        if (t.equalsIgnoreCase("bugfounder")) return BUGFOUNDER_AH;
        if (kaliciMi(t)) return SINIRSIZ;
        return ahLimit.getOrDefault(t, -1);
    }

    public Integer rankAhLimiti(String ad) {
        return ahLimit.get(ad.toLowerCase());
    }

    public void rankAhAyarla(String ad, Integer deger) {
        if (deger == null) ahLimit.remove(ad.toLowerCase());
        else ahLimit.put(ad.toLowerCase(), deger);
    }

    // ---------------------------------------------------------------- tabela

    public boolean acikMi(UUID uuid) {
        return !kapali.contains(uuid);
    }

    /** Tabelayi ac/kapa, yeni durumu doner. */
    public boolean degistir(Player p) {
        UUID u = p.getUniqueId();
        if (kapali.remove(u)) {
            goster(p);
            kaydet();
            return true;
        }
        kapali.add(u);
        kaldir(p);
        kaydet();
        return false;
    }

    public void kaldir(Player p) {
        tabelalar.remove(p.getUniqueId());
        p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
    }

    public void goster(Player p) {
        if (!plugin.getConfig().getBoolean("tabela.aktif", true)) return;
        if (!acikMi(p.getUniqueId())) return;

        Scoreboard sb = tabelalar.get(p.getUniqueId());
        if (sb == null || p.getScoreboard() != sb) {
            sb = kur(p);
            tabelalar.put(p.getUniqueId(), sb);
            p.setScoreboard(sb);
        }
        guncelle(p, sb);
    }

    /** Irk eklentisinin bayragi + oyuncu ismi (ana scoreboard takimindan). */
    public Component bayrakliIsim(Player p) {
        Team t = Bukkit.getScoreboardManager().getMainScoreboard().getEntryTeam(p.getName());
        if (t == null) return rankOnEk(p).append(p.displayName());
        // bayrak (prefix) kendi rengiyle kalir; irk rengi SADECE isme uygulanir
        Component isim = Component.text(p.getName());
        NamedTextColor rutbeRengi = isimRengi(p.getUniqueId());
        if (rutbeRengi != null) isim = isim.color(rutbeRengi);
        else if (t.color() != null) isim = isim.color(t.color());
        return Component.empty()
                .append(parantezliBayrak(t.prefix()))
                .append(rankOnEk(p))
                .append(isim)
                .append(t.suffix());
    }

    private Component c(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s)
                .decoration(TextDecoration.ITALIC, false);
    }

    /** Satir sayisi: bos, Oyuncu, Para, Rank, bos, Hasar, bos, IP = 8 */
    private static final int SATIR = 9;

    private Scoreboard kur(Player p) {
        Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective obj = sb.registerNewObjective("tagsistemi", Criteria.DUMMY,
                c(plugin.getConfig().getString("tabela.sunucu-adi", "&6&lSUNUCU")));
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);

        for (int i = 0; i < SATIR; i++) {
            String entry = girdi(i);
            Team t = sb.registerNewTeam("satir" + i);
            t.addEntry(entry);
            obj.getScore(entry).setScore(SATIR - i);
        }
        return sb;
    }

    /** Her satir icin gorunmez benzersiz girdi. */
    private static String girdi(int i) {
        ChatColor[] renkler = ChatColor.values();
        return renkler[i % renkler.length].toString() + ChatColor.RESET;
    }

    private String takimAdi(Player q) {
        return takimAdi.computeIfAbsent(q.getUniqueId(), k -> "tag" + (takimSayac++ % 100000));
    }

    /**
     * Kisisel tabelaya isim satirlarini kurar:
     *   [Rank] + (irk eklentisinin bayragi) + isim
     * Ana scoreboard'a DOKUNULMAZ; irk eklentisinin bayragi ve rengi
     * oradan oldugu gibi kopyalanir, sadece onune rank eklenir.
     */
    private void isimleriSenkronla(Scoreboard sb) {
        if (!plugin.getConfig().getBoolean("rank-isim-oneki", true)) return;
        Scoreboard ana = Bukkit.getScoreboardManager().getMainScoreboard();

        for (Player q : Bukkit.getOnlinePlayers()) {
            String tad = takimAdi(q);
            Team hedef = sb.getTeam(tad);
            if (hedef == null) hedef = sb.registerNewTeam(tad);

            Component onek = Component.empty();
            Team kaynak = ana.getEntryTeam(q.getName());   // irk eklentisinin takimi
            if (kaynak != null) {
                // once bayrak (parantezli), sonra tag, en son isim
                onek = parantezliBayrak(kaynak.prefix());
                hedef.suffix(kaynak.suffix());
                NamedTextColor rutbeRengi = isimRengi(q.getUniqueId());
                if (rutbeRengi != null) hedef.color(rutbeRengi);
                else if (kaynak.color() != null) hedef.color(NamedTextColor.nearestTo(kaynak.color()));
            }
            onek = onek.append(rankOnEk(q));
            hedef.prefix(onek);
            if (!hedef.hasEntry(q.getName())) hedef.addEntry(q.getName());
        }

        // cikan oyuncularin takimlarini temizle
        for (Team t : new ArrayList<>(sb.getTeams())) {
            if (!t.getName().startsWith("tag")) continue;
            boolean var = false;
            for (String e : t.getEntries()) {
                if (Bukkit.getPlayerExact(e) != null) {
                    var = true;
                    break;
                }
            }
            if (!var) t.unregister();
        }
    }

    private void guncelle(Player p, Scoreboard sb) {
        UUID u = p.getUniqueId();
        String ip = plugin.getConfig().getString("tabela.sunucu-ip", "&fsunucu.ip");


        String[] satirlar = new String[SATIR];
        satirlar[0] = "&7&m                      ";
        satirlar[1] = "&fOyuncu: &f" + p.getName();
        String para = plugin.paraMetni(u);
        satirlar[2] = "&fPara: " + (para == null ? "&7-" : "&a" + para);
        satirlar[3] = "&fRütbe: &r" + rankMetni(p);
        String pass = plugin.passMetni(u);
        satirlar[4] = "&fBP Aşama: " + (pass == null ? "&7-" : "&d" + pass);
        satirlar[5] = "&r ";
        satirlar[6] = "&fVuruş Hasarı: &c" + HASAR.format(vurusHasari(p));
        satirlar[7] = "&7&m                      ";
        satirlar[8] = ip;

        for (int i = 0; i < SATIR; i++) {
            Team t = sb.getTeam("satir" + i);
            if (t != null) t.prefix(c(satirlar[i]));
        }
        isimleriSenkronla(sb);
    }
}
