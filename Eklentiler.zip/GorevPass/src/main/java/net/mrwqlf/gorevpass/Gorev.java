package net.mrwqlf.gorevpass;

import org.bukkit.Material;

import java.util.List;
import java.util.Locale;

/** Gorev havuzundaki tek bir gorev tanimi. */
public final class Gorev {

    public final String id;
    public final String ad;
    public final String tur;              // MOB_OLDUR, BLOK_KIR, BLOK_KOY, BALIK_TUT, OYUNCU_OLDUR, SURE_DAKIKA
    public final List<String> hedefler;   // bos ya da HEPSI = hepsi gecerli
    public final int adet;
    public final int xp;
    public final Material simge;
    public final Odul odul;

    public Gorev(String id, String ad, String tur, List<String> hedefler, int adet, int xp,
                 Material simge, Odul odul) {
        this.id = id;
        this.ad = ad;
        this.tur = tur;
        this.hedefler = hedefler;
        this.adet = adet;
        this.xp = xp;
        this.simge = simge;
        this.odul = odul;
    }

    public boolean hedefUyar(String hedef) {
        if (hedefler.isEmpty()) return true;
        for (String h : hedefler) {
            if (h.equalsIgnoreCase("HEPSI") || h.equalsIgnoreCase("ANY")) return true;
        }
        if (hedef == null) return false;
        for (String h : hedefler) if (h.equalsIgnoreCase(hedef)) return true;
        return false;
    }

    /** Menude gosterilen kisa aciklama. */
    public String tanim() {
        String hedefMetni = hedefler.isEmpty() || hedefler.contains("HEPSI")
                ? "" : String.join(", ", hedefler.stream().map(h -> h.toLowerCase(Locale.ROOT).replace('_', ' ')).toList());
        return switch (tur) {
            case "MOB_OLDUR" -> hedefMetni.isEmpty() ? "Canlı öldür" : "Öldür: " + hedefMetni;
            case "BLOK_KIR" -> hedefMetni.isEmpty() ? "Blok kır" : "Kır: " + hedefMetni;
            case "BLOK_KOY" -> hedefMetni.isEmpty() ? "Blok yerleştir" : "Yerleştir: " + hedefMetni;
            case "BALIK_TUT" -> "Balık tut";
            case "OYUNCU_OLDUR" -> "Oyuncu öldür";
            case "SURE_DAKIKA" -> "Sunucuda dakika geçir";
            default -> tur;
        };
    }
}
