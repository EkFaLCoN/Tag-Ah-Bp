package net.mrwqlf.gorevpass;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * Config'ten okunan odul: konsol komutlari ve/veya esyalar.
 * Komutlarda %oyuncu% yerine oyuncunun adi yazilir. Sadece config'te yazan sey calisir.
 */
public final class Odul {

    public static final Odul BOS = new Odul(List.of(), List.of(), "");

    public final List<String> komutlar;
    public final List<String> esyalar;
    public final String aciklama;

    public Odul(List<String> komutlar, List<String> esyalar, String aciklama) {
        this.komutlar = komutlar;
        this.esyalar = esyalar;
        this.aciklama = aciklama;
    }

    /** Bolum yoksa BOS doner. */
    public static Odul oku(ConfigurationSection s) {
        if (s == null) return BOS;
        return new Odul(new ArrayList<>(s.getStringList("komutlar")),
                new ArrayList<>(s.getStringList("esyalar")),
                s.getString("aciklama", ""));
    }

    public boolean bosMu() {
        return komutlar.isEmpty() && esyalar.isEmpty();
    }

    /** Odulu oyuncuya verir. Envanter doluysa esya yere duser ve sadece o alabilir. */
    public void ver(Player p, GorevPass plugin) {
        for (String komut : komutlar) {
            String k = komut.trim();
            if (k.startsWith("/")) k = k.substring(1);
            if (k.isEmpty()) continue;
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), k.replace("%oyuncu%", p.getName()));
        }
        for (String e : esyalar) {
            String[] parca = e.trim().split(":");
            Material mat = Material.matchMaterial(parca[0].trim());
            if (mat == null || mat.isAir()) {
                plugin.getLogger().warning("Ödül eşyası tanınmadı: " + e);
                continue;
            }
            int adet = 1;
            if (parca.length > 1) {
                try {
                    adet = Integer.parseInt(parca[1].trim());
                } catch (NumberFormatException ex) {
                    plugin.getLogger().warning("Ödül adedi okunamadı: " + e);
                }
            }
            adet = Math.max(1, Math.min(adet, 2304));
            for (ItemStack artan : p.getInventory().addItem(new ItemStack(mat, adet)).values()) {
                Item d = p.getWorld().dropItem(p.getLocation(), artan);
                d.setOwner(p.getUniqueId());
            }
        }
    }
}
