package net.mrwqlf.gorevpass;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Oyuncu ilerlemeleri ve pass XP'si (veri.yml). */
public final class Veri {

    /** Tek oyuncunun verisi. */
    public static final class Oyuncu {
        public long xp;
        /** Ilerlemenin ait oldugu hafta (donem). Degisirse ilerleme sifirlanir. */
        public String donem = "";
        public final Map<String, Integer> ilerleme = new HashMap<>();
        public final Set<String> tamam = new HashSet<>();
        public final Set<Integer> alinan = new HashSet<>();
        /** Yetkilinin verdigi premium battle pass var mi */
        public boolean premium;
        public final Set<Integer> premiumAlinan = new HashSet<>();
        /** Gunluk gorevlerin ait oldugu gun; degisirse gunluk ilerleme sifirlanir */
        public String gunDonem = "";
        public final Map<String, Integer> gunIlerleme = new HashMap<>();
        public final Set<String> gunTamam = new HashSet<>();
    }

    private final GorevPass plugin;
    private final File dosya;
    private final Map<UUID, Oyuncu> oyuncular = new HashMap<>();

    /** Yoneticinin "yenile" ile arttirdigi sayi: haftalik gorev secimini degistirir. */
    public int tohum = 0;
    public boolean kirli = false;

    public Veri(GorevPass plugin) {
        this.plugin = plugin;
        this.dosya = new File(plugin.getDataFolder(), "veri.yml");
        yukle();
    }

    public Oyuncu al(UUID uuid) {
        return oyuncular.computeIfAbsent(uuid, k -> new Oyuncu());
    }

    public Map<UUID, Oyuncu> hepsi() {
        return oyuncular;
    }

    public void yukle() {
        oyuncular.clear();
        if (!dosya.exists()) return;
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(dosya);
        tohum = cfg.getInt("tohum", 0);
        ConfigurationSection os = cfg.getConfigurationSection("oyuncular");
        if (os == null) return;
        for (String u : os.getKeys(false)) {
            try {
                UUID id = UUID.fromString(u);
                ConfigurationSection s = os.getConfigurationSection(u);
                if (s == null) continue;
                Oyuncu o = new Oyuncu();
                o.xp = s.getLong("xp", 0L);
                o.donem = s.getString("donem", "");
                ConfigurationSection il = s.getConfigurationSection("ilerleme");
                if (il != null) for (String g : il.getKeys(false)) o.ilerleme.put(g, il.getInt(g));
                o.tamam.addAll(s.getStringList("tamam"));
                o.gunDonem = s.getString("gun-donem", "");
                ConfigurationSection gi = s.getConfigurationSection("gun-ilerleme");
                if (gi != null) for (String g : gi.getKeys(false)) o.gunIlerleme.put(g, gi.getInt(g));
                o.gunTamam.addAll(s.getStringList("gun-tamam"));
                o.alinan.addAll(s.getIntegerList("alinan"));
                o.premium = s.getBoolean("premium", false);
                o.premiumAlinan.addAll(s.getIntegerList("premium-alinan"));
                oyuncular.put(id, o);
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    public void kaydet() {
        FileConfiguration cfg = new YamlConfiguration();
        cfg.set("tohum", tohum);
        for (Map.Entry<UUID, Oyuncu> e : oyuncular.entrySet()) {
            Oyuncu o = e.getValue();
            // bos kayitlari dosyaya yazma
            if (o.xp == 0 && o.ilerleme.isEmpty() && o.tamam.isEmpty() && o.alinan.isEmpty()
                    && !o.premium && o.premiumAlinan.isEmpty()) continue;
            String k = "oyuncular." + e.getKey();
            cfg.set(k + ".xp", o.xp);
            cfg.set(k + ".donem", o.donem);
            for (Map.Entry<String, Integer> g : o.ilerleme.entrySet()) cfg.set(k + ".ilerleme." + g.getKey(), g.getValue());
            cfg.set(k + ".tamam", new java.util.ArrayList<>(o.tamam));
            cfg.set(k + ".gun-donem", o.gunDonem);
            for (Map.Entry<String, Integer> g : o.gunIlerleme.entrySet()) cfg.set(k + ".gun-ilerleme." + g.getKey(), g.getValue());
            cfg.set(k + ".gun-tamam", new java.util.ArrayList<>(o.gunTamam));
            cfg.set(k + ".alinan", new java.util.ArrayList<>(o.alinan));
            cfg.set(k + ".premium", o.premium);
            cfg.set(k + ".premium-alinan", new java.util.ArrayList<>(o.premiumAlinan));
        }
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            cfg.save(dosya);
            kirli = false;
        } catch (IOException ex) {
            plugin.getLogger().warning("veri.yml kaydedilemedi: " + ex.getMessage());
        }
    }
}
