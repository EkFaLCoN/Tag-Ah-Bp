package net.mrwqlf.gorevpass;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

/** Gorev ve pass menulerini taniyan envanter sahibi. */
public final class PassMenu implements InventoryHolder {

    public enum Tip { GOREV, PASS }

    public final Tip tip;
    public final int sayfa;
    private Inventory inv;

    public PassMenu(Tip tip, int sayfa) {
        this.tip = tip;
        this.sayfa = sayfa;
    }

    public void setInventory(Inventory inv) {
        this.inv = inv;
    }

    @Override
    public @NotNull Inventory getInventory() {
        return inv;
    }
}
