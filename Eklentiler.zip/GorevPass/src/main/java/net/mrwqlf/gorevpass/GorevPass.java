package net.mrwqlf.gorevpass;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.IsoFields;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;

/**
 * GorevPass: haftalik yenilenen gorevler + battle pass.
 * Gorevler, odulller ve seviyeler tamamen config.yml'den ayarlanir.
 */
public final class GorevPass extends JavaPlugin implements Listener {

    private static final String ADMIN = "gorevpass.admin";
    private static final int[] SLOTLAR = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34,
            37, 38, 39, 40, 41, 42, 43};

    /** Gorev menusu: haftalik gorevler ust satirda, gunluk gorevler alt satirda */
    private static final int[] HAFTALIK_SLOTLAR = {9, 10, 11, 12, 13, 14, 15, 16, 17};
    private static final int[] GUNLUK_SLOTLAR = {27, 28, 29, 30, 31, 32, 33, 34, 35};

    /** Pass seviyesi: menude gorunen ad, simge ve odul. */
    private record Seviye(String ad, Material simge, Odul odul) {
    }

    private final Map<String, Gorev> havuz = new LinkedHashMap<>();
    private final Map<String, Gorev> gunlukHavuz = new LinkedHashMap<>();
    private List<Gorev> gunluk = new ArrayList<>();
    /** Normal oyuncunun gordugu gorev sayilari (liste premium icin ekstralari da icerir) */
    private int haftalikTemel = 7;
    private int gunlukTemel = 3;
    private String aktifGun = "";
    private final Map<Integer, Seviye> seviyeler = new TreeMap<>();
    private final Map<Integer, Seviye> premiumSeviyeler = new TreeMap<>();
    /** Menude bir sayfada gorunen seviye sayisi: yatay yol (ustte normal, arada bosluk, altta premium) */
    private static final int SAYFA_SEVIYE = 9;
    private List<Gorev> haftalik = new ArrayList<>();
    private String aktifDonem = "";
    private ZoneId zone = ZoneId.systemDefault();
    private int seviyeXp = 100;
    private int maxSeviye = 0;
    /** Normal (ucretsiz) pass'in son seviyesi */
    private int normalMax = 0;
    private Veri veri;

    /** Oyuncularin koydugu bloklar (bellekte): koy-kir dongusuyle "blok kir" gorevi kasilmasin. */
    private final Map<UUID, java.util.Set<Long>> yerlestirilen = new java.util.HashMap<>();
    /** "Blok koy" gorevinde kredi alinmis konumlar: ayni noktaya koy-kir-koy ile kasilamaz. */
    private final Map<UUID, java.util.Set<Long>> sayilanKonumlar = new java.util.HashMap<>();

    // ------------------------------------------------------------------ yasam dongusu

    @Override
    public void onEnable() {
        saveDefaultConfig();
        configSurumKontrol();
        veri = new Veri(this);
        ayarlariOku();
        donemKontrol(false);
        Bukkit.getPluginManager().registerEvents(this, this);

        // Dakikada bir: sure gorevi + hafta degisimi kontrolu
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            donemKontrol(true);
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getGameMode() == GameMode.SPECTATOR) continue;
                ilerle(p, "SURE_DAKIKA", "HEPSI", 1);
            }
        }, 1200L, 1200L);

        // Otomatik kayit (5 dakikada bir)
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (veri.kirli) veri.kaydet();
        }, 6000L, 6000L);

        getLogger().info("GorevPass aktif. Görev havuzu: " + havuz.size()
                + ", pass seviyesi: " + maxSeviye + ", dönem: " + aktifDonem);
    }

    @Override
    public void onDisable() {
        if (veri != null) veri.kaydet();
    }

    // ------------------------------------------------------------------ ayarlar

    /** Config'in guncel surumu: eski config bulunursa yedeklenir, yenisi yazilir (elle silmek gerekmez). */
    private static final int CONFIG_SURUM = 3;

    private void configSurumKontrol() {
        reloadConfig();
        if (getConfig().getInt("config-surum", 0) >= CONFIG_SURUM) return;
        java.io.File dosya = new java.io.File(getDataFolder(), "config.yml");
        java.io.File yedek = new java.io.File(getDataFolder(), "config_eski_" + System.currentTimeMillis() + ".yml");
        if (dosya.exists() && !dosya.renameTo(yedek)) {
            getLogger().warning("Eski config yedeklenemedi, yeni config yazılmadı.");
            return;
        }
        saveDefaultConfig();
        reloadConfig();
        getLogger().warning("config.yml eski sürümdü: yeni ayarlar yazıldı. Eskisi yedeklendi: " + yedek.getName());
    }

    private void ayarlariOku() {
        reloadConfig();
        try {
            zone = ZoneId.of(getConfig().getString("zaman-dilimi", "Europe/Istanbul"));
        } catch (Exception ex) {
            zone = ZoneId.systemDefault();
            getLogger().warning("zaman-dilimi geçersiz, sistem saati kullanılıyor.");
        }
        seviyeXp = Math.max(1, getConfig().getInt("pass.seviye-xp", 100));

        havuz.clear();
        gorevleriOku(getConfig().getConfigurationSection("gorevler"), havuz, false);
        gunlukHavuz.clear();
        gorevleriOku(getConfig().getConfigurationSection("gunluk-gorevler"), gunlukHavuz, true);

        seviyeler.clear();
        maxSeviye = 0;
        normalMax = 0;
        ConfigurationSection ss = getConfig().getConfigurationSection("pass.seviyeler");
        if (ss != null) {
            for (String k : ss.getKeys(false)) {
                int no;
                try {
                    no = Integer.parseInt(k);
                } catch (NumberFormatException ex) {
                    continue;
                }
                if (no < 1) continue;
                ConfigurationSection s = ss.getConfigurationSection(k);
                if (s == null) continue;
                Material simge = Material.matchMaterial(s.getString("simge", "CHEST"));
                if (simge == null || simge.isAir()) simge = Material.CHEST;
                seviyeler.put(no, new Seviye(s.getString("ad", "Seviye " + no), simge,
                        Odul.oku(s.getConfigurationSection("odul"))));
                maxSeviye = Math.max(maxSeviye, no);
                normalMax = Math.max(normalMax, no);
            }
        }
        premiumSeviyeler.clear();
        ConfigurationSection ps = getConfig().getConfigurationSection("pass.premium-seviyeler");
        if (ps != null) {
            for (String k : ps.getKeys(false)) {
                int no;
                try {
                    no = Integer.parseInt(k);
                } catch (NumberFormatException ex) {
                    continue;
                }
                if (no < 1) continue;
                ConfigurationSection s = ps.getConfigurationSection(k);
                if (s == null) continue;
                Material simge = Material.matchMaterial(s.getString("simge", "CHEST"));
                if (simge == null || simge.isAir()) simge = Material.CHEST;
                premiumSeviyeler.put(no, new Seviye(s.getString("ad", "Premium " + no), simge,
                        Odul.oku(s.getConfigurationSection("odul"))));
                maxSeviye = Math.max(maxSeviye, no);
            }
        }
        haftaliklariSec();
        gunlukleriSec();
    }

    private void gorevleriOku(ConfigurationSection gs, Map<String, Gorev> hedefHavuz, boolean gunlukMu) {
        if (gs == null) return;
        for (String id : gs.getKeys(false)) {
            ConfigurationSection s = gs.getConfigurationSection(id);
            if (s == null) continue;
            String tur = s.getString("tur", "").toUpperCase(Locale.ROOT);
            if (!List.of("MOB_OLDUR", "BLOK_KIR", "BLOK_KOY", "BALIK_TUT", "OYUNCU_OLDUR", "SURE_DAKIKA").contains(tur)) {
                getLogger().warning("Görev atlandı (geçersiz tür '" + tur + "'): " + id);
                continue;
            }
            List<String> hedefler = new ArrayList<>();
            if (s.isList("hedef")) {
                for (String h : s.getStringList("hedef")) hedefler.add(h.toUpperCase(Locale.ROOT));
            } else if (s.isString("hedef")) {
                hedefler.add(s.getString("hedef", "").toUpperCase(Locale.ROOT));
            }
            Material simge = Material.matchMaterial(s.getString("simge", "PAPER"));
            if (simge == null || simge.isAir()) simge = Material.PAPER;
            int adet = Math.max(1, s.getInt("adet", 1));
            int xp = Math.max(0, s.getInt("xp", 10));
            hedefHavuz.put(id, new Gorev(id, s.getString("ad", id), tur, hedefler, adet, xp, simge,
                    Odul.oku(s.getConfigurationSection("odul")), gunlukMu));
        }
    }

    // ------------------------------------------------------------------ hafta / donem

    private String donemHesapla() {
        LocalDate bugun = LocalDate.now(zone);
        int yil = bugun.get(IsoFields.WEEK_BASED_YEAR);
        int hafta = bugun.get(IsoFields.WEEK_OF_WEEK_BASED_YEAR);
        return yil + "-W" + hafta + "-" + veri.tohum;
    }

    private String gunHesapla() {
        return LocalDate.now(zone) + "-" + veri.tohum;
    }

    /** Hafta/gun (ya da yoneticinin yenilemesi) degistiyse yeni gorevleri secer. */
    private void donemKontrol(boolean duyur) {
        String yeni = donemHesapla();
        if (!yeni.equals(aktifDonem)) {
            aktifDonem = yeni;
            haftaliklariSec();
            if (duyur) {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    msj(p, "&aHaftalık görevler yenilendi! &7/quests");
                    p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.5f);
                }
            }
        }
        String yeniGun = gunHesapla();
        if (!yeniGun.equals(aktifGun)) {
            aktifGun = yeniGun;
            gunlukleriSec();
            if (duyur) {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    msj(p, "&aGünlük görevler yenilendi! &7/quests");
                }
            }
        }
    }

    /** Gunluk gorevler: her gun herkes icin ayni (tohum gunden gelir). */
    private void gunlukleriSec() {
        List<String> idler = new ArrayList<>(gunlukHavuz.keySet());
        Collections.sort(idler);
        Collections.shuffle(idler, new Random(("gun" + aktifGun).hashCode()));
        gunlukTemel = Math.max(0, getConfig().getInt("gunluk-gorev-sayisi", 3));
        int ekstra = Math.max(0, getConfig().getInt("premium-ekstra-gunluk", 1));
        int n = Math.min(gunlukTemel + ekstra, Math.min(GUNLUK_SLOTLAR.length, idler.size()));
        List<Gorev> secilen = new ArrayList<>();
        for (int i = 0; i < Math.max(0, n); i++) secilen.add(gunlukHavuz.get(idler.get(i)));
        gunluk = secilen;
    }

    /** Ayni donemde herkes ayni gorevleri gorur (tohum donemden gelir). */
    private void haftaliklariSec() {
        List<String> idler = new ArrayList<>(havuz.keySet());
        Collections.sort(idler);
        Collections.shuffle(idler, new Random(aktifDonem.hashCode()));
        haftalikTemel = Math.max(0, getConfig().getInt("haftalik-gorev-sayisi", 7));
        int ekstra = Math.max(0, getConfig().getInt("premium-ekstra-haftalik", 2));
        int n = Math.min(haftalikTemel + ekstra, Math.min(HAFTALIK_SLOTLAR.length, idler.size()));
        List<Gorev> secilen = new ArrayList<>();
        for (int i = 0; i < Math.max(0, n); i++) secilen.add(havuz.get(idler.get(i)));
        haftalik = secilen;
    }

    /** Oyuncunun verisi; hafta degistiyse ilerlemesi sifirlanir. */
    private Veri.Oyuncu oyuncu(UUID uuid) {
        Veri.Oyuncu o = veri.al(uuid);
        if (!aktifDonem.equals(o.donem)) {
            o.donem = aktifDonem;
            o.ilerleme.clear();
            o.tamam.clear();
            veri.kirli = true;
        }
        if (!aktifGun.equals(o.gunDonem)) {
            o.gunDonem = aktifGun;
            o.gunIlerleme.clear();
            o.gunTamam.clear();
            veri.kirli = true;
        }
        return o;
    }

    /** Oyuncunun gorecegi haftalik gorevler: premium (ve yetkili) ekstra gorevleri de gorur. */
    private List<Gorev> haftalikFor(boolean prem) {
        return prem ? haftalik : haftalik.subList(0, Math.min(haftalikTemel, haftalik.size()));
    }

    private List<Gorev> gunlukFor(boolean prem) {
        return prem ? gunluk : gunluk.subList(0, Math.min(gunlukTemel, gunluk.size()));
    }

    private long gunYenilenmeyeKalan() {
        ZonedDateTime simdi = ZonedDateTime.now(zone);
        ZonedDateTime sonraki = simdi.toLocalDate().plusDays(1).atStartOfDay(zone);
        return Math.max(0, sonraki.toInstant().toEpochMilli() - simdi.toInstant().toEpochMilli());
    }

    private long yenilenmeyeKalan() {
        ZonedDateTime simdi = ZonedDateTime.now(zone);
        ZonedDateTime sonraki = simdi.toLocalDate()
                .with(TemporalAdjusters.next(DayOfWeek.MONDAY)).atStartOfDay(zone);
        return Math.max(0, sonraki.toInstant().toEpochMilli() - simdi.toInstant().toEpochMilli());
    }

    // ------------------------------------------------------------------ yardimcilar

    private static Component c(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s)
                .decoration(TextDecoration.ITALIC, false);
    }

    private void msj(CommandSender s, String metin) {
        s.sendMessage(c("&8[&dGörev&8] &r" + metin));
    }

    static String sure(long ms) {
        long g = ms / 86_400_000L;
        long s = (ms % 86_400_000L) / 3_600_000L;
        long dk = (ms % 3_600_000L) / 60_000L;
        if (g > 0) return g + "g " + s + "s " + dk + "dk";
        if (s > 0) return s + "s " + dk + "dk";
        return Math.max(1, dk) + "dk";
    }

    private static String bar(long simdiki, long hedef) {
        int dolu = hedef <= 0 ? 10 : (int) Math.round(10.0 * Math.min(simdiki, hedef) / hedef);
        return "&a" + "█".repeat(dolu) + "&7" + "█".repeat(10 - dolu);
    }

    /** TagSistemi'nin yansima ile cagirdigi deger: oyuncunun pass seviyesi. Adini/imzasini degistirme. */
    public int passSeviye(UUID uuid) {
        int sev = seviyeOf(oyuncu(uuid).xp);
        return premiumAcik(uuid) ? sev : Math.min(sev, normalMax);
    }

    /** TagSistemi'nin yansima ile cagirdigi deger: oyuncuda premium pass var mi. */
    public boolean passPremium(UUID uuid) {
        return premiumAcik(uuid);
    }

    /** Oyuncuda premium var mi: yetkili (gorevpass.admin) her zaman premium acik sayilir. */
    private boolean premiumAcik(UUID uuid) {
        if (oyuncu(uuid).premium) return true;
        Player p = Bukkit.getPlayer(uuid);
        return p != null && p.hasPermission(ADMIN);
    }

    /** TagSistemi'nin yansima ile cagirdigi deger: bu oyuncunun gorecegi son seviye (30 normal, 40 premium). */
    public int passMaxFor(UUID uuid) {
        return premiumAcik(uuid) ? maxSeviye : normalMax;
    }

    /** TagSistemi'nin yansima ile cagirdigi deger: en yuksek pass seviyesi. */
    public int passMax() {
        return maxSeviye;
    }

    private int seviyeOf(long xp) {
        return (int) Math.min(maxSeviye, Math.max(0, xp / seviyeXp));
    }

    private ItemStack esya(Material mat, String ad, boolean parla, List<String> lore) {
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        if (m != null) {
            m.displayName(c(ad));
            List<Component> l = new ArrayList<>();
            for (String s : lore) l.add(c(s));
            m.lore(l);
            if (parla) m.setEnchantmentGlintOverride(true);
            it.setItemMeta(m);
        }
        return it;
    }

    private void aciklamaEkle(List<String> lore, Odul odul) {
        if (odul.aciklama != null && !odul.aciklama.isBlank()) lore.add("&7Ödül: " + odul.aciklama);
    }

    // ------------------------------------------------------------------ ilerleme

    private void ilerle(Player p, String tur, String hedef, int miktar) {
        if (miktar <= 0) return;
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return;   // hile olmasin

        Veri.Oyuncu o = oyuncu(p.getUniqueId());
        boolean prem = premiumAcik(p.getUniqueId());
        List<Gorev> hepsi = new ArrayList<>(haftalikFor(prem));
        hepsi.addAll(gunlukFor(prem));
        for (Gorev g : hepsi) {
            Set<String> tamamSet = g.gunluk ? o.gunTamam : o.tamam;
            Map<String, Integer> ilerSet = g.gunluk ? o.gunIlerleme : o.ilerleme;
            if (!g.tur.equals(tur) || tamamSet.contains(g.id) || !g.hedefUyar(hedef)) continue;
            int yeni = Math.min(g.adet, ilerSet.getOrDefault(g.id, 0) + miktar);
            ilerSet.put(g.id, yeni);
            veri.kirli = true;
            if (yeni >= g.adet) tamamla(p, o, g);
        }
    }

    private void tamamla(Player p, Veri.Oyuncu o, Gorev g) {
        if (!(g.gunluk ? o.gunTamam : o.tamam).add(g.id)) return;
        veri.kirli = true;
        p.sendMessage(c("&8[&dGörev&8] &a✔ " + (g.gunluk ? "Günlük" : "Haftalık") + " görev tamamlandı: &r" + g.ad + " &8(&d+" + g.xp + " XP&8)"));
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.3f);
        if (!g.odul.bosMu()) g.odul.ver(p, this);
        xpEkle(p.getUniqueId(), g.xp);
    }

    /** XP ekler/cikarir; oyuncu cevrimiciyse seviye atladigini bildirir. */
    private void xpEkle(UUID uuid, long miktar) {
        Veri.Oyuncu o = oyuncu(uuid);
        int eski = seviyeOf(o.xp);
        o.xp = Math.max(0, o.xp + miktar);
        veri.kirli = true;
        int yeni = seviyeOf(o.xp);
        Player p = Bukkit.getPlayer(uuid);
        if (p != null && yeni > eski) {
            msj(p, "&d&lSeviye atladın! &7Pass seviyesi: &f" + yeni + " &8| &7Ödülünü al: &f/pass");
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
        }
    }

    // ------------------------------------------------------------------ olaylar

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onOldur(EntityDeathEvent e) {
        LivingEntity olen = e.getEntity();
        if (olen instanceof ArmorStand) return;
        Player katil = olen.getKiller();
        if (katil == null) return;
        if (olen instanceof Player kurban) {
            if (!kurban.getUniqueId().equals(katil.getUniqueId())) ilerle(katil, "OYUNCU_OLDUR", "HEPSI", 1);
        } else {
            ilerle(katil, "MOB_OLDUR", olen.getType().name(), 1);
        }
    }

    /** Blok konumu icin dunya basina tekil anahtar (x, z 26 bit, y 12 bit). */
    private static long blokAnahtar(org.bukkit.block.Block b) {
        return ((long) (b.getX() & 0x3FFFFFF) << 38) | ((long) (b.getZ() & 0x3FFFFFF) << 12) | (b.getY() & 0xFFF);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onKir(BlockBreakEvent e) {
        java.util.Set<Long> koyulanlar = yerlestirilen.get(e.getBlock().getWorld().getUID());
        // oyuncunun kendi koydugu blok sayilmaz (bir kereye mahsus)
        if (koyulanlar != null && koyulanlar.remove(blokAnahtar(e.getBlock()))) return;
        ilerle(e.getPlayer(), "BLOK_KIR", e.getBlock().getType().name(), 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onKoy(BlockPlaceEvent e) {
        java.util.Set<Long> koyulanlar = yerlestirilen.computeIfAbsent(
                e.getBlockPlaced().getWorld().getUID(), k -> new java.util.HashSet<>());
        if (koyulanlar.size() > 200_000) koyulanlar.clear();      // bellek sinirla
        long anahtar = blokAnahtar(e.getBlockPlaced());
        koyulanlar.add(anahtar);

        java.util.Set<Long> sayilan = sayilanKonumlar.computeIfAbsent(
                e.getBlockPlaced().getWorld().getUID(), k -> new java.util.HashSet<>());
        if (sayilan.size() > 200_000) sayilan.clear();
        if (sayilan.add(anahtar)) {                                // her konum yalnizca bir kez sayilir
            ilerle(e.getPlayer(), "BLOK_KOY", e.getBlockPlaced().getType().name(), 1);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onBalik(PlayerFishEvent e) {
        if (e.getState() != PlayerFishEvent.State.CAUGHT_FISH) return;
        String hedef = "HEPSI";
        Entity yakalanan = e.getCaught();
        if (yakalanan instanceof Item it) hedef = it.getItemStack().getType().name();
        ilerle(e.getPlayer(), "BALIK_TUT", hedef, 1);
    }

    @EventHandler
    public void onCik(PlayerQuitEvent e) {
        if (veri.kirli) veri.kaydet();
    }

    // ------------------------------------------------------------------ menuler

    private static final int[] GOREV_ALT = {45, 46, 47, 48, 50, 51, 52};

    private void gorevMenuAc(Player p) {
        donemKontrol(false);
        Veri.Oyuncu o = oyuncu(p.getUniqueId());

        PassMenu menu = new PassMenu(PassMenu.Tip.GOREV, 1);
        Inventory inv = Bukkit.createInventory(menu, 54, c("&0&lGÖREVLER"));
        menu.setInventory(inv);

        ItemStack cam = esya(Material.GRAY_STAINED_GLASS_PANE, " ", false, List.of());
        for (int s : GOREV_ALT) inv.setItem(s, cam);
        inv.setItem(49, passBilgi(o, premiumAcik(p.getUniqueId())));
        inv.setItem(53, esya(Material.EXPERIENCE_BOTTLE, "&d&lBattle Pass &7»", false,
                List.of("&7Seviye ödüllerini görmek için tıkla.")));

        boolean prem = premiumAcik(p.getUniqueId());
        inv.setItem(4, esya(Material.CLOCK, "&6&lHAFTALIK GÖREVLER", false, List.of(
                "&7Daha zor, daha çok XP.",
                prem ? "&6★ Premium: +" + (haftalikFor(true).size() - haftalikFor(false).size()) + " ekstra görev" : "&7Premium ile daha fazla görev",
                "", "&7Yenilenmesine: &f" + sure(yenilenmeyeKalan()))));
        inv.setItem(22, esya(Material.SUNFLOWER, "&a&lGÜNLÜK GÖREVLER", false, List.of(
                "&7Kolay, az XP.",
                prem ? "&6★ Premium: +" + (gunlukFor(true).size() - gunlukFor(false).size()) + " ekstra görev" : "&7Premium ile daha fazla görev",
                "", "&7Yenilenmesine: &f" + sure(gunYenilenmeyeKalan()))));
        gorevleriKoy(inv, o, haftalikFor(prem), HAFTALIK_SLOTLAR, "&6[Haftalık] ");
        gorevleriKoy(inv, o, gunlukFor(prem), GUNLUK_SLOTLAR, "&a[Günlük] ");
        if (haftalik.isEmpty()) {
            inv.setItem(13, esya(Material.BARRIER, "&cBu hafta görev yok", false,
                    List.of("&7Yönetici config.yml'ye görev eklemeli.")));
        }
        p.openInventory(inv);
    }

    private void gorevleriKoy(Inventory inv, Veri.Oyuncu o, List<Gorev> liste, int[] slotlar, String onEk) {
        for (int i = 0; i < liste.size() && i < slotlar.length; i++) {
            Gorev g = liste.get(i);
            int simdiki = (g.gunluk ? o.gunIlerleme : o.ilerleme).getOrDefault(g.id, 0);
            boolean bitti = (g.gunluk ? o.gunTamam : o.tamam).contains(g.id);
            List<String> lore = new ArrayList<>();
            lore.add("&7" + g.tanim());
            lore.add("");
            lore.add(bar(bitti ? g.adet : simdiki, g.adet) + " &f" + (bitti ? g.adet : simdiki) + "&7/&f" + g.adet);
            lore.add("&7Pass XP: &d+" + g.xp);
            aciklamaEkle(lore, g.odul);
            lore.add("");
            lore.add(bitti ? "&a✔ Tamamlandı" : "&eDevam ediyor...");
            inv.setItem(slotlar[i], esya(g.simge, onEk + "&r" + g.ad, bitti, lore));
        }
    }

    private ItemStack passBilgi(Veri.Oyuncu o, boolean prem) {
        int tavan = prem ? maxSeviye : normalMax;
        int sev = Math.min(seviyeOf(o.xp), tavan);
        List<String> lore = new ArrayList<>();
        lore.add("&7Seviye: &f" + sev + "&7/&f" + tavan);
        lore.add(prem ? "&6★ Premium pass: aktif" : "&7Premium pass: yok");
        if (sev < tavan) {
            long buSeviyede = o.xp % seviyeXp;
            lore.add(bar(buSeviyede, seviyeXp) + " &f" + buSeviyede + "&7/&f" + seviyeXp + " XP");
        } else {
            lore.add("&6Maksimum seviyedesin!");
        }
        lore.add("");
        lore.add("&7Görevler yenilenmesine: &f" + sure(yenilenmeyeKalan()));
        return esya(Material.NETHER_STAR, "&d&lBattle Pass", false, lore);
    }

    /** Seviye indeksi (0-8) -> normal odul slotu (2. satir). Arada bos satir, altta premium (4. satir). */
    private static int normalSlot(int i) {
        return 9 + i;
    }

    private static int premiumSlot(int i) {
        return 27 + i;
    }

    private void passMenuAc(Player p, int sayfa) {
        donemKontrol(false);
        Veri.Oyuncu o = oyuncu(p.getUniqueId());
        int sayfaSayisi = Math.max(1, (int) Math.ceil(maxSeviye / (double) SAYFA_SEVIYE));
        sayfa = Math.max(1, Math.min(sayfa, sayfaSayisi));

        boolean prem = premiumAcik(p.getUniqueId());
        PassMenu menu = new PassMenu(PassMenu.Tip.PASS, sayfa);
        Inventory inv = Bukkit.createInventory(menu, 54, c("&0&lBATTLE PASS &8(" + sayfa + "/" + sayfaSayisi + ")"));
        menu.setInventory(inv);

        ItemStack cam = esya(Material.GRAY_STAINED_GLASS_PANE, " ", false, List.of());
        for (int s = 0; s < 9; s++) inv.setItem(s, cam);
        for (int s = 36; s < 54; s++) inv.setItem(s, cam);
        inv.setItem(51, esya(Material.PAPER, "&7Bilgi", false, List.of(
                "&7Üst yol: &fNormal pass",
                "&7Alt yol: &6Premium pass",
                "&7Oklarla sağa/sola ilerle.",
                prem ? "&6★ Premium pass sende aktif" : "&cPremium pass yok &7(yetkiliden alınır)")));
        inv.setItem(49, passBilgi(o, prem));
        inv.setItem(47, esya(Material.BOOK, "&e« Görevler", false, List.of("&7Haftalık görevlere dön.")));
        if (sayfa > 1) inv.setItem(45, esya(Material.ARROW, "&eÖnceki sayfa", false, List.of()));
        if (sayfa < sayfaSayisi) inv.setItem(53, esya(Material.ARROW, "&eSonraki sayfa", false, List.of()));

        int sev = seviyeOf(o.xp);
        for (int i = 0; i < SAYFA_SEVIYE; i++) {
            int no = (sayfa - 1) * SAYFA_SEVIYE + i + 1;

            Seviye s = seviyeler.get(no);
            if (s != null) {
                List<String> lore = new ArrayList<>();
                aciklamaEkle(lore, s.odul());
                lore.add("");
                ItemStack it;
                if (o.alinan.contains(no)) {
                    lore.add("&8Ödül alındı");
                    it = esya(Material.GRAY_STAINED_GLASS_PANE, "&8Seviye " + no + " &7(alındı)", false, lore);
                } else if (sev >= no) {
                    lore.add("&a▶ Tıkla ve ödülü al!");
                    it = esya(s.simge(), "&a&lSeviye " + no + " &r" + s.ad(), true, lore);
                } else {
                    lore.add("&cKilitli &7- gereken: &f" + (long) no * seviyeXp + " XP");
                    it = esya(s.simge(), "&cSeviye " + no + " &r" + s.ad(), false, lore);
                }
                inv.setItem(normalSlot(i), it);
            }

            Seviye ps = premiumSeviyeler.get(no);
            if (ps != null) {
                List<String> lore = new ArrayList<>();
                aciklamaEkle(lore, ps.odul());
                lore.add("");
                ItemStack it;
                if (!prem) {
                    lore.add("&6★ Premium pass gerekli");
                    lore.add("&7Yetkiliden premium pass alabilirsin.");
                    it = esya(Material.LIGHT_GRAY_STAINED_GLASS_PANE, "&6★ Premium " + no + " &r" + ps.ad(), false, lore);
                } else if (o.premiumAlinan.contains(no)) {
                    lore.add("&8Ödül alındı");
                    it = esya(Material.GRAY_STAINED_GLASS_PANE, "&8Premium " + no + " &7(alındı)", false, lore);
                } else if (sev >= no) {
                    lore.add("&a▶ Tıkla ve ödülü al!");
                    it = esya(ps.simge(), "&6&l★ Premium " + no + " &r" + ps.ad(), true, lore);
                } else {
                    lore.add("&cKilitli &7- gereken: &f" + (long) no * seviyeXp + " XP");
                    it = esya(ps.simge(), "&6★ Premium " + no + " &r" + ps.ad(), false, lore);
                }
                inv.setItem(premiumSlot(i), it);
            }
        }
        p.openInventory(inv);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof PassMenu) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof PassMenu menu)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || !e.getClickedInventory().equals(e.getInventory())) return;
        int slot = e.getRawSlot();

        if (menu.tip == PassMenu.Tip.GOREV) {
            if (slot == 53) Bukkit.getScheduler().runTask(this, () -> passMenuAc(p, 1));
            return;
        }

        // pass menusu
        if (slot == 47) {
            Bukkit.getScheduler().runTask(this, () -> gorevMenuAc(p));
            return;
        }
        if (slot == 45) {
            Bukkit.getScheduler().runTask(this, () -> passMenuAc(p, menu.sayfa - 1));
            return;
        }
        if (slot == 53) {
            Bukkit.getScheduler().runTask(this, () -> passMenuAc(p, menu.sayfa + 1));
            return;
        }
        int sutun;
        boolean premium;
        if (slot >= 9 && slot <= 17) {
            sutun = slot - 9;
            premium = false;
        } else if (slot >= 27 && slot <= 35) {
            sutun = slot - 27;
            premium = true;
        } else {
            return;
        }
        int no = (menu.sayfa - 1) * SAYFA_SEVIYE + sutun + 1;
        if (premium) premiumSeviyeAl(p, no, menu.sayfa);
        else seviyeAl(p, no, menu.sayfa);
    }

    private void seviyeAl(Player p, int no, int sayfa) {
        Seviye s = seviyeler.get(no);
        if (s == null) return;
        Veri.Oyuncu o = oyuncu(p.getUniqueId());
        if (seviyeOf(o.xp) < no) {
            msj(p, "&cBu seviye için yeterli XP'n yok.");
            return;
        }
        if (!o.alinan.add(no)) {                    // zaten alinmissa false doner
            msj(p, "&7Bu seviyenin ödülünü zaten aldın.");
            return;
        }
        veri.kirli = true;
        s.odul().ver(p, this);
        msj(p, "&aSeviye " + no + " ödülü alındı!");
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
        Bukkit.getScheduler().runTask(this, () -> passMenuAc(p, sayfa));
    }

    private void premiumSeviyeAl(Player p, int no, int sayfa) {
        Seviye s = premiumSeviyeler.get(no);
        if (s == null) return;
        Veri.Oyuncu o = oyuncu(p.getUniqueId());
        if (!premiumAcik(p.getUniqueId())) {
            msj(p, "&6★ Bu ödül için premium battle pass gerekli. &7Yetkiliden alabilirsin.");
            return;
        }
        if (seviyeOf(o.xp) < no) {
            msj(p, "&cBu seviye için yeterli XP'n yok.");
            return;
        }
        if (!o.premiumAlinan.add(no)) {
            msj(p, "&7Bu premium ödülünü zaten aldın.");
            return;
        }
        veri.kirli = true;
        s.odul().ver(p, this);
        msj(p, "&6★ Premium seviye " + no + " ödülü alındı!");
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.2f);
        Bukkit.getScheduler().runTask(this, () -> passMenuAc(p, sayfa));
    }

    // ------------------------------------------------------------------ komutlar

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd,
                             @NotNull String label, @NotNull String[] args) {
        String ad = cmd.getName().toLowerCase();
        if (ad.equals("questadmin")) {
            adminKomut(sender, args);
            return true;
        }
        if (!(sender instanceof Player p)) {
            msj(sender, "&cBu komut sadece oyuncular için.");
            return true;
        }
        switch (ad) {
            case "quests" -> gorevMenuAc(p);
            case "pass" -> passMenuAc(p, 1);
            default -> {
                return false;
            }
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command cmd,
                                      @NotNull String alias, @NotNull String[] args) {
        if (!cmd.getName().equalsIgnoreCase("questadmin") || !sender.hasPermission(ADMIN)) return List.of();
        List<String> adaylar = new ArrayList<>();
        if (args.length == 1) {
            adaylar.addAll(List.of("refresh", "xp", "premium", "reset", "info", "reload"));
        } else if (args.length == 2 && args[0].equalsIgnoreCase("premium")) {
            adaylar.addAll(List.of("give", "take"));
        } else if (args.length == 2 && args[0].equalsIgnoreCase("xp")) {
            adaylar.addAll(List.of("give", "take", "set"));
        } else if ((args.length == 2 && List.of("sifirla", "bilgi", "reset", "info").contains(args[0].toLowerCase()))
                || (args.length == 3 && (args[0].equalsIgnoreCase("xp") || args[0].equalsIgnoreCase("premium")))) {
            for (Player p : Bukkit.getOnlinePlayers()) adaylar.add(p.getName());
        }
        String son = args.length == 0 ? "" : args[args.length - 1].toLowerCase();
        adaylar.removeIf(s -> !s.toLowerCase().startsWith(son));
        return adaylar;
    }

    private static long sayiOku(String s) {
        try {
            return Long.parseLong(s.trim());
        } catch (NumberFormatException e) {
            return Long.MIN_VALUE;
        }
    }

    private void adminKomut(CommandSender sender, String[] args) {
        if (!sender.hasPermission(ADMIN)) {
            msj(sender, "&cYetkin yok.");
            return;
        }
        if (args.length == 0) {
            msj(sender, "&8/questadmin refresh &7- görevleri yeniden seç, herkesin ilerlemesini sıfırla");
            msj(sender, "&8/questadmin xp <give|take|set> <oyuncu> <miktar>");
            msj(sender, "&8/questadmin premium <give|take> <oyuncu> &7- premium battle pass ver/al");
            msj(sender, "&8/questadmin reset <oyuncu> &7- XP, ilerleme ve alınan ödüller");
            msj(sender, "&8/questadmin info <oyuncu> &7| &8/questadmin reload");
            return;
        }
        switch (args[0].toLowerCase()) {
            case "refresh", "yenile" -> {
                veri.tohum++;
                veri.kirli = true;
                donemKontrol(true);
                veri.kaydet();
                msj(sender, "&aGörevler yenilendi. Bu haftaki görev sayısı: &f" + haftalik.size());
            }
            case "xp" -> {
                if (args.length < 4) {
                    msj(sender, "&cKullanım: /questadmin xp <give|take|set> <oyuncu> <miktar>");
                    return;
                }
                long miktar = sayiOku(args[3]);
                if (miktar < 0 || miktar > 10_000_000L) {
                    msj(sender, "&cMiktar 0 - 10.000.000 arasında bir tam sayı olmalı.");
                    return;
                }
                UUID id = Bukkit.getOfflinePlayer(args[2]).getUniqueId();
                Veri.Oyuncu o = oyuncu(id);
                switch (args[1].toLowerCase()) {
                    case "give", "ver" -> xpEkle(id, miktar);
                    case "take", "al" -> xpEkle(id, -miktar);
                    case "set", "ayarla" -> xpEkle(id, miktar - o.xp);
                    default -> {
                        msj(sender, "&cgive, take ya da set yaz.");
                        return;
                    }
                }
                veri.kaydet();
                msj(sender, "&f" + args[2] + " &7yeni XP: &d" + oyuncu(id).xp
                        + " &8(seviye " + seviyeOf(oyuncu(id).xp) + ")");
            }
            case "reset", "sifirla" -> {
                if (args.length < 2) {
                    msj(sender, "&cKullanım: /questadmin reset <oyuncu>");
                    return;
                }
                UUID id = Bukkit.getOfflinePlayer(args[1]).getUniqueId();
                Veri.Oyuncu o = oyuncu(id);
                o.xp = 0;
                o.ilerleme.clear();
                o.tamam.clear();
                o.gunIlerleme.clear();
                o.gunTamam.clear();
                o.alinan.clear();
                o.premiumAlinan.clear();
                veri.kaydet();
                msj(sender, "&f" + args[1] + " &7oyuncusunun pass verisi sıfırlandı.");
            }
            case "premium" -> {
                if (args.length < 3) {
                    msj(sender, "&cKullanım: /questadmin premium <give|take> <oyuncu>");
                    return;
                }
                boolean ver;
                switch (args[1].toLowerCase()) {
                    case "give", "ver" -> ver = true;
                    case "take", "al" -> ver = false;
                    default -> {
                        msj(sender, "&cgive ya da take yaz.");
                        return;
                    }
                }
                OfflinePlayer hedef = Bukkit.getOfflinePlayer(args[2]);
                Veri.Oyuncu o = oyuncu(hedef.getUniqueId());
                o.premium = ver;
                veri.kirli = true;
                veri.kaydet();
                msj(sender, ver ? "&f" + args[2] + " &7oyuncusuna &6premium battle pass &7verildi."
                        : "&f" + args[2] + " &7oyuncusundan premium pass alındı.");
                Player hp = hedef.getPlayer();
                if (hp != null && ver) msj(hp, "&6★ Premium Battle Pass sende aktif! &7/pass");
            }
            case "info", "bilgi" -> {
                if (args.length < 2) {
                    msj(sender, "&cKullanım: /questadmin info <oyuncu>");
                    return;
                }
                OfflinePlayer hedef = Bukkit.getOfflinePlayer(args[1]);
                Veri.Oyuncu o = oyuncu(hedef.getUniqueId());
                msj(sender, "&f" + args[1] + " &7XP: &d" + o.xp + " &8| &7seviye: &f" + seviyeOf(o.xp)
                        + " &8| &7premium: " + (o.premium ? "&6var" : "&cyok") + (hedef.isOnline() && hedef.getPlayer().hasPermission(ADMIN) ? " &8(yetkili: her zaman açık)" : "")
                        + " &8| &7alınan ödül: &f" + o.alinan.size() + "&7+&6" + o.premiumAlinan.size()
                        + " &8| &7biten görev: &f" + o.tamam.size() + "&7/&f" + haftalik.size());
            }
            case "reload" -> {
                veri.kaydet();
                ayarlariOku();
                donemKontrol(false);
                msj(sender, "&aAyarlar yüklendi. Görev havuzu: &f" + havuz.size()
                        + " &7| pass seviyesi: &f" + maxSeviye);
            }
            default -> msj(sender, "&cBilinmeyen alt komut. &7/questadmin");
        }
    }
}
