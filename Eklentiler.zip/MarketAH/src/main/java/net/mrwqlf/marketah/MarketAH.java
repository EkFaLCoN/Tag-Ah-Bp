package net.mrwqlf.marketah;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class MarketAH extends JavaPlugin implements Listener {

    private Ekonomi ekonomi;
    private Depo depo;

    private static final int SAYFA_BOYUT = 45;

    // ------------------------------------------------------------------ yasam dongusu

    @Override
    public void onEnable() {
        saveDefaultConfig();
        Coin.ANAHTAR = new org.bukkit.NamespacedKey(this, "coin");
        ekonomi = new Ekonomi(this);
        depo = new Depo(this);
        Bukkit.getPluginManager().registerEvents(this, this);

        // Suresi dolan ilanlari kontrol et (5 saniyede bir)
        Bukkit.getScheduler().runTaskTimer(this, this::sureKontrol, 100L, 100L);
        // Coin taramasi: envantere giren coin aninda paraya donusur
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (!getConfig().getBoolean("coin-sistemi", true)) return;
            for (Player p : Bukkit.getOnlinePlayers()) coinleriBozdur(p);
        }, 20L, 10L);

        // Otomatik kayit (5 dakikada bir)
        Bukkit.getScheduler().runTaskTimer(this, this::kaydet, 6000L, 6000L);

        getLogger().info("MarketAH aktif. İlan sayısı: " + depo.hepsi().size());
    }

    @Override
    public void onDisable() {
        kaydet();
    }

    private void kaydet() {
        ekonomi.kaydet();
        depo.kaydet();
    }

    // ------------------------------------------------------------------ disariya acik (TagSistemi tabelasi okur)

    /** Oyuncunun bakiyesi. TagSistemi bunu yansima ile cagirir; adini/imzasini degistirme. */
    public double bakiye(UUID uuid) {
        return ekonomi.bakiye(uuid);
    }

    /** Parayi birimiyle biçimler (ornek: 12.500 TL). TagSistemi yansima ile cagirir. */
    public String bicim(double miktar) {
        return ekonomi.bicim(miktar);
    }

    // ------------------------------------------------------------------ yardimcilar

    private static Component c(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s)
                .decoration(TextDecoration.ITALIC, false);
    }

    private void msj(CommandSender s, String metin) {
        s.sendMessage(c("&8[&6Market&8] &r" + metin));
    }

    /** Esyayi envantere koy, yer yoksa posta kutusuna at. */
    private void esyaVer(Player p, ItemStack item) {
        var artan = p.getInventory().addItem(item);
        if (!artan.isEmpty()) {
            for (ItemStack kalan : artan.values()) depo.kutuyaKoy(p.getUniqueId(), kalan.serializeAsBytes());
            msj(p, "&eEnvanterin dolu, eşya &6/ahbox&e içine konuldu.");
        }
    }

    private void esyaVerOfflineDahil(UUID uuid, ItemStack item) {
        Player p = Bukkit.getPlayer(uuid);
        if (p != null && p.isOnline()) esyaVer(p, item);
        else depo.kutuyaKoy(uuid, item.serializeAsBytes());
    }

    private String isim(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        if (meta != null && meta.hasDisplayName()) {
            return LegacyComponentSerializer.legacyAmpersand().serialize(meta.displayName());
        }
        String t = item.getType().name().toLowerCase().replace('_', ' ');
        return Character.toUpperCase(t.charAt(0)) + t.substring(1);
    }

    private double minArtis(double mevcut) {
        double yuzde = getConfig().getDouble("acik-artirma.min-artis-yuzde", 5.0);
        double sabit = getConfig().getDouble("acik-artirma.min-artis-sabit", 10.0);
        return Ekonomi.yuvarla(Math.max(mevcut * yuzde / 100.0, sabit));
    }

    // ------------------------------------------------------------------ sure kontrolu

    private void sureKontrol() {
        long simdi = System.currentTimeMillis();
        List<Ilan> bitenler = new ArrayList<>();
        for (Ilan i : depo.hepsi().values()) if (i.suresiDoldu(simdi)) bitenler.add(i);
        if (bitenler.isEmpty()) return;

        for (Ilan i : bitenler) {
            depo.sil(i.id);
            if (i.acikArtirma && i.teklifVar()) {
                double komisyon = getConfig().getDouble("komisyon", 5.0);
                double net = Ekonomi.yuvarla(i.fiyat * (1 - komisyon / 100.0));
                ekonomi.ekle(i.satici, net);
                esyaVerOfflineDahil(i.enYuksek, i.item());

                Player kazanan = Bukkit.getPlayer(i.enYuksek);
                if (kazanan != null) msj(kazanan, "&aAçık artırmayı kazandın: &f" + isim(i.item())
                        + " &7(" + ekonomi.bicim(i.fiyat) + ")");
                Player satici = Bukkit.getPlayer(i.satici);
                if (satici != null) msj(satici, "&aEşyan satıldı: &f" + isim(i.item())
                        + " &7-> " + ekonomi.bicim(net) + " (komisyon %" + komisyon + ")");
            } else {
                // teklif gelmedi veya sabit ilan suresi doldu
                esyaVerOfflineDahil(i.satici, i.item());
                Player satici = Bukkit.getPlayer(i.satici);
                if (satici != null) msj(satici, "&eİlanının süresi doldu, eşyan &6/ahbox&e içinde.");
            }
        }
        depo.kaydet();
    }

    // ------------------------------------------------------------------ GUI

    private void marketAc(Player p, int sayfa) {
        List<Ilan> liste = depo.siraliListe();
        menuAc(p, Menu.Tip.MARKET, sayfa, liste, "&0&lAH &8(%d/%d)");
    }

    private void ilanlarimAc(Player p, int sayfa) {
        List<Ilan> liste = depo.oyuncununIlanlari(p.getUniqueId());
        menuAc(p, Menu.Tip.ILANLARIM, sayfa, liste, "&0&lAH &8İlanlarım (%d/%d)");
    }

    private void menuAc(Player p, Menu.Tip tip, int sayfa, List<Ilan> liste, String baslikSablon) {
        int maxSayfa = Math.max(1, (int) Math.ceil(liste.size() / (double) SAYFA_BOYUT));
        sayfa = Math.max(1, Math.min(sayfa, maxSayfa));

        Menu menu = new Menu(tip, sayfa);
        Inventory inv = Bukkit.createInventory(menu, 54,
                c(String.format(baslikSablon, sayfa, maxSayfa)));
        menu.setInventory(inv);

        long simdi = System.currentTimeMillis();
        int bas = (sayfa - 1) * SAYFA_BOYUT;
        for (int s = 0; s < SAYFA_BOYUT && bas + s < liste.size(); s++) {
            Ilan ilan = liste.get(bas + s);
            ItemStack goster;
            try {
                goster = ilan.item().clone();
            } catch (Exception ex) {
                getLogger().warning("Okunamayan ilan atlandı: " + ilan.id + " (" + ex + ")");
                continue;
            }
            ItemMeta meta = goster.getItemMeta();
            if (meta != null) {
                List<Component> lore = new ArrayList<>();
                if (meta.hasLore() && meta.lore() != null) lore.addAll(meta.lore());
                lore.add(c("&8&m                    "));
                lore.add(c("&7Satıcı: &f" + ilan.saticiAdi));
                if (ilan.acikArtirma) {
                    lore.add(c("&7Tür: &6Açık Artırma"));
                    lore.add(c("&7Güncel teklif: &a" + ekonomi.bicim(ilan.fiyat)));
                    lore.add(c("&7En yüksek: &f" + (ilan.teklifVar() ? ilan.enYuksekAdi : "yok")));
                    lore.add(c("&7Kalan süre: &f" + ilan.kalanSure(simdi)));
                    if (tip == Menu.Tip.MARKET) {
                        double sonraki = Ekonomi.yuvarla(ilan.fiyat + minArtis(ilan.fiyat));
                        lore.add(c("&eSol tık: teklif ver (&a" + ekonomi.bicim(sonraki) + "&e)"));
                        lore.add(c("&7Farklı miktar: &f/ah bid"));
                    }
                } else {
                    lore.add(c("&7Tür: &bSabit Fiyat"));
                    lore.add(c("&7Fiyat: &a" + ekonomi.bicim(ilan.fiyat)));
                    lore.add(c("&7Kalan süre: &f" + ilan.kalanSure(simdi)));
                    if (tip == Menu.Tip.MARKET) lore.add(c("&eSol tık: satın al"));
                }
                if (tip == Menu.Tip.ILANLARIM) {
                    if (ilan.acikArtirma && ilan.teklifVar()) lore.add(c("&cTeklif almış ilan iptal edilemez"));
                    else lore.add(c("&cSağ tık: ilanı geri çek"));
                }
                meta.lore(lore);
                goster.setItemMeta(meta);
            }
            inv.setItem(s, goster);
            menu.slotIlan.put(s, ilan.id);
        }

        // alt bar
        if (sayfa > 1) inv.setItem(45, buton(Material.ARROW, "&eÖnceki sayfa"));
        if (sayfa < maxSayfa) inv.setItem(53, buton(Material.ARROW, "&eSonraki sayfa"));
        inv.setItem(49, buton(Material.GOLD_INGOT, "&6Bakiyen: &a" + ekonomi.bicim(ekonomi.bakiye(p.getUniqueId()))));
        inv.setItem(47, buton(Material.WRITABLE_BOOK, tip == Menu.Tip.ILANLARIM ? "&eMarkete don" : "&eİlanlarım"));
        inv.setItem(51, buton(Material.CHEST, "&ePosta kutusu &7(/ahbox)"));

        p.openInventory(inv);
    }

    private void kutuAc(Player p) {
        List<byte[]> liste = depo.kutu(p.getUniqueId());
        Menu menu = new Menu(Menu.Tip.KUTU, 1);
        Inventory inv = Bukkit.createInventory(menu, 54, c("&8Posta Kutusu"));
        menu.setInventory(inv);
        for (int i = 0; i < liste.size() && i < 45; i++) {
            inv.setItem(i, ItemStack.deserializeBytes(liste.get(i)));
            menu.slotKutu.put(i, i);
        }
        inv.setItem(49, buton(Material.PAPER, "&7Eşyaları almak için tıkla"));
        p.openInventory(inv);
    }

    private ItemStack buton(Material mat, String ad) {
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        if (m != null) {
            m.displayName(c(ad));
            it.setItemMeta(m);
        }
        return it;
    }

    // ------------------------------------------------------------------ tiklama

    /** Oyuncunun envanterindeki tum coinleri paraya cevirir. */
    private void coinleriBozdur(Player p) {
        var env = p.getInventory();
        long toplam = 0;
        int adetToplam = 0;
        Coin sonCoin = null;

        for (int i = 0; i < env.getSize(); i++) {
            ItemStack it = env.getItem(i);
            Coin coin = Coin.coinMi(it);
            if (coin == null) continue;
            int adet = it.getAmount();
            for (int k = 0; k < adet; k++) toplam += coin.rastgeleDeger();
            adetToplam += adet;
            sonCoin = coin;
            env.setItem(i, null);
        }
        if (toplam == 0) return;

        ekonomi.ekle(p.getUniqueId(), toplam);
        ekonomi.kaydet();
        p.sendMessage(c("&8[&6Coin&8] &r" + sonCoin.gorunum + " &8x" + adetToplam + " &a→ &f"
                + ekonomi.bicim(toplam)));
        p.playSound(p.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.4f);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof Menu) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof Menu menu)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || !e.getClickedInventory().equals(e.getInventory())) return;

        int slot = e.getRawSlot();

        // navigasyon
        if (slot == 45 && menu.tip != Menu.Tip.KUTU) {
            acSayfa(p, menu.tip, menu.sayfa - 1);
            return;
        }
        if (slot == 53 && menu.tip != Menu.Tip.KUTU) {
            acSayfa(p, menu.tip, menu.sayfa + 1);
            return;
        }
        if (slot == 47 && menu.tip != Menu.Tip.KUTU) {
            if (menu.tip == Menu.Tip.ILANLARIM) marketAc(p, 1);
            else ilanlarimAc(p, 1);
            return;
        }
        if (slot == 51 && menu.tip != Menu.Tip.KUTU) {
            kutuAc(p);
            return;
        }

        if (menu.tip == Menu.Tip.KUTU) {
            Integer idx = menu.slotKutu.get(slot);
            if (idx == null) return;
            List<byte[]> liste = depo.kutu(p.getUniqueId());
            if (idx >= liste.size()) return;
            ItemStack item = ItemStack.deserializeBytes(liste.get(idx.intValue()));
            if (p.getInventory().firstEmpty() == -1) {
                msj(p, "&cEnvanterinde yer yok.");
                return;
            }
            liste.remove(idx.intValue());
            p.getInventory().addItem(item);
            depo.kaydet();
            kutuAc(p);
            return;
        }

        UUID ilanId = menu.slotIlan.get(slot);
        if (ilanId == null) return;
        Ilan ilan = depo.al(ilanId);
        if (ilan == null) {
            msj(p, "&cBu ilan artık mevcut değil.");
            acSayfa(p, menu.tip, menu.sayfa);
            return;
        }

        if (menu.tip == Menu.Tip.ILANLARIM) {
            if (e.isRightClick()) geriCek(p, ilan, menu);
            return;
        }

        if (ilan.satici.equals(p.getUniqueId())) {
            msj(p, "&cKendi ilanına teklif veremezsin. &7(/ah mylistings)");
            return;
        }

        if (ilan.acikArtirma) teklifVer(p, ilan, menu);
        else satinAl(p, ilan, menu);
    }

    private void acSayfa(Player p, Menu.Tip tip, int sayfa) {
        if (tip == Menu.Tip.ILANLARIM) ilanlarimAc(p, sayfa);
        else marketAc(p, sayfa);
    }

    private void geriCek(Player p, Ilan ilan, Menu menu) {
        if (ilan.acikArtirma && ilan.teklifVar()) {
            msj(p, "&cTeklif almış açık artırma iptal edilemez.");
            return;
        }
        depo.sil(ilan.id);
        esyaVer(p, ilan.item());
        depo.kaydet();
        msj(p, "&aİlan geri çekildi.");
        ilanlarimAc(p, menu.sayfa);
    }

    private void satinAl(Player p, Ilan ilan, Menu menu) {
        if (!ekonomi.cek(p.getUniqueId(), ilan.fiyat)) {
            msj(p, "&cYeterli paran yok. Gereken: &f" + ekonomi.bicim(ilan.fiyat));
            return;
        }
        depo.sil(ilan.id);
        double komisyon = getConfig().getDouble("komisyon", 5.0);
        double net = Ekonomi.yuvarla(ilan.fiyat * (1 - komisyon / 100.0));
        ekonomi.ekle(ilan.satici, net);
        esyaVer(p, ilan.item());
        depo.kaydet();
        ekonomi.kaydet();

        msj(p, "&aSatın aldın: &f" + isim(ilan.item()) + " &7(" + ekonomi.bicim(ilan.fiyat) + ")");
        Player satici = Bukkit.getPlayer(ilan.satici);
        if (satici != null) msj(satici, "&a" + p.getName() + " eşyanı satın aldı: &f" + isim(ilan.item())
                + " &7-> " + ekonomi.bicim(net));
        marketAc(p, menu.sayfa);
    }

    private void teklifVer(Player p, Ilan ilan, Menu menu) {
        double yeni = ilan.teklifVar()
                ? Ekonomi.yuvarla(ilan.fiyat + minArtis(ilan.fiyat))
                : ilan.fiyat;

        if (p.getUniqueId().equals(ilan.enYuksek)) {
            msj(p, "&eEn yüksek teklif zaten senin.");
            return;
        }
        if (!ekonomi.cek(p.getUniqueId(), yeni)) {
            msj(p, "&cYeterli paran yok. Gereken: &f" + ekonomi.bicim(yeni));
            return;
        }
        // onceki teklifi iade et
        if (ilan.teklifVar()) {
            ekonomi.ekle(ilan.enYuksek, ilan.fiyat);
            Player eski = Bukkit.getPlayer(ilan.enYuksek);
            if (eski != null) msj(eski, "&cTeklifin geçildi: &f" + isim(ilan.item())
                    + " &7(paran iade edildi)");
        }
        ilan.fiyat = yeni;
        ilan.enYuksek = p.getUniqueId();
        ilan.enYuksekAdi = p.getName();
        depo.kaydet();
        ekonomi.kaydet();

        msj(p, "&aTeklif verildi: &f" + ekonomi.bicim(yeni) + " &7(" + isim(ilan.item()) + ")");
        marketAc(p, menu.sayfa);
    }

    // ------------------------------------------------------------------ komutlar

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd,
                             @NotNull String label, @NotNull String[] args) {
        String ad = cmd.getName().toLowerCase();

        if (ad.equals("ahadmin")) return ahAdmin(sender, args);
        if (ad.equals("coin")) {
            coinKomut(sender, args);
            return true;
        }

        if (ad.equals("balance")) {
            if (args.length > 0) {
                OfflinePlayer hedef = Bukkit.getOfflinePlayer(args[0]);
                msj(sender, "&f" + args[0] + " &7bakiyesi: &a"
                        + ekonomi.bicim(ekonomi.bakiye(hedef.getUniqueId())));
                return true;
            }
            if (!(sender instanceof Player p)) {
                msj(sender, "&cKonsol için: /balance <oyuncu>");
                return true;
            }
            msj(p, "&7Bakiyen: &a" + ekonomi.bicim(ekonomi.bakiye(p.getUniqueId())));
            return true;
        }

        if (!(sender instanceof Player p)) {
            msj(sender, "&cBu komut sadece oyuncular için.");
            return true;
        }

        switch (ad) {
            case "ah" -> {
                if (args.length > 0) {
                    switch (args[0].toLowerCase()) {
                        case "sell", "sat" -> ilanKoy(p, java.util.Arrays.copyOfRange(args, 1, args.length), false);
                        case "auction", "aa", "acikartirma" ->
                                ilanKoy(p, java.util.Arrays.copyOfRange(args, 1, args.length), true);
                        case "mylistings", "ilanlarim", "benim" -> ilanlarimAc(p, 1);
                        case "box", "kutu", "posta" -> kutuAc(p);
                        case "limit" -> ahLimit(p, java.util.Arrays.copyOfRange(args, 1, args.length));
                        case "bid", "teklif" -> teklifKomut(p, java.util.Arrays.copyOfRange(args, 1, args.length));
                        default -> {
                            msj(p, "&8/ah &7- market menüsü");
                            msj(p, "&8/ah sell <fiyat> &7- elindekini satışa koy");
                            msj(p, "&8/ah auction <fiyat> [saat] &7- açık artırmaya koy");
                            msj(p, "&8/ah bid <no> <miktar> &7- açık artırmada fiyat artır");
                            msj(p, "&8/ah mylistings &7| &8/ah box");
                        }
                    }
                    return true;
                }
                marketAc(p, 1);
            }
            case "ahbox" -> kutuAc(p);
            case "sell" -> ilanKoy(p, args, false);
            case "auction" -> ilanKoy(p, args, true);
            case "pay" -> odeme(p, args);
            default -> {
                return false;
            }
        }
        return true;
    }

    /** Acik artirmalari sira numarasiyla listeler (teklif komutu icin). */
    private List<Ilan> acikArtirmalar() {
        List<Ilan> l = new ArrayList<>();
        for (Ilan i : depo.siraliListe()) if (i.acikArtirma) l.add(i);
        return l;
    }

    private void teklifKomut(Player p, String[] args) {
        List<Ilan> liste = acikArtirmalar();
        long simdi = System.currentTimeMillis();

        if (args.length == 0) {
            if (liste.isEmpty()) {
                msj(p, "&7Şu an açık artırma yok.");
                return;
            }
            msj(p, "&7Açık artırmalar &8(&f/ah bid <no> <miktar>&8)");
            for (int i = 0; i < liste.size(); i++) {
                Ilan il = liste.get(i);
                double sonraki = il.teklifVar()
                        ? Ekonomi.yuvarla(il.fiyat + minArtis(il.fiyat)) : il.fiyat;
                p.sendMessage(c("  &6#" + (i + 1) + " &f" + isim(il.item())
                        + " &8| &7güncel: &a" + ekonomi.bicim(il.fiyat)
                        + " &8| &7en az: &e" + ekonomi.bicim(sonraki)
                        + " &8| &7" + il.kalanSure(simdi)));
            }
            return;
        }
        if (args.length < 2) {
            msj(p, "&cKullanım: /ah bid <no> <miktar>");
            msj(p, "&7Numaraları görmek için: &f/ah bid");
            return;
        }

        int no = (int) sayi(args[0]);
        if (no < 1 || no > liste.size()) {
            msj(p, "&cGeçersiz numara. &7/ah bid &cile listeye bak.");
            return;
        }
        Ilan ilan = liste.get(no - 1);
        double miktar = Ekonomi.yuvarla(sayi(args[1]));

        if (ilan.satici.equals(p.getUniqueId())) {
            msj(p, "&cKendi ilanına teklif veremezsin.");
            return;
        }
        if (p.getUniqueId().equals(ilan.enYuksek)) {
            msj(p, "&eEn yüksek teklif zaten senin.");
            return;
        }
        double enAz = ilan.teklifVar() ? Ekonomi.yuvarla(ilan.fiyat + minArtis(ilan.fiyat)) : ilan.fiyat;
        if (miktar < enAz) {
            msj(p, "&cEn az &f" + ekonomi.bicim(enAz) + " &cteklif vermelisin.");
            return;
        }
        if (!ekonomi.cek(p.getUniqueId(), miktar)) {
            msj(p, "&cYeterli paran yok. Gereken: &f" + ekonomi.bicim(miktar));
            return;
        }

        if (ilan.teklifVar()) {
            ekonomi.ekle(ilan.enYuksek, ilan.fiyat);
            Player eski = Bukkit.getPlayer(ilan.enYuksek);
            if (eski != null) msj(eski, "&cTeklifin geçildi: &f" + isim(ilan.item())
                    + " &7(paran iade edildi)");
        }
        ilan.fiyat = miktar;
        ilan.enYuksek = p.getUniqueId();
        ilan.enYuksekAdi = p.getName();
        depo.kaydet();
        ekonomi.kaydet();

        msj(p, "&aTeklif verildi: &f" + ekonomi.bicim(miktar) + " &7(" + isim(ilan.item()) + ")");
        Player satici = Bukkit.getPlayer(ilan.satici);
        if (satici != null) msj(satici, "&aİlanına yeni teklif: &f" + ekonomi.bicim(miktar)
                + " &7(" + p.getName() + ")");
    }

    /** "Sinirsiz" ilan hakki (yetkili taglar). TagSistemi ayni degeri dondurur. */
    private static final int SINIRSIZ = Integer.MAX_VALUE;

    /**
     * TagSistemi yukluyse oyuncunun rutbesine bagli ilan limitini yansima ile okur.
     * -1 = rutbe/limit yok (varsayilan hak gecerli), SINIRSIZ = sinirsiz.
     */
    private int rutbeLimiti(UUID uuid) {
        org.bukkit.plugin.Plugin t = Bukkit.getPluginManager().getPlugin("TagSistemi");
        if (t == null || !t.isEnabled()) return -1;
        try {
            Object r = t.getClass().getMethod("ahLimiti", UUID.class).invoke(t, uuid);
            return r instanceof Integer i ? i : -1;
        } catch (ReflectiveOperationException ex) {
            return -1;
        }
    }

    /** Oyuncunun aynı anda açabileceği ilan sayısı. */
    private int ilanHakki(Player p) {
        int rutbe = rutbeLimiti(p.getUniqueId());
        if (rutbe == SINIRSIZ) return SINIRSIZ;           // yetkili: her seyin ustunde

        int hak = getConfig().getInt("max-ilan", 4);
        if (rutbe > 0) hak = Math.max(hak, rutbe);        // rutbe hakki varsayilandan dusuk olamaz
        Integer ozel = depo.ilanLimiti(p.getUniqueId());  // /ah limit ile elle verilen
        if (ozel != null) hak = ozel;
        return hak;
    }

    private String hakMetni(Player p) {
        int h = ilanHakki(p);
        return h == SINIRSIZ ? "sınırsız" : String.valueOf(h);
    }

    private void ahLimit(CommandSender sender, String[] args) {
        if (args.length == 0) {
            if (sender instanceof Player p) {
                msj(p, "&7İlan hakkın: &f" + depo.oyuncununIlanlari(p.getUniqueId()).size()
                        + "&7/&f" + hakMetni(p));
            }
            if (sender.hasPermission("marketah.admin")) {
                msj(sender, "&8/ah limit <oyuncu> <sayı> &7- oyuncunun ilan hakkını ayarla");
                msj(sender, "&8/ah limit <oyuncu> reset &7- varsayılana döndür");
            }
            return;
        }
        if (!sender.hasPermission("marketah.admin")) {
            msj(sender, "&cYetkin yok.");
            return;
        }
        if (args.length < 2) {
            msj(sender, "&cKullanım: /ah limit <oyuncu> <sayı|reset>");
            return;
        }
        OfflinePlayer hedef = Bukkit.getOfflinePlayer(args[0]);
        if (args[1].equalsIgnoreCase("reset") || args[1].equalsIgnoreCase("sıfırla") || args[1].equalsIgnoreCase("sifirla")) {
            depo.ilanLimitiAyarla(hedef.getUniqueId(), null);
            depo.kaydet();
            msj(sender, "&f" + args[0] + " &7artık varsayılan hakka sahip &8("
                    + getConfig().getInt("max-ilan", 4) + ")");
            return;
        }
        int sayiDeger = (int) sayi(args[1]);
        if (sayiDeger < 1 || sayiDeger > 54) {
            msj(sender, "&c1 - 54 arasında bir sayı gir.");
            return;
        }
        depo.ilanLimitiAyarla(hedef.getUniqueId(), sayiDeger);
        depo.kaydet();
        msj(sender, "&f" + args[0] + " &aartık &f" + sayiDeger + " &ailan açabilir.");
        Player hp = hedef.getPlayer();
        if (hp != null) msj(hp, "&aİlan hakkın &f" + sayiDeger + " &aoldu!");
    }

    private void coinKomut(CommandSender sender, String[] args) {
        if (!sender.hasPermission("marketah.admin")) {
            msj(sender, "&cYetkin yok.");
            return;
        }
        if (args.length == 0) {
            msj(sender, "&8/coin give <oyuncu> <tür> [adet] &7- coin verir");
            msj(sender, "&8/coin toggle &7- coin sistemini aç/kapat");
            StringBuilder sb = new StringBuilder();
            for (Coin c : Coin.values()) sb.append("&f").append(c.ad).append(" &8(&a")
                    .append(String.format("%,d", c.min)).append("-")
                    .append(String.format("%,d", c.max)).append("&8) ");
            msj(sender, "&7Türler: " + sb);
            return;
        }

        switch (args[0].toLowerCase()) {
            case "toggle", "sistem" -> {
                boolean yeni = !getConfig().getBoolean("coin-sistemi", true);
                getConfig().set("coin-sistemi", yeni);
                saveConfig();
                msj(sender, yeni ? "&aCoin sistemi açıldı." : "&cCoin sistemi kapatıldı.");
            }
            case "give", "ver" -> {
                if (args.length < 3) {
                    msj(sender, "&cKullanım: /coin give <oyuncu> <tür> [adet]");
                    return;
                }
                Player hedef = Bukkit.getPlayerExact(args[1]);
                if (hedef == null) {
                    msj(sender, "&cOyuncu çevrimiçi değil.");
                    return;
                }
                Coin coin = Coin.bul(args[2]);
                if (coin == null) {
                    msj(sender, "&cGeçersiz tür: &f" + args[2]);
                    return;
                }
                int adet = args.length > 3 ? (int) sayi(args[3]) : 1;
                if (adet < 1 || adet > 64) adet = 1;
                // yere birakilir: oyuncu aldigi an paraya doner
                hedef.getWorld().dropItem(hedef.getLocation().add(0, 0.5, 0),
                        coin.esya(adet, ekonomi.birim()));
                sender.sendMessage(c("&8[&6Coin&8] &a" + hedef.getName() + " oyuncusunun önüne &r"
                        + coin.gorunum + " &8x" + adet + " &abırakıldı."));
            }
            default -> msj(sender, "&cBilinmeyen alt komut. &7/coin");
        }
    }

    private void odeme(Player p, String[] args) {
        if (args.length < 2) {
            msj(p, "&cKullanım: /pay <oyuncu> <miktar>");
            return;
        }
        Player hedef = Bukkit.getPlayerExact(args[0]);
        if (hedef == null) {
            msj(p, "&cOyuncu çevrimiçi değil.");
            return;
        }
        if (hedef.getUniqueId().equals(p.getUniqueId())) {
            msj(p, "&cKendine para gönderemezsin.");
            return;
        }
        double miktar = Ekonomi.yuvarla(sayi(args[1]));
        if (miktar < 0.01) {
            msj(p, "&cGeçerli bir miktar gir. &7(en az 0,01)");
            return;
        }
        if (!ekonomi.cek(p.getUniqueId(), miktar)) {
            msj(p, "&cYeterli paran yok.");
            return;
        }
        ekonomi.ekle(hedef.getUniqueId(), miktar);
        ekonomi.kaydet();
        msj(p, "&a" + ekonomi.bicim(miktar) + " gönderildi → &f" + hedef.getName());
        msj(hedef, "&a" + p.getName() + " sana " + ekonomi.bicim(miktar) + " gönderdi.");
    }

    private void ilanKoy(Player p, String[] args, boolean acikArtirma) {
        if (args.length < 1) {
            msj(p, acikArtirma ? "&cKullanım: /auction <başlangıç fiyatı> [saat]"
                    : "&cKullanım: /sell <fiyat>");
            return;
        }
        ItemStack elde = p.getInventory().getItemInMainHand();
        if (elde.getType() == Material.AIR) {
            msj(p, "&cElinde eşya yok.");
            return;
        }
        int max = ilanHakki(p);
        if (depo.oyuncununIlanlari(p.getUniqueId()).size() >= max) {
            msj(p, "&cİlan hakkın doldu &7(" + hakMetni(p) + "&7). &cRütben ile artırabilirsin.");
            return;
        }

        double fiyat = Ekonomi.yuvarla(sayi(args[0]));
        double min = getConfig().getDouble("min-fiyat", 1.0);
        double maxF = getConfig().getDouble("max-fiyat", 10000000.0);
        if (fiyat < min || fiyat > maxF) {
            msj(p, "&cFiyat &f" + ekonomi.bicim(min) + " &c- &f" + ekonomi.bicim(maxF) + " &carasında olmalı.");
            return;
        }

        long simdi = System.currentTimeMillis();
        long bitis;
        if (acikArtirma) {
            int varsayilan = getConfig().getInt("acik-artirma.varsayilan-saat", 6);
            int maxSaat = getConfig().getInt("acik-artirma.max-saat", 48);
            int saat = args.length > 1 ? (int) sayi(args[1]) : varsayilan;
            if (saat < 1 || saat > maxSaat) {
                msj(p, "&cSüre 1 - " + maxSaat + " saat arasında olmalı.");
                return;
            }
            bitis = simdi + saat * 3600000L;
        } else {
            int saat = getConfig().getInt("ilan-suresi-saat", 72);
            bitis = saat > 0 ? simdi + saat * 3600000L : 0L;
        }

        ItemStack kopya = elde.clone();
        Ilan ilan;
        try {
            byte[] veri = kopya.serializeAsBytes();
            ItemStack deneme = ItemStack.deserializeBytes(veri);   // geri okunabiliyor mu?
            if (deneme == null || deneme.getType() == Material.AIR) throw new IllegalStateException("bos esya");
            ilan = new Ilan(UUID.randomUUID(), p.getUniqueId(), p.getName(),
                    veri, acikArtirma, fiyat, simdi, bitis);
        } catch (Exception ex) {
            msj(p, "&cBu eşya markete konulamıyor. &7(" + ex.getClass().getSimpleName() + ")");
            getLogger().warning("İlan oluşturulamadı (" + p.getName() + " / "
                    + kopya.getType() + "): " + ex);
            return;
        }
        depo.ekle(ilan);
        p.getInventory().setItemInMainHand(null);
        depo.kaydet();

        msj(p, "&aİlan açıldı: &f" + isim(kopya) + " &7- "
                + (acikArtirma ? "açık artırma, başlangıç " : "fiyat ")
                + ekonomi.bicim(fiyat));

        Bukkit.broadcast(c("&8[&6Market&8] &f" + p.getName() + " &7bir eşya "
                + (acikArtirma ? "açık artırmaya koydu" : "satışa koydu") + ": &f"
                + isim(kopya) + " &7- &a" + ekonomi.bicim(fiyat) + " &8(/ah)"));
    }

    private boolean ahAdmin(CommandSender sender, String[] args) {
        if (!sender.hasPermission("marketah.admin")) {
            msj(sender, "&cYetkin yok.");
            return true;
        }
        if (args.length < 1) {
            msj(sender, "&7/ahadmin give|take|set <oyuncu> <miktar> &8| &7/ahadmin clearall &8| &7/ahadmin reload");
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "give", "take", "set", "ver", "al", "ayarla" -> {
                if (args.length < 3) {
                    msj(sender, "&cKullanım: /ahadmin " + args[0] + " <oyuncu> <miktar>");
                    return true;
                }
                OfflinePlayer hedef = Bukkit.getOfflinePlayer(args[1]);
                double miktar = sayi(args[2]);
                if (miktar < 0) {
                    msj(sender, "&cGeçerli bir miktar gir.");
                    return true;
                }
                UUID u = hedef.getUniqueId();
                switch (args[0].toLowerCase()) {
                    case "give", "ver" -> ekonomi.ekle(u, miktar);
                    case "take", "al" -> ekonomi.ayarla(u, ekonomi.bakiye(u) - miktar);
                    default -> ekonomi.ayarla(u, miktar);
                }
                ekonomi.kaydet();
                msj(sender, "&aTamam. &f" + args[1] + " &7yeni bakiye: &a" + ekonomi.bicim(ekonomi.bakiye(u)));
            }
            case "clearall", "temizle" -> {
                int n = depo.hepsi().size();
                for (Ilan i : new ArrayList<>(depo.hepsi().values())) {
                    if (i.acikArtirma && i.teklifVar()) ekonomi.ekle(i.enYuksek, i.fiyat);
                    esyaVerOfflineDahil(i.satici, i.item());
                    depo.sil(i.id);
                }
                depo.kaydet();
                ekonomi.kaydet();
                msj(sender, "&a" + n + " ilan iptal edildi, eşyalar satıcılara iade edildi.");
            }
            case "reload" -> {
                ekonomi.kaydet();
                reloadConfig();
                ekonomi.yukle();
                msj(sender, "&aAyarlar yeniden yüklendi.");
            }
            default -> msj(sender, "&cBilinmeyen alt komut. &7/ahadmin");
        }
        return true;
    }

    /** Sayiyi okur; gecersiz, NaN veya sonsuz ise -1 doner (Double.parseDouble "NaN" kabul eder!). */
    private static double sayi(String s) {
        try {
            double d = Double.parseDouble(s.replace(",", "."));
            return Double.isFinite(d) ? d : -1;
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
