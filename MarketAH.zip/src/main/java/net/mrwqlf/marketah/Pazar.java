/*
 * © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR.
 * Bu kodun izinsiz kopyalanması, dağıtılması veya değiştirilmesi yasaktır.
 */
package net.mrwqlf.marketah;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.command.CommandSender;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Yere kurulan oyuncu pazari (kirilmaz tezgah).
 * /ah pazar <fiyat>: eldeki esyayi pazara koyar; ilk kullanimda pazar oyuncunun durdugu yere kurulur.
 * /ah clear: tum esyalar oyuncuya geri doner, pazar kapanir.
 * Normal oyuncu 6, VIP (marketah.pazar.vip) 12 slot kullanir.
 * Tezgah blok degil gorunur varliklardan (display) olustugu icin kirilamaz; yok olursa otomatik yeniden kurulur.
 */
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
final class Pazar implements Listener {

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static final int TOPLAM_SLOT = 12;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static final String ETIKET = "marketah_pazar";

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private record Esya(ItemStack esya, double fiyat, boolean alim) {}

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private record Hedef(UUID sahip, int slot) {}

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private record Onay(UUID sahip, int slot, Esya esya, long bitis) {}

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static final class Tezgah {
        UUID sahip;
        String dunya;
        double x, y, z;
        float yaw;
        long bitis;
        UUID baslik;
        final Esya[] slot = new Esya[TOPLAM_SLOT];
        final List<UUID> varliklar = new ArrayList<>();
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final MarketAH eklenti;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Map<UUID, Tezgah> tezgahlar = new LinkedHashMap<>();
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Map<UUID, Hedef> hedefler = new HashMap<>();
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Map<UUID, Onay> onaylar = new HashMap<>();
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Map<UUID, Long> sonTik = new HashMap<>();
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private File dosya;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private BukkitTask gorev;

    Pazar(MarketAH eklenti) {
        this.eklenti = eklenti;
    }

    // ------------------------------------------------------------ yardimcilar

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static Component c(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s)
                .decoration(TextDecoration.ITALIC, false);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static void msj(Player p, String metin) {
        p.sendMessage(c("&8[&6Pazar&8] &r" + metin));
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private int slotSayisi(Player p) {
        int s = p.hasPermission("marketah.pazar.vip")
                ? eklenti.getConfig().getInt("pazar.slot-vip", 12)
                : eklenti.getConfig().getInt("pazar.slot-normal", 6);
        return Math.max(1, Math.min(TOPLAM_SLOT, s));
    }

    /** "1500", "2.5k", "3m", "1b" gibi fiyatlari okur; gecersizse -1. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static double fiyatOku(String s) {
        try {
            String t = s.trim().toLowerCase().replace(",", ".");
            double carpan = 1;
            if (!t.isEmpty()) {
                char son = t.charAt(t.length() - 1);
                switch (son) {
                    case 'k' -> carpan = 1e3;
                    case 'm' -> carpan = 1e6;
                    case 'b' -> carpan = 1e9;
                    default -> { }
                }
                if (carpan != 1) {
                    t = t.substring(0, t.length() - 1);
                }
            }
            double d = Double.parseDouble(t) * carpan;
            return Double.isFinite(d) ? d : -1;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    // ------------------------------------------------------------ yasam dongusu

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    void baslat() {
        dosya = new File(eklenti.getDataFolder(), "pazar.yml");
        yukle();
        gorev = Bukkit.getScheduler().runTaskTimer(eklenti, this::garanti, 60L, 100L);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    void kapat() {
        if (gorev != null) {
            gorev.cancel();
            gorev = null;
        }
        for (Tezgah t : tezgahlar.values()) {
            varliklariKaldir(t);
        }
        kaydet();
    }

    // ------------------------------------------------------------ veri

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void yukle() {
        tezgahlar.clear();
        if (!dosya.exists()) {
            return;
        }
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dosya);
        ConfigurationSection kok = y.getConfigurationSection("tezgahlar");
        if (kok == null) {
            return;
        }
        for (String anahtar : kok.getKeys(false)) {
            try {
                ConfigurationSection b = kok.getConfigurationSection(anahtar);
                if (b == null) {
                    continue;
                }
                Tezgah t = new Tezgah();
                t.sahip = UUID.fromString(anahtar);
                t.dunya = b.getString("dunya", "world");
                t.x = b.getDouble("x");
                t.y = b.getDouble("y");
                t.z = b.getDouble("z");
                t.yaw = (float) b.getDouble("yaw");
                t.bitis = b.getLong("bitis", 0L);
                ConfigurationSection sl = b.getConfigurationSection("slot");
                if (sl != null) {
                    for (String no : sl.getKeys(false)) {
                        int i = Integer.parseInt(no);
                        ItemStack it = sl.getItemStack(no + ".esya");
                        if (i >= 0 && i < TOPLAM_SLOT && it != null) {
                            t.slot[i] = new Esya(it, sl.getDouble(no + ".fiyat"), sl.getBoolean(no + ".alim", false));
                        }
                    }
                }
                tezgahlar.put(t.sahip, t);
            } catch (IllegalArgumentException ignored) {
                // bozuk kayit atlanir
            }
        }
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void kaydet() {
        YamlConfiguration y = new YamlConfiguration();
        for (Tezgah t : tezgahlar.values()) {
            String k = "tezgahlar." + t.sahip;
            y.set(k + ".dunya", t.dunya);
            y.set(k + ".x", t.x);
            y.set(k + ".y", t.y);
            y.set(k + ".z", t.z);
            y.set(k + ".yaw", t.yaw);
            y.set(k + ".bitis", t.bitis);
            for (int i = 0; i < TOPLAM_SLOT; i++) {
                if (t.slot[i] != null) {
                    y.set(k + ".slot." + i + ".esya", t.slot[i].esya());
                    y.set(k + ".slot." + i + ".fiyat", t.slot[i].fiyat());
                    y.set(k + ".slot." + i + ".alim", t.slot[i].alim());
                }
            }
        }
        try {
            eklenti.getDataFolder().mkdirs();
            y.save(dosya);
        } catch (IOException hata) {
            eklenti.getLogger().warning("pazar.yml kaydedilemedi: " + hata.getMessage());
        }
    }

    // ------------------------------------------------------------ komutlar

    /** Pazar suresi (ms): normal oyuncu / VIP. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private long sureMs(Player p) {
        double saat = p.hasPermission("marketah.pazar.vip")
                ? eklenti.getConfig().getDouble("pazar.sure-vip-saat", 24)
                : eklenti.getConfig().getDouble("pazar.sure-normal-saat", 8);
        return (long) (Math.max(0.01, saat) * 3600_000L);
    }

    /** "7s 12dk" biciminde kalan sure. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static String sureYazi(long ms) {
        if (ms <= 0) {
            return "0dk";
        }
        long dk = ms / 60_000L;
        long sa = dk / 60;
        dk = dk % 60;
        return sa > 0 ? sa + "s " + dk + "dk" : dk + "dk";
    }

    // ------------------------------------------------------------ guvenli bolge

    /** Ayarlanan guvenli bolgelerden birinin icinde mi? ("dunya,x1,y1,z1,x2,y2,z2") */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private boolean bolgedeMi(Location l) {
        for (String satir : eklenti.getConfig().getStringList("pazar.guvenli-bolgeler")) {
            String[] a = satir.split(",");
            if (a.length != 7 || l.getWorld() == null || !l.getWorld().getName().equalsIgnoreCase(a[0].trim())) {
                continue;
            }
            try {
                double x1 = Double.parseDouble(a[1].trim()), y1 = Double.parseDouble(a[2].trim());
                double z1 = Double.parseDouble(a[3].trim()), x2 = Double.parseDouble(a[4].trim());
                double y2 = Double.parseDouble(a[5].trim()), z2 = Double.parseDouble(a[6].trim());
                if (l.getX() >= Math.min(x1, x2) && l.getX() <= Math.max(x1, x2) + 1
                        && l.getY() >= Math.min(y1, y2) - 1 && l.getY() <= Math.max(y1, y2) + 1
                        && l.getZ() >= Math.min(z1, z2) && l.getZ() <= Math.max(z1, z2) + 1) {
                    return true;
                }
            } catch (NumberFormatException ignored) {
                // bozuk satir atlanir
            }
        }
        return false;
    }

    /** /ah bolge ekle|liste|sil|sinir (yalniz marketah.admin) */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    void bolgeKomut(Player p, String[] args) {
        if (!p.hasPermission("marketah.admin")) {
            msj(p, "&cBu komut sadece yetkililer içindir.");
            return;
        }
        List<String> liste = new ArrayList<>(eklenti.getConfig().getStringList("pazar.guvenli-bolgeler"));
        String alt = args.length > 1 ? args[1].toLowerCase() : "liste";
        switch (alt) {
            case "ekle" -> {
                if (args.length < 9) {
                    msj(p, "&cKullanım: /ah bolge ekle <dünya> <x1> <y1> <z1> <x2> <y2> <z2>");
                    return;
                }
                String satir = String.join(",", java.util.Arrays.copyOfRange(args, 2, 9));
                liste.add(satir);
                eklenti.getConfig().set("pazar.guvenli-bolgeler", liste);
                eklenti.saveConfig();
                msj(p, "&aGüvenli bölge eklendi: &f" + satir + " &7(#" + liste.size() + ")");
            }
            case "buraya" -> {
                // Bulundugun noktanin etrafinda (tum yukseklik) daire/kare bolge: /ah bolge buraya <yaricap>
                double r = args.length > 2 ? fiyatOku(args[2]) : 30;
                if (r < 3 || r > 500) {
                    msj(p, "&cYarıçap 3 - 500 arasında olmalı. &7Örnek: /ah bolge buraya 40");
                    return;
                }
                Location l = p.getLocation();
                World w = l.getWorld();
                String satir = w.getName() + "," + (int) Math.floor(l.getX() - r) + "," + w.getMinHeight() + ","
                        + (int) Math.floor(l.getZ() - r) + "," + (int) Math.floor(l.getX() + r) + ","
                        + w.getMaxHeight() + "," + (int) Math.floor(l.getZ() + r);
                liste.add(satir);
                eklenti.getConfig().set("pazar.guvenli-bolgeler", liste);
                eklenti.saveConfig();
                msj(p, "&aGüvenli bölge eklendi (yarıçap " + (int) r + "): &f" + satir + " &7(#" + liste.size() + ")");
            }
            case "sil" -> {
                int no = args.length > 2 ? (int) fiyatOku(args[2]) : -1;
                if (no < 1 || no > liste.size()) {
                    msj(p, "&cKullanım: /ah bolge sil <numara>");
                    return;
                }
                String silinen = liste.remove(no - 1);
                eklenti.getConfig().set("pazar.guvenli-bolgeler", liste);
                eklenti.saveConfig();
                msj(p, "&aBölge silindi: &f" + silinen);
            }
            case "sinir" -> {
                boolean ac = args.length > 2 && args[2].equalsIgnoreCase("ac");
                eklenti.getConfig().set("pazar.bolge-siniri", ac);
                eklenti.saveConfig();
                msj(p, ac ? "&aPazar sadece güvenli bölgelerde kurulabilir."
                        : "&ePazar HER YERDE kurulabilir (bölge sınırı kapalı).");
            }
            default -> {
                msj(p, "&7Bölge sınırı: " + (eklenti.getConfig().getBoolean("pazar.bolge-siniri", true) ? "&aaçık" : "&ckapalı"));
                if (liste.isEmpty()) {
                    msj(p, "&7Henüz güvenli bölge yok. &f/ah bolge buraya <yarıçap> &7(durduğun yer) veya &f/ah bolge ekle <dünya> <x1> <y1> <z1> <x2> <y2> <z2>");
                }
                for (int i = 0; i < liste.size(); i++) {
                    msj(p, "&8#" + (i + 1) + " &f" + liste.get(i));
                }
            }
        }
    }

    // ------------------------------------------------------------ komutlar

    /** /ah pazar <fiyat> (satis) ve /ah buy <fiyat> (alim istegi): eldeki esyayi pazara koyar. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    void ekle(Player p, String fiyatMetni, boolean alim) {
        double fiyat = Ekonomi.yuvarla(fiyatOku(fiyatMetni));
        double min = eklenti.getConfig().getDouble("min-fiyat", 1.0);
        double max = eklenti.getConfig().getDouble("max-fiyat", 10000000.0);
        if (fiyat < min || fiyat > max) {
            msj(p, "&cFiyat &f" + eklenti.bicim(min) + " &c- &f" + eklenti.bicim(max)
                    + " &carasında olmalı. &7(örnek: /ah pazar 2.5k)");
            return;
        }
        ItemStack elde = p.getInventory().getItemInMainHand();
        if (elde.getType() == Material.AIR) {
            msj(p, "&cElinde eşya yok.");
            return;
        }
        Tezgah t = tezgahlar.get(p.getUniqueId());
        boolean yeni = false;
        if (t == null) {
            if (eklenti.getConfig().getBoolean("pazar.bolge-siniri", true) && !p.hasPermission("marketah.admin")) { // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
                Location l0 = p.getLocation();
                double yr = Math.toRadians(Math.round(l0.getYaw() / 90f) * 90f);
                Location on = l0.clone().add(-Math.sin(yr) * 0.9, 0, Math.cos(yr) * 0.9);
                if (!bolgedeMi(l0) || !bolgedeMi(on)) {
                    msj(p, eklenti.getConfig().getStringList("pazar.guvenli-bolgeler").isEmpty()
                            ? "&cPazar kurulabilecek güvenli bölge henüz belirlenmedi."
                            : "&cPazarı sadece &fgüvenli bölgelerde &ckurabilirsin.");
                    return;
                }
            }
            t = new Tezgah();
            t.sahip = p.getUniqueId();
            Location l = p.getLocation();
            t.dunya = l.getWorld().getName();
            t.x = l.getBlockX() + 0.5;
            t.y = l.getY();
            t.z = l.getBlockZ() + 0.5;
            t.yaw = Math.round(l.getYaw() / 90f) * 90f;
            t.bitis = System.currentTimeMillis() + sureMs(p);
            yeni = true;
        }
        int limit = slotSayisi(p);
        int bos = -1;
        for (int i = 0; i < limit; i++) {
            if (t.slot[i] == null) {
                bos = i;
                break;
            }
        }
        if (bos < 0) {
            msj(p, "&cPazarın dolu &7(" + limit + " slot). &7VIP'ler " + eklenti.getConfig().getInt("pazar.slot-vip", 12)
                    + " slot kullanır.");
            return;
        }
        if (alim) {
            // Alim istegi: eldeki esya ORNEK olarak kopyalanir, odeme pesin ayrilir (emanet)
            if (!eklenti.cek(p.getUniqueId(), fiyat)) {
                msj(p, "&cYetersiz bakiye. &7Alım isteği için para peşin ayrılır: &e" + eklenti.bicim(fiyat));
                return;
            }
            t.slot[bos] = new Esya(elde.clone(), fiyat, true);
        } else {
            t.slot[bos] = new Esya(elde.clone(), fiyat, false);
            p.getInventory().setItemInMainHand(null);
        }
        if (yeni) {
            tezgahlar.put(t.sahip, t);
        }
        kaydet();
        kur(t);
        Esya e = t.slot[bos];
        if (alim) {
            msj(p, "&bAlım isteği: &f" + eklenti.isim(e.esya()) + " &7x" + e.esya().getAmount()
                    + " &8- &e" + eklenti.bicim(fiyat) + " &7(para ayrıldı) &8(" + (bos + 1) + "/" + limit + ")");
        } else {
            msj(p, "&a" + eklenti.isim(e.esya()) + " &7x" + e.esya().getAmount()
                    + " &apazara konuldu: &e" + eklenti.bicim(fiyat) + " &8(" + (bos + 1) + "/" + limit + ")");
        }
        if (yeni) {
            msj(p, "&7Pazarın &e" + sureYazi(t.bitis - System.currentTimeMillis())
                    + " &7açık kalır. Tümünü kapatmak için &f/ah clear");
        }
    }

    /** /ah clear: butun esyalar oyuncuya doner (alim emanetleri iade), pazar kapanir. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    void kapat(Player p) {
        Tezgah t = tezgahlar.get(p.getUniqueId());
        if (t == null) {
            msj(p, "&cAçık bir pazarın yok.");
            return;
        }
        kapatTezgah(t, false);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void kapatTezgah(Tezgah t, boolean sureDoldu) {
        tezgahlar.remove(t.sahip);
        varliklariKaldir(t);
        int satis = 0;
        int alis = 0;
        double iade = 0;
        for (Esya e : t.slot) {
            if (e == null) {
                continue;
            }
            if (e.alim()) {
                eklenti.paraEkle(t.sahip, e.fiyat());
                iade += e.fiyat();
                alis++;
            } else {
                eklenti.esyaVerOfflineDahil(t.sahip, e.esya().clone());
                satis++;
            }
        }
        kaydet();
        Player o = Bukkit.getPlayer(t.sahip);
        if (o != null) {
            msj(o, (sureDoldu ? "&ePazarının süresi doldu ve kapandı. " : "&aPazar kapatıldı. ")
                    + "&7" + satis + " eşya sana geri döndü"
                    + (alis > 0 ? ", " + alis + " alım isteği için &e" + eklenti.bicim(iade) + " &7iade edildi" : "")
                    + (sureDoldu ? " &8(taşan eşyalar /ahbox)" : "") + ".");
        }
    }

    // ------------------------------------------------------------ gorunum

    /** Sure dolduysa kapatir; varliklar eksikse (chunk yuklenmesi, silinme) yeniden kurar; basligi gunceller. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void garanti() {
        long simdi = System.currentTimeMillis();
        for (Tezgah t : new ArrayList<>(tezgahlar.values())) {
            if (t.bitis > 0 && simdi >= t.bitis) {
                kapatTezgah(t, true);
                continue;
            }
            World w = Bukkit.getWorld(t.dunya);
            if (w == null || !w.isChunkLoaded(((int) Math.floor(t.x)) >> 4, ((int) Math.floor(t.z)) >> 4)) {
                continue;
            }
            boolean tamam = !t.varliklar.isEmpty();
            for (UUID id : t.varliklar) {
                Entity e = Bukkit.getEntity(id);
                if (e == null || !e.isValid()) {
                    tamam = false;
                    break;
                }
            }
            if (!tamam) {
                kur(t);
            } else if (t.baslik != null && Bukkit.getEntity(t.baslik) instanceof TextDisplay td) {
                td.text(baslikMetni(t));
            }
        }
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private Component baslikMetni(Tezgah t) {
        String ad = Bukkit.getOfflinePlayer(t.sahip).getName();
        long kalan = t.bitis - System.currentTimeMillis();
        return c("&6&lMERCHANT\n&e" + (ad != null ? ad : "?") + "\n&7Kalan: &f" + sureYazi(kalan));
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void varliklariKaldir(Tezgah t) {
        for (UUID id : t.varliklar) {
            hedefler.remove(id);
            Entity e = Bukkit.getEntity(id);
            if (e != null) {
                e.remove();
            }
        }
        t.varliklar.clear();
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void kur(Tezgah t) {
        varliklariKaldir(t);
        World w = Bukkit.getWorld(t.dunya);
        if (w == null) {
            return;
        }
        double yr = Math.toRadians(t.yaw);
        Vector n = new Vector(-Math.sin(yr), 0, Math.cos(yr));       // on yuz (musteri tarafi)
        Vector sag = new Vector(n.getZ(), 0, -n.getX());             // musterinin sagi
        // Tezgah, oyuncunun durdugu noktanin biraz onunde (oyuncu tezgahin arkasinda kalir)
        Location taban = new Location(w, t.x, t.y, t.z, t.yaw, 0).add(n.clone().multiply(0.9));

        // --- Rise Online tarzi katlanir ahsap masa + beyaz masa ortusu ---
        // bacaklar
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sz = -1; sz <= 1; sz += 2) {
                kutu(t, taban, sag, n, sx * 1.45 - 0.05, 0, sz * 0.5 - 0.05, 0.1, 0.95, 0.1, Material.SPRUCE_PLANKS);
            }
        }
        // alt cubuklar (carpraz bacak hissi veren cerceve)
        kutu(t, taban, sag, n, -1.45, 0.4, 0.45, 2.9, 0.06, 0.06, Material.OAK_PLANKS);
        kutu(t, taban, sag, n, -1.45, 0.4, -0.51, 2.9, 0.06, 0.06, Material.OAK_PLANKS);
        kutu(t, taban, sag, n, -1.48, 0.4, -0.5, 0.06, 0.06, 1.0, Material.OAK_PLANKS);
        kutu(t, taban, sag, n, 1.42, 0.4, -0.5, 0.06, 0.06, 1.0, Material.OAK_PLANKS);
        // alt raf
        kutu(t, taban, sag, n, -1.4, 0.22, -0.48, 2.8, 0.05, 0.96, Material.OAK_PLANKS);
        // masa tahtasi + beyaz ortu + one sarkan ortu
        kutu(t, taban, sag, n, -1.6, 0.92, -0.6, 3.2, 0.06, 1.2, Material.OAK_PLANKS);
        kutu(t, taban, sag, n, -1.65, 0.98, -0.65, 3.3, 0.05, 1.3, Material.WHITE_WOOL);
        kutu(t, taban, sag, n, -1.65, 0.66, 0.62, 3.3, 0.37, 0.04, Material.WHITE_WOOL);
        kutu(t, taban, sag, n, 1.58, 0.66, -0.65, 0.04, 0.37, 1.3, Material.WHITE_WOOL);
        kutu(t, taban, sag, n, -1.62, 0.66, -0.65, 0.04, 0.37, 1.3, Material.WHITE_WOOL);

        // --- susler: varil + icinde silahlar (soldan), fener (masa kosesi), kasa (sagdan) ---
        kutu(t, taban, sag, n, -1.25, 0.0, 0.7, 0.45, 0.5, 0.45, Material.BARREL);
        dekor(t, taban, sag, n, -1.12, 0.78, 0.9, Material.IRON_SWORD, 0.9f, 45f);
        dekor(t, taban, sag, n, -1.03, 0.76, 0.9, Material.STICK, 0.9f, 45f);
        dekor(t, taban, sag, n, -0.95, 0.78, 0.9, Material.WOODEN_SWORD, 0.9f, 45f);
        kutu(t, taban, sag, n, 0.85, 0.0, 0.7, 0.5, 0.35, 0.4, Material.CHEST);
        kutu(t, taban, sag, n, 1.35, 1.03, -0.5, 0.25, 0.3, 0.25, Material.LANTERN);

        // --- baslik: MERCHANT + sahip adi + kalan sure (her yonden okunur) ---
        t.baslik = yazi(t, taban.clone().add(0, 2.15, 0), baslikMetni(t), 1.0f);

        // --- esyalar masanin ustunde yatar; fiyat yazisi uzerinde yuzer ---
        for (int i = 0; i < TOPLAM_SLOT; i++) {
            int satir = i / 6;            // 0 = arka sira, 1 = on sira
            int sutun = i % 6;
            double lx = (sutun - 2.5) * 0.5;
            double lz = satir == 0 ? -0.22 : 0.25;
            Esya e = t.slot[i];
            if (e == null) {
                continue;
            }
            Location yer = taban.clone().add(sag.clone().multiply(lx)).add(n.clone().multiply(lz)).add(0, 1.06, 0);
            esyaYat(t, yer, e.esya());
            yazi(t, yer.clone().add(0, satir == 0 ? 0.62 : 0.36, 0),
                    c((e.alim() ? "&aAlım &7x" : "&7x") + e.esya().getAmount() + "\n&e" + eklenti.bicim(e.fiyat())), 0.4f);
            Location h = yer.clone().add(0, -0.06, 0);
            h.setYaw(t.yaw);
            final int slotNo = i;
            Interaction ia = w.spawn(h, Interaction.class, x -> {
                x.setInteractionWidth(0.48f);
                x.setInteractionHeight(0.6f);
                x.setResponsive(true);
                x.setInvulnerable(true);
                x.setPersistent(false);
                x.addScoreboardTag(ETIKET);
            });
            t.varliklar.add(ia.getUniqueId());
            hedefler.put(ia.getUniqueId(), new Hedef(t.sahip, slotNo));
        }
    }

    /** Yerel koordinatta (sag, yukari, musteriye dogru) kose noktasindan baslayan kutu. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void kutu(Tezgah t, Location taban, Vector sag, Vector n, double lx, double ly, double lz,
                      double sx, double sy, double sz, Material m) {
        Location l = taban.clone().add(sag.clone().multiply(lx)).add(n.clone().multiply(lz)).add(0, ly, 0);
        blok(t, l, m, 0f, 0f, 0f, (float) sx, (float) sy, (float) sz);
    }

    /** Susleme: ayakta duran esya (z ekseninde donuk). */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void dekor(Tezgah t, Location taban, Vector sag, Vector n, double lx, double ly, double lz,
                       Material m, float olcek, float derece) {
        Location l = taban.clone().add(sag.clone().multiply(lx)).add(n.clone().multiply(lz)).add(0, ly, 0);
        l.setYaw(t.yaw);
        l.setPitch(0);
        ItemStack it = new ItemStack(m);
        ItemDisplay id = l.getWorld().spawn(l, ItemDisplay.class, d -> {
            d.setItemStack(it);
            d.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
            d.setTransformation(new Transformation(new Vector3f(),
                    new AxisAngle4f((float) Math.toRadians(derece), 0f, 0f, 1f),
                    new Vector3f(olcek, olcek, olcek), new AxisAngle4f()));
            ortak(d);
        });
        t.varliklar.add(id.getUniqueId());
    }

    /** Masanin ustunde yatan esya (yuzu yukari bakar). */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void esyaYat(Tezgah t, Location l, ItemStack esya) {
        l.setYaw(t.yaw);
        l.setPitch(0);
        ItemStack tek = esya.clone();
        tek.setAmount(1);
        ItemDisplay id = l.getWorld().spawn(l, ItemDisplay.class, d -> {
            d.setItemStack(tek);
            d.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
            d.setTransformation(new Transformation(new Vector3f(),
                    new AxisAngle4f((float) Math.toRadians(-90), 1f, 0f, 0f),
                    new Vector3f(0.4f, 0.4f, 0.4f), new AxisAngle4f()));
            ortak(d);
        });
        t.varliklar.add(id.getUniqueId());
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void ortak(Display d) {
        d.setPersistent(false);
        d.setInvulnerable(true);
        d.addScoreboardTag(ETIKET);
        d.setBrightness(new Display.Brightness(15, 15));
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void blok(Tezgah t, Location l, Material m, float tx, float ty, float tz, float sx, float sy, float sz) {
        l.setYaw(t.yaw);
        l.setPitch(0);
        BlockDisplay bd = l.getWorld().spawn(l, BlockDisplay.class, d -> {
            d.setBlock(m.createBlockData());
            d.setTransformation(new Transformation(new Vector3f(tx, ty, tz), new AxisAngle4f(),
                    new Vector3f(sx, sy, sz), new AxisAngle4f()));
            ortak(d);
        });
        t.varliklar.add(bd.getUniqueId());
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private UUID yazi(Tezgah t, Location l, Component metin, float olcek) {
        l.setYaw(t.yaw);
        l.setPitch(0);
        TextDisplay td = l.getWorld().spawn(l, TextDisplay.class, d -> {
            d.text(metin);
            d.setBillboard(Display.Billboard.CENTER);
            d.setBackgroundColor(Color.fromARGB(0, 0, 0, 0));
            d.setShadowed(true);
            d.setTransformation(new Transformation(new Vector3f(), new AxisAngle4f(),
                    new Vector3f(olcek, olcek, olcek), new AxisAngle4f()));
            ortak(d);
        });
        t.varliklar.add(td.getUniqueId());
        return td.getUniqueId();
    }

    // ------------------------------------------------------------ tiklama / satin alma

    @EventHandler(priority = EventPriority.HIGH)
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void sagTik(PlayerInteractEntityEvent e) {
        Hedef h = hedefler.get(e.getRightClicked().getUniqueId());
        if (h == null) {
            return;
        }
        e.setCancelled(true);
        if (e.getHand() != EquipmentSlot.HAND) {
            return;
        }
        tikla(e.getPlayer(), h);
    }

    @EventHandler(priority = EventPriority.HIGH)
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void solTik(EntityDamageByEntityEvent e) {
        Hedef h = hedefler.get(e.getEntity().getUniqueId());
        if (h == null) {
            return;
        }
        e.setCancelled(true);
        if (e.getDamager() instanceof Player p) {
            tikla(p, h);
        }
    }

    private void tikla(Player p, Hedef h) {
        long simdi = System.currentTimeMillis();
        Long son = sonTik.get(p.getUniqueId());
        if (son != null && simdi - son < 250) {
            return;
        }
        sonTik.put(p.getUniqueId(), simdi);

        Tezgah t = tezgahlar.get(h.sahip());
        if (t == null) {
            return;
        }
        Esya es = t.slot[h.slot()];
        if (es == null) {
            return;
        }
        if (p.getUniqueId().equals(t.sahip)) {
            if (p.isSneaking()) {
                t.slot[h.slot()] = null;
                if (es.alim()) {
                    eklenti.paraEkle(p.getUniqueId(), es.fiyat());
                    msj(p, "&7Alım isteği kaldırıldı, &e" + eklenti.bicim(es.fiyat()) + " &7iade edildi.");
                } else {
                    eklenti.esyaVer(p, es.esya().clone());
                    msj(p, "&7Eşya pazardan geri alındı.");
                }
                kaydet();
                kur(t);
            } else {
                msj(p, "&7Bu senin pazarın. Geri almak için &fçömelip tıkla&7, hepsini kapatmak için &f/ah clear");
            }
            return;
        }
        Onay o = onaylar.get(p.getUniqueId());
        if (o != null && o.esya() == es && o.sahip().equals(t.sahip) && o.slot() == h.slot() && simdi <= o.bitis()) {
            onaylar.remove(p.getUniqueId());
            if (es.alim()) {
                alimaSat(p, t, h.slot(), es);
            } else {
                satinAl(p, t, h.slot(), es);
            }
            return;
        }
        onaylar.put(p.getUniqueId(), new Onay(t.sahip, h.slot(), es, simdi + 6000));
        if (es.alim()) {
            p.sendActionBar(c("&aALIM: &e" + eklenti.isim(es.esya()) + " &7x" + es.esya().getAmount()
                    + " &8- &a+" + eklenti.bicim(es.fiyat()) + " &8| &feşyanı satmak için tekrar tıkla"));
        } else {
            p.sendActionBar(c("&e" + eklenti.isim(es.esya()) + " &7x" + es.esya().getAmount() + " &8- &a"
                    + eklenti.bicim(es.fiyat()) + " &8| &fsatın almak için tekrar tıkla"));
        }
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void satinAl(Player p, Tezgah t, int slot, Esya es) {
        if (t.slot[slot] != es) {
            msj(p, "&cBu eşya artık satışta değil.");
            return;
        }
        if (!eklenti.cek(p.getUniqueId(), es.fiyat())) {
            msj(p, "&cYetersiz bakiye. &7Gerekli: &e" + eklenti.bicim(es.fiyat()));
            return;
        }
        t.slot[slot] = null;
        double komisyon = eklenti.getConfig().getDouble("pazar.komisyon", 5.0);
        double net = Ekonomi.yuvarla(es.fiyat() * (1.0 - Math.max(0, Math.min(100, komisyon)) / 100.0));
        eklenti.paraEkle(t.sahip, net);
        eklenti.esyaVer(p, es.esya().clone());
        kaydet();
        kur(t);
        msj(p, "&a" + eklenti.isim(es.esya()) + " &7x" + es.esya().getAmount() + " &asatın alındı: &e"
                + eklenti.bicim(es.fiyat()));
        Player satici = Bukkit.getPlayer(t.sahip);
        if (satici != null) {
            msj(satici, "&f" + p.getName() + " &7pazarından &a" + eklenti.isim(es.esya()) + " &7x"
                    + es.esya().getAmount() + " &7aldı. &a+" + eklenti.bicim(net));
        }
    }

    /** Alim istegine esya satar: ayni esyadan (ayni ozellikler) istenen adet envanterde olmali. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void alimaSat(Player p, Tezgah t, int slot, Esya es) {
        if (t.slot[slot] != es) {
            msj(p, "&cBu alım isteği artık geçerli değil.");
            return;
        }
        ItemStack sablon = es.esya();
        int gereken = sablon.getAmount();
        int var = 0;
        for (ItemStack s : p.getInventory().getStorageContents()) {
            if (s != null && s.isSimilar(sablon)) {
                var += s.getAmount();
            }
        }
        if (var < gereken) {
            msj(p, "&cEnvanterinde yeterli yok. &7Gerekli: &f" + eklenti.isim(sablon) + " &7x" + gereken
                    + " &8(sende " + var + ")");
            return;
        }
        ItemStack al = sablon.clone();
        al.setAmount(gereken);
        if (!p.getInventory().removeItem(al).isEmpty()) {
            msj(p, "&cEşya alınamadı.");
            return;
        }
        t.slot[slot] = null;
        double komisyon = eklenti.getConfig().getDouble("pazar.komisyon", 5.0);
        double net = Ekonomi.yuvarla(es.fiyat() * (1.0 - Math.max(0, Math.min(100, komisyon)) / 100.0));
        eklenti.paraEkle(p.getUniqueId(), net);
        eklenti.esyaVerOfflineDahil(t.sahip, al.clone());
        kaydet();
        kur(t);
        msj(p, "&a" + eklenti.isim(sablon) + " &7x" + gereken + " &asatıldı: &e+" + eklenti.bicim(net));
        Player alici = Bukkit.getPlayer(t.sahip);
        if (alici != null) {
            msj(alici, "&f" + p.getName() + " &7alım isteğine &a" + eklenti.isim(sablon) + " &7x" + gereken
                    + " &7sattı. Eşya envanterinde.");
        }
    }

    // ------------------------------------------------------------ menu (/ah pazarlar)

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static final class Menu implements InventoryHolder {
        Inventory env;
        boolean liste;
        boolean tum;
        final Map<Integer, Hedef> hedefler = new HashMap<>();
        int sayfa;
        UUID sahip;
        final List<UUID> sahipler = new ArrayList<>();

        @Override
        public Inventory getInventory() {
            return env;
        }
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    int acikSayisi() {
        return tezgahlar.size();
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    boolean pazariVar(UUID kimlik) {
        return tezgahlar.containsKey(kimlik);
    }

    /** Acik tum pazarlarin listesi (sayfali). */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    void pazarlarMenu(Player p, int sayfa) {
        List<Tezgah> hepsi = new ArrayList<>(tezgahlar.values());
        if (hepsi.isEmpty()) {
            msj(p, "&7Şu an açık pazar yok.");
            return;
        }
        int sayfaSayisi = Math.max(1, (hepsi.size() + 44) / 45);
        sayfa = Math.max(0, Math.min(sayfa, sayfaSayisi - 1));
        Menu m = new Menu();
        m.liste = true;
        m.sayfa = sayfa;
        m.env = Bukkit.createInventory(m, 54, c("&6Pazarlar &8(" + (sayfa + 1) + "/" + sayfaSayisi + ")"));
        for (int i = sayfa * 45; i < Math.min(hepsi.size(), sayfa * 45 + 45); i++) {
            Tezgah t = hepsi.get(i);
            int sat = 0;
            int al = 0;
            for (Esya e : t.slot) {
                if (e != null) {
                    if (e.alim()) {
                        al++;
                    } else {
                        sat++;
                    }
                }
            }
            ItemStack bas = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta sm = (SkullMeta) bas.getItemMeta();
            sm.setOwningPlayer(Bukkit.getOfflinePlayer(t.sahip));
            String ad = Bukkit.getOfflinePlayer(t.sahip).getName();
            sm.displayName(c("&6" + (ad != null ? ad : "?") + " &eMerchant"));
            sm.lore(List.of(c("&7Satışta: &a" + sat + " &8| &7Alım isteği: &b" + al),
                    c("&7Kalan süre: &f" + sureYazi(t.bitis - System.currentTimeMillis())),
                    c("&7Konum: &f" + t.dunya + " " + (int) t.x + " " + (int) t.y + " " + (int) t.z),
                    c("&eİncelemek için tıkla")));
            bas.setItemMeta(sm);
            m.env.setItem(i - sayfa * 45, bas);
            m.sahipler.add(t.sahip);
        }
        if (sayfa > 0) {
            m.env.setItem(48, duzEsya(Material.ARROW, "&e« Önceki sayfa"));
        }
        if (sayfa < sayfaSayisi - 1) {
            m.env.setItem(50, duzEsya(Material.ARROW, "&eSonraki sayfa »"));
        }
        p.openInventory(m.env);
    }

// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    /** /ah ana menusu: tum acik pazarlardaki esyalar (satis + alim istegi) tek listede. */
    void esyaListesi(Player p, int sayfa) {
        List<Hedef> hs = new ArrayList<>();
        for (Tezgah t : tezgahlar.values()) {
            for (int i = 0; i < TOPLAM_SLOT; i++) {
                if (t.slot[i] != null) {
                    hs.add(new Hedef(t.sahip, i));
                }
            }
        }
        int sayfaSayisi = Math.max(1, (hs.size() + 44) / 45);
        sayfa = Math.max(0, Math.min(sayfa, sayfaSayisi - 1));
        Menu m = new Menu();
        m.tum = true;
        m.sayfa = sayfa;
        m.env = Bukkit.createInventory(m, 54, c("&0&lAH &8- Pazar eşyaları (" + (sayfa + 1) + "/" + sayfaSayisi + ")"));
        for (int k = sayfa * 45; k < Math.min(hs.size(), sayfa * 45 + 45); k++) {
            Hedef h = hs.get(k);
            Tezgah t = tezgahlar.get(h.sahip());
            Esya e = t.slot[h.slot()];
            ItemStack g = e.esya().clone();
            ItemMeta meta = g.getItemMeta();
            List<Component> lore = meta.lore() != null ? new ArrayList<>(meta.lore()) : new ArrayList<>();
            String ad = Bukkit.getOfflinePlayer(t.sahip).getName();
            lore.add(c("&8&m                    "));
            lore.add(c("&7Satıcı: &f" + (ad != null ? ad : "?")));
            if (e.alim()) {
                lore.add(c("&b&lALIM İSTEĞİ &7- karşılığı: &a+" + eklenti.bicim(e.fiyat())));
                lore.add(c("&eEşyayı satmak için 2 kez tıkla"));
            } else {
                lore.add(c("&7Fiyat: &e" + eklenti.bicim(e.fiyat())));
                lore.add(c("&eSatın almak için 2 kez tıkla"));
            }
            lore.add(c("&7Konum: &f" + t.dunya + " " + (int) t.x + " " + (int) t.y + " " + (int) t.z));
            lore.add(c("&7Kalan süre: &f" + sureYazi(t.bitis - System.currentTimeMillis())));
            meta.lore(lore);
            g.setItemMeta(meta);
            int ek = k - sayfa * 45;
            m.env.setItem(ek, g);
            m.hedefler.put(ek, h);
        }
        if (sayfa > 0) {
            m.env.setItem(45, duzEsya(Material.ARROW, "&e« Önceki sayfa"));
        }
        if (sayfa < sayfaSayisi - 1) {
            m.env.setItem(53, duzEsya(Material.ARROW, "&eSonraki sayfa »"));
        }
        m.env.setItem(46, duzEsya(Material.OAK_SIGN, "&6Pazarlar &7(" + tezgahlar.size() + " açık)"));
        m.env.setItem(47, duzEsya(Material.WRITABLE_BOOK, "&eAçık artırmalar"));
        m.env.setItem(48, duzEsya(Material.BARREL, pazariVar(p.getUniqueId())
                ? "&aPazarım &7(açmak için tıkla)" : "&7Pazarım yok &8(/ah sell <fiyat>)"));
        m.env.setItem(49, duzEsya(Material.GOLD_INGOT, "&6Bakiyen: &a" + eklenti.bicim(eklenti.bakiye(p.getUniqueId()))));
        m.env.setItem(51, duzEsya(Material.CHEST, "&ePosta kutusu &7(/ahbox)"));
        p.openInventory(m.env);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static final int[] MENU_SLOTLAR = {10, 11, 12, 13, 14, 15, 19, 20, 21, 22, 23, 24};

    /** Tek bir pazarin icindekiler; tiklayinca satin alma / alim istegine satis. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    void pazarMenusu(Player p, UUID sahip) {
        Tezgah t = tezgahlar.get(sahip);
        if (t == null) {
            pazarlarMenu(p, 0);
            return;
        }
        Menu m = new Menu();
        m.sahip = sahip;
        String ad = Bukkit.getOfflinePlayer(sahip).getName();
        m.env = Bukkit.createInventory(m, 36, c("&6" + (ad != null ? ad : "?") + " &8- Merchant"));
        for (int i = 0; i < TOPLAM_SLOT; i++) {
            Esya e = t.slot[i];
            if (e == null) {
                continue;
            }
            ItemStack g = e.esya().clone();
            ItemMeta meta = g.getItemMeta();
            List<Component> lore = meta.lore() != null ? new ArrayList<>(meta.lore()) : new ArrayList<>();
            lore.add(Component.empty());
            if (e.alim()) {
                lore.add(c("&b&lALIM İSTEĞİ"));
                lore.add(c("&7Karşılığında: &a+" + eklenti.bicim(e.fiyat())));
                lore.add(c("&eEşyayı satmak için 2 kez tıkla"));
            } else {
                lore.add(c("&7Fiyat: &e" + eklenti.bicim(e.fiyat())));
                lore.add(c("&eSatın almak için 2 kez tıkla"));
            }
            meta.lore(lore);
            g.setItemMeta(meta);
            m.env.setItem(MENU_SLOTLAR[i], g);
        }
        m.env.setItem(31, duzEsya(Material.BARRIER, "&c« Pazar listesi"));
        m.env.setItem(35, duzEsya(Material.CLOCK, "&7Kalan süre: &f" + sureYazi(t.bitis - System.currentTimeMillis())));
        p.openInventory(m.env);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private ItemStack duzEsya(Material m, String ad) {
        ItemStack i = new ItemStack(m);
        ItemMeta meta = i.getItemMeta();
        meta.displayName(c(ad));
        i.setItemMeta(meta);
        return i;
    }

    @EventHandler
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void menuTik(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Menu m)) {
            return;
        }
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p) || e.getClickedInventory() != e.getView().getTopInventory()) {
            return;
        }
        int slot = e.getSlot();
        if (m.tum) {
            if (slot == 45 && m.sayfa > 0) {
                esyaListesi(p, m.sayfa - 1);
            } else if (slot == 53) {
                esyaListesi(p, m.sayfa + 1);
            } else if (slot == 46) {
                pazarlarMenu(p, 0);
            } else if (slot == 47) {
                eklenti.acikArtirmaMenu(p);
            } else if (slot == 48) {
                if (pazariVar(p.getUniqueId())) {
                    pazarMenusu(p, p.getUniqueId());
                } else {
                    msj(p, "&7Pazarın yok. Elindeki eşyayla: &f/ah sell <fiyat>");
                }
            } else if (slot == 51) {
                eklenti.postaKutusu(p);
            } else if (m.hedefler.containsKey(slot)) {
                tikla(p, m.hedefler.get(slot));
                Bukkit.getScheduler().runTask(eklenti, () -> {
                    if (p.isOnline() && p.getOpenInventory().getTopInventory().getHolder() instanceof Menu mm && mm.tum) {
                        esyaListesi(p, m.sayfa);
                    }
                });
            }
            return;
        }
        if (m.liste) {
            if (slot == 48 && m.sayfa > 0) {
                pazarlarMenu(p, m.sayfa - 1);
            } else if (slot == 50) {
                pazarlarMenu(p, m.sayfa + 1);
            } else if (slot >= 0 && slot < 45 && slot < m.sahipler.size()) {
                pazarMenusu(p, m.sahipler.get(slot));
            }
            return;
        }
        if (slot == 31) {
            pazarlarMenu(p, 0);
            return;
        }
        for (int i = 0; i < MENU_SLOTLAR.length; i++) {
            if (MENU_SLOTLAR[i] == slot) {
                tikla(p, new Hedef(m.sahip, i));
                Bukkit.getScheduler().runTask(eklenti, () -> {
                    if (p.isOnline() && p.getOpenInventory().getTopInventory().getHolder() instanceof Menu) {
                        pazarMenusu(p, m.sahip);
                    }
                });
                return;
            }
        }
    }

    @EventHandler
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void menuSurukle(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Menu) {
            e.setCancelled(true);
        }
    }
}
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
