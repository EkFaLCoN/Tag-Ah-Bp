/*
 * © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR.
 * Bu kodun izinsiz kopyalanması, dağıtılması veya değiştirilmesi yasaktır.
 */
package net.mrwqlf.marketah;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Basit, dosya tabanli para sistemi. Vault/Essentials gerektirmez. */
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
public final class Ekonomi {

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static final DecimalFormat FMT =
            new DecimalFormat("#,##0.##", new DecimalFormatSymbols(Locale.forLanguageTag("tr-TR")));

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final MarketAH plugin;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final File file;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Map<UUID, Double> bakiye = new HashMap<>();
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private double baslangic;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private String birim;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private boolean kisalt = true;

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public Ekonomi(MarketAH plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "bakiye.yml");
        yukle();
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void yukle() {
        baslangic = plugin.getConfig().getDouble("baslangic-bakiye", 500.0);
        birim = plugin.getConfig().getString("para-birimi", "TL");
        kisalt = plugin.getConfig().getBoolean("para-kisaltma", true);
        bakiye.clear();
        if (!file.exists()) return;
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        for (String key : cfg.getKeys(false)) {
            try {
                bakiye.put(UUID.fromString(key), cfg.getDouble(key));
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void kaydet() {
        FileConfiguration cfg = new YamlConfiguration();
        for (Map.Entry<UUID, Double> e : bakiye.entrySet()) {
            cfg.set(e.getKey().toString(), e.getValue());
        }
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            cfg.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("bakiye.yml kaydedilemedi: " + ex.getMessage());
        }
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public String birim() {
        return birim;
    }

    /** 9b TL, 12,5m TL gibi kisaltilmis gosterim (k, m, b, t, q). config: para-kisaltma (varsayilan acik). */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public String bicim(double miktar) {
        if (!kisalt || !Double.isFinite(miktar)) return FMT.format(miktar) + " " + birim;
        double a = Math.abs(miktar);
        double v;
        String ek;
        if (a >= 1e15) { v = miktar / 1e15; ek = "q"; }
        else if (a >= 1e12) { v = miktar / 1e12; ek = "t"; }
        else if (a >= 1e9) { v = miktar / 1e9; ek = "b"; }
        else if (a >= 1e6) { v = miktar / 1e6; ek = "m"; }
        else if (a >= 1e4) { v = miktar / 1e3; ek = "k"; }
        else return FMT.format(miktar) + " " + birim;
        v = Math.floor(v * 100.0) / 100.0;
        return FMT.format(v) + ek + " " + birim;
    }

    /** Tam sayi (kisaltmasiz) gosterim. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public String tam(double miktar) {
        return FMT.format(miktar) + " " + birim;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public double bakiye(UUID uuid) {
        return bakiye.computeIfAbsent(uuid, k -> baslangic);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void ayarla(UUID uuid, double miktar) {
        if (!Double.isFinite(miktar)) return;          // NaN / sonsuz bakiyeyi bozamaz
        bakiye.put(uuid, Math.max(0, yuvarla(miktar)));
    }

    /** Para ekler. Miktar once kurusa yuvarlanir (0.005 gibi degerlerle para uretilemez). */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void ekle(UUID uuid, double miktar) {
        if (!Double.isFinite(miktar)) return;
        miktar = yuvarla(miktar);
        if (miktar <= 0) return;
        ayarla(uuid, bakiye(uuid) + miktar);
    }

    /** Yeterli para varsa duser ve true doner. Gecersiz (NaN/sonsuz/negatif) miktar reddedilir. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public boolean cek(UUID uuid, double miktar) {
        if (!Double.isFinite(miktar)) return false;
        miktar = yuvarla(miktar);
        if (miktar < 0) return false;
        if (miktar == 0) return true;
        double mevcut = bakiye(uuid);
        if (mevcut + 0.0001 < miktar) return false;
        ayarla(uuid, mevcut - miktar);
        return true;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public static double yuvarla(double d) {
        return Math.round(d * 100.0) / 100.0;
    }
}
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
