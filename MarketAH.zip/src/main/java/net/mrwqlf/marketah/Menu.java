/*
 * © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR.
 * Bu kodun izinsiz kopyalanması, dağıtılması veya değiştirilmesi yasaktır.
 */
package net.mrwqlf.marketah;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Acik menuyu tanimak icin kullanilan holder. */
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
public final class Menu implements InventoryHolder {

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public enum Tip { MARKET, ILANLARIM, KUTU }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public final Tip tip;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public int sayfa;
    /** slot -> ilan id (MARKET/ILANLARIM) */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public final Map<Integer, UUID> slotIlan = new HashMap<>();
    /** slot -> kutu index (KUTU) */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public final Map<Integer, Integer> slotKutu = new HashMap<>();

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private Inventory inv;

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public Menu(Tip tip, int sayfa) {
        this.tip = tip;
        this.sayfa = sayfa;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void setInventory(Inventory inv) {
        this.inv = inv;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    @Override
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public @NotNull Inventory getInventory() {
        return inv;
    }
}
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
