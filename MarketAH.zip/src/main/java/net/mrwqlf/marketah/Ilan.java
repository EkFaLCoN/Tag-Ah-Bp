/*
 * © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR.
 * Bu kodun izinsiz kopyalanması, dağıtılması veya değiştirilmesi yasaktır.
 */
package net.mrwqlf.marketah;

import org.bukkit.inventory.ItemStack;

import java.util.Base64;
import java.util.UUID;

/** Tek bir market ilani. Hem sabit fiyatli hem acik artirma olabilir. */
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
public final class Ilan {

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public final UUID id;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public final UUID satici;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public final String saticiAdi;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public final byte[] esya;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public final boolean acikArtirma;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public final long olusturma;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public final long bitis;          // 0 = suresiz

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public double fiyat;              // sabit fiyat veya guncel teklif
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public UUID enYuksek;             // acik artirmada en yuksek teklif sahibi
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public String enYuksekAdi;

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public Ilan(UUID id, UUID satici, String saticiAdi, byte[] esya, boolean acikArtirma,
                double fiyat, long olusturma, long bitis) {
        this.id = id;
        this.satici = satici;
        this.saticiAdi = saticiAdi;
        this.esya = esya;
        this.acikArtirma = acikArtirma;
        this.fiyat = fiyat;
        this.olusturma = olusturma;
        this.bitis = bitis;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public ItemStack item() {
        return ItemStack.deserializeBytes(esya);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public String esyaBase64() {
        return Base64.getEncoder().encodeToString(esya);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public static byte[] cozB64(String s) {
        return Base64.getDecoder().decode(s);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public boolean suresiDoldu(long simdi) {
        return bitis > 0 && simdi >= bitis;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public boolean teklifVar() {
        return enYuksek != null;
    }

    /** Kalan sureyi "2s 14dk" seklinde dondurur. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public String kalanSure(long simdi) {
        if (bitis <= 0) return "suresiz";
        long kalan = bitis - simdi;
        if (kalan <= 0) return "bitti";
        long saat = kalan / 3600000L;
        long dk = (kalan % 3600000L) / 60000L;
        if (saat > 0) return saat + "s " + dk + "dk";
        long sn = (kalan % 60000L) / 1000L;
        return dk + "dk " + sn + "sn";
    }
}
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
