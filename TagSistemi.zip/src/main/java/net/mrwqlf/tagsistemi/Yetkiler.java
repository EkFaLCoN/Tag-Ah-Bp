package net.mrwqlf.tagsistemi;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.permissions.PermissionAttachment;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;

/**
 * Rutbeye komut/izin yetkisi baglama. Her rutbenin bir izin listesi vardir; oyuncunun gecerli
 * rutbesi degisince (verme, alma, sure bitisi, giris/cikis) izinler PermissionAttachment ile uygulanir.
 */
public final class Yetkiler {

    private final TagSistemi pl;
    private final File dosya;
    /** rutbe -> izin dugumleri */
    private final Map<String, Set<String>> izinler = new TreeMap<>();
    private final Map<UUID, PermissionAttachment> ekler = new HashMap<>();

    public Yetkiler(TagSistemi pl) {
        this.pl = pl;
        this.dosya = new File(pl.getDataFolder(), "yetkiler.yml");
        yukle();
    }

    public void yukle() {
        izinler.clear();
        if (!dosya.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dosya);
        var sec = y.getConfigurationSection("rutbeler");
        if (sec == null) return;
        for (String k : sec.getKeys(false)) {
            List<String> l = sec.getStringList(k);
            if (!l.isEmpty()) izinler.put(k.toLowerCase(Locale.ROOT), new LinkedHashSet<>(l));
        }
    }

    public void kaydet() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<String, Set<String>> e : izinler.entrySet()) {
            y.set("rutbeler." + e.getKey(), new ArrayList<>(e.getValue()));
        }
        try {
            pl.getDataFolder().mkdirs();
            y.save(dosya);
        } catch (IOException ex) {
            pl.getLogger().warning("yetkiler.yml kaydedilemedi: " + ex.getMessage());
        }
    }

    public Set<String> liste(String rutbe) {
        return izinler.getOrDefault(rutbe.toLowerCase(Locale.ROOT), Set.of());
    }

    public void ekle(String rutbe, Set<String> dugumler) {
        izinler.computeIfAbsent(rutbe.toLowerCase(Locale.ROOT), k -> new LinkedHashSet<>()).addAll(dugumler);
    }

    /** @return gercekten silinen dugum sayisi */
    public int sil(String rutbe, Set<String> dugumler) {
        Set<String> s = izinler.get(rutbe.toLowerCase(Locale.ROOT));
        if (s == null) return 0;
        int n = 0;
        for (String d : dugumler) if (s.remove(d)) n++;
        if (s.isEmpty()) izinler.remove(rutbe.toLowerCase(Locale.ROOT));
        return n;
    }

    public void rutbeSil(String rutbe) {
        izinler.remove(rutbe.toLowerCase(Locale.ROOT));
    }

    /**
     * Girdiyi izin dugumlerine cevirir. "/gamemode", "gamemode" gibi bir komut adi ise komutun kendi
     * izni, nokta iceren bir dugum ise aynen kullanilir. Bos donerse komut herkese aciktir/bulunamadi.
     */
    public Set<String> coz(String girdi, List<String> bilgi) {
        Set<String> r = new LinkedHashSet<>();
        String g = girdi.startsWith("/") ? girdi.substring(1) : girdi;
        g = g.toLowerCase(Locale.ROOT);
        Command c = Bukkit.getCommandMap().getCommand(g);
        if (c != null) {
            String p = c.getPermission();
            if (p == null || p.isBlank()) {
                bilgi.add("&7/" + g + " &7zaten herkese açık (yetki istemiyor).");
            } else {
                for (String x : p.split(";")) if (!x.isBlank()) r.add(x.trim());
            }
            return r;
        }
        if (g.contains(".")) {
            r.add(g);
            return r;
        }
        bilgi.add("&c'" + girdi + "' diye bir komut bulunamadı. &7İzin düğümü yazmak için nokta kullan (örn. plugin.izin).");
        return r;
    }

    // ---------------------------------------------------------------- uygulama

    public void uygula(Player p) {
        kaldir(p);
        String rutbe = pl.rutbeAdi(p.getUniqueId());
        if (rutbe == null) return;
        Set<String> s = izinler.get(rutbe);
        if (s == null || s.isEmpty()) return;
        PermissionAttachment a = p.addAttachment(pl);
        for (String d : s) a.setPermission(d, true);
        ekler.put(p.getUniqueId(), a);
        p.recalculatePermissions();
        p.updateCommands();
    }

    public void kaldir(Player p) {
        PermissionAttachment a = ekler.remove(p.getUniqueId());
        if (a == null) return;
        try {
            p.removeAttachment(a);
        } catch (IllegalArgumentException ignored) {
        }
        p.recalculatePermissions();
        p.updateCommands();
    }

    public void hepsiniUygula() {
        for (Player p : Bukkit.getOnlinePlayers()) uygula(p);
    }

    public void hepsiniKaldir() {
        for (Player p : new ArrayList<>(Bukkit.getOnlinePlayers())) kaldir(p);
    }
}
