/*
 * © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR.
 * Bu kodun izinsiz kopyalanması, dağıtılması veya değiştirilmesi yasaktır.
 */
package net.mrwqlf.tagsistemi;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Rutbe kitleri ve oyuncularin son kit alma zamani (kitler.yml). */
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
public final class Kitler {

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final TagSistemi plugin;
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final File dosya;

    /** rutbe adi -> kit esyalari (bayt olarak) */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Map<String, List<byte[]>> kitler = new HashMap<>();
    /** oyuncu -> (rutbe adi -> son alim zamani) */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Map<UUID, Map<String, Long>> sonAlim = new HashMap<>();

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public Kitler(TagSistemi plugin) {
        this.plugin = plugin;
        this.dosya = new File(plugin.getDataFolder(), "kitler.yml");
        yukle();
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void yukle() {
        kitler.clear();
        sonAlim.clear();
        if (!dosya.exists()) return;
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(dosya);

        ConfigurationSection ks = cfg.getConfigurationSection("kitler");
        if (ks != null) {
            for (String rutbe : ks.getKeys(false)) {
                List<byte[]> liste = new ArrayList<>();
                for (String b64 : ks.getStringList(rutbe)) {
                    try {
                        liste.add(Base64.getDecoder().decode(b64));
                    } catch (IllegalArgumentException ex) {
                        plugin.getLogger().warning("Bozuk kit eşyası atlandı: " + rutbe);
                    }
                }
                kitler.put(rutbe.toLowerCase(), liste);
            }
        }

        ConfigurationSection ss = cfg.getConfigurationSection("son-alim");
        if (ss != null) {
            for (String u : ss.getKeys(false)) {
                try {
                    UUID id = UUID.fromString(u);
                    ConfigurationSection os = ss.getConfigurationSection(u);
                    if (os == null) continue;
                    Map<String, Long> m = new HashMap<>();
                    for (String r : os.getKeys(false)) m.put(r.toLowerCase(), os.getLong(r));
                    sonAlim.put(id, m);
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void kaydet() {
        FileConfiguration cfg = new YamlConfiguration();
        for (Map.Entry<String, List<byte[]>> e : kitler.entrySet()) {
            List<String> l = new ArrayList<>();
            for (byte[] b : e.getValue()) l.add(Base64.getEncoder().encodeToString(b));
            cfg.set("kitler." + e.getKey(), l);
        }
        for (Map.Entry<UUID, Map<String, Long>> e : sonAlim.entrySet()) {
            for (Map.Entry<String, Long> r : e.getValue().entrySet()) {
                cfg.set("son-alim." + e.getKey() + "." + r.getKey(), r.getValue());
            }
        }
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            cfg.save(dosya);
        } catch (IOException ex) {
            plugin.getLogger().warning("kitler.yml kaydedilemedi: " + ex.getMessage());
        }
    }

    // ---------------------------------------------------------------- kit

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public boolean var(String rutbe) {
        List<byte[]> l = kitler.get(rutbe.toLowerCase());
        return l != null && !l.isEmpty();
    }

    /** Rutbenin kitini yeni esyalarla degistirir. Bos esyalar atlanir. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public int kaydetKit(String rutbe, ItemStack[] esyalar) {
        List<byte[]> liste = new ArrayList<>();
        for (ItemStack it : esyalar) {
            if (it == null || it.getType().isAir()) continue;
            liste.add(it.serializeAsBytes());
        }
        if (liste.isEmpty()) return 0;
        kitler.put(rutbe.toLowerCase(), liste);
        kaydet();
        return liste.size();
    }

    /** Kitin esyalarinin KOPYALARI (her cagrida yeni nesneler). */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public List<ItemStack> esyalar(String rutbe) {
        List<ItemStack> sonuc = new ArrayList<>();
        List<byte[]> l = kitler.get(rutbe.toLowerCase());
        if (l == null) return sonuc;
        for (byte[] b : l) {
            try {
                sonuc.add(ItemStack.deserializeBytes(b));
            } catch (Exception ex) {
                plugin.getLogger().warning("Kit eşyası okunamadı (" + rutbe + "): " + ex.getMessage());
            }
        }
        return sonuc;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void kitSil(String rutbe) {
        String k = rutbe.toLowerCase();
        kitler.remove(k);
        for (Map<String, Long> m : sonAlim.values()) m.remove(k);
    }

    // ---------------------------------------------------------------- bekleme

    /** Oyuncunun bu kiti en son aldigi zaman; hic almadiysa 0. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public long sonAlim(UUID uuid, String rutbe) {
        Map<String, Long> m = sonAlim.get(uuid);
        if (m == null) return 0L;
        return m.getOrDefault(rutbe.toLowerCase(), 0L);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void alimKaydet(UUID uuid, String rutbe, long zaman) {
        sonAlim.computeIfAbsent(uuid, k -> new HashMap<>()).put(rutbe.toLowerCase(), zaman);
    }

    /** Kalan bekleme (ms); hazirsa 0. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public long kalanBekleme(UUID uuid, String rutbe, long beklemeMs) {
        long son = sonAlim(uuid, rutbe);
        if (son <= 0) return 0L;
        return Math.max(0L, son + beklemeMs - System.currentTimeMillis());
    }
}
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
