/*
 * © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR.
 * Bu kodun izinsiz kopyalanması, dağıtılması veya değiştirilmesi yasaktır.
 */
package net.mrwqlf.tagsistemi;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

/** Kit menusunu taniyan envanter sahibi. */
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
public final class KitMenu implements InventoryHolder {

    /** Menu hangi rutbenin kitini gosteriyor */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public final String rutbe;
    /** true = sadece onizleme (alma dugmesi yok) */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public final boolean onizleme;

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private Inventory inv;

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public KitMenu(String rutbe, boolean onizleme) {
        this.rutbe = rutbe;
        this.onizleme = onizleme;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void setInventory(Inventory inv) {
        this.inv = inv;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    @Override
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public @NotNull Inventory getInventory() {
        return inv;
    }
}
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
