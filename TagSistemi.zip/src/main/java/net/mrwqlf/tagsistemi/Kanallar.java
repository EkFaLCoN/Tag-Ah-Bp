/*
 * © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR.
 * Bu kodun izinsiz kopyalanması, dağıtılması veya değiştirilmesi yasaktır.
 */
package net.mrwqlf.tagsistemi;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Sohbet kanallari: GENEL, TICARET, PARTI, GLOBAL.
 * /ticaretc, /partyc, /genelc, /globalc ile kanal degistirilir.
 * GLOBAL kanalina yalnizca yetkililer yazabilir; her kanalda [GLOBAL] etiketiyle gorunur.
 * PARTI kanali PartySistemi'ne yansima ile baglanir (yumusak bagimlilik).
 */
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
final class Kanallar {

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    enum Kanal { GENEL, TICARET, PARTI, GLOBAL }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static final String ADMIN = "tagsistemi.admin";
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static final String GLOBAL_YETKI = "tagsistemi.global";

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private final Map<UUID, Kanal> aktif = new HashMap<>();

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static Component c(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s)
                .decoration(TextDecoration.ITALIC, false);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static void msj(CommandSender s, String metin) {
        s.sendMessage(c("&8[&bSohbet&8] &r" + metin));
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    Kanal kanalOf(Player p) {
        return aktif.getOrDefault(p.getUniqueId(), Kanal.GENEL);
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private boolean globalYazabilir(Player p) {
        return p.hasPermission(ADMIN) || p.hasPermission(GLOBAL_YETKI) || p.isOp();
    }

    /** Oyuncunun partisindeki herkes (kendisi dahil); partisi yoksa bos liste. */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private List<UUID> partiUyeleri(UUID kimlik) {
        try {
            Plugin pl = Bukkit.getPluginManager().getPlugin("PartySistemi");
            if (pl == null || !pl.isEnabled()) {
                return List.of();
            }
            Object sonuc = pl.getClass().getMethod("getMembersOf", UUID.class).invoke(pl, kimlik);
            List<UUID> liste = new ArrayList<>();
            if (sonuc instanceof Collection<?> uyeler) {
                for (Object o : uyeler) {
                    if (o instanceof UUID u) {
                        liste.add(u);
                    }
                }
            }
            return liste;
        } catch (ReflectiveOperationException | RuntimeException hata) {
            return List.of();
        }
    }

    // ------------------------------------------------------------ komutlar

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    void komut(CommandSender gonderen, String ad) {
        if (!(gonderen instanceof Player p)) {
            msj(gonderen, "&cBu komut sadece oyuncular için.");
            return;
        }
        switch (ad.toLowerCase()) {
            case "genelc" -> gec(p, Kanal.GENEL);
            case "ticaretc" -> gec(p, Kanal.TICARET);
            case "partyc" -> {
                if (partiUyeleri(p.getUniqueId()).size() < 2) {
                    msj(p, "&cParti sohbeti için bir partide olmalısın. &7(/parti olustur)");
                    return;
                }
                gec(p, Kanal.PARTI);
            }
            case "globalc" -> {
                if (!globalYazabilir(p)) {
                    msj(p, "&cGlobal sohbeti sadece yetkililer kullanabilir.");
                    return;
                }
                gec(p, Kanal.GLOBAL);
            }
            default -> msj(p, "&cBilinmeyen kanal.");
        }
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private void gec(Player p, Kanal kanal) {
        if (kanalOf(p) == kanal) {
            msj(p, "&7Zaten bu kanaldasın.");
            return;
        }
        if (kanal == Kanal.GENEL) {
            aktif.remove(p.getUniqueId());
        } else {
            aktif.put(p.getUniqueId(), kanal);
        }
        String isim = switch (kanal) {
            case GENEL -> "&fGenel";
            case TICARET -> "&6Ticaret";
            case PARTI -> "&aParti";
            case GLOBAL -> "&c&lGlobal";
        };
        msj(p, "&7Sohbet kanalın: " + isim + "&7. &8(/genelc /ticaretc /partyc"
                + (globalYazabilir(p) ? " /globalc" : "") + "&8)");
    }

    // ------------------------------------------------------------ sohbet

    /**
     * Mesajin gorulecegi izleyicileri kanala gore daraltir ve kanali dondurur.
     * Gecersiz kanal (yetki/parti yok) otomatik GENEL'e doner.
     */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    Kanal filtrele(AsyncChatEvent e) {
        Player g = e.getPlayer();
        Kanal k = kanalOf(g);
        Set<UUID> parti = Set.of();
        if (k == Kanal.GLOBAL && !globalYazabilir(g)) {
            k = Kanal.GENEL;
        }
        if (k == Kanal.PARTI) {
            List<UUID> uyeler = partiUyeleri(g.getUniqueId());
            if (uyeler.size() < 2) {
                k = Kanal.GENEL;
            } else {
                parti = new HashSet<>(uyeler);
            }
        }
        if (k == Kanal.GENEL) {
            aktif.remove(g.getUniqueId());
        }
        final Kanal kanal = k;
        final Set<UUID> partiSet = parti;
        e.viewers().removeIf(a -> a instanceof Player v && !goruyor(v, kanal, g, partiSet));
        return k;
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private boolean goruyor(Player izleyen, Kanal kanal, Player gonderen, Set<UUID> parti) {
        if (izleyen.getUniqueId().equals(gonderen.getUniqueId())) {
            return true;
        }
        return switch (kanal) {
            case GLOBAL -> true;
            case PARTI -> parti.contains(izleyen.getUniqueId());
            case TICARET, GENEL -> kanalOf(izleyen) == kanal;
        };
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    Component onek(Kanal k) {
        return switch (k) {
            case GENEL -> Component.empty();
            case TICARET -> c("&8[&6Ticaret&8] ");
            case PARTI -> c("&8[&aParti&8] ");
            case GLOBAL -> c("&8[&c&lGLOBAL&8] ");
        };
    }

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    void cikis(UUID kimlik) {
        aktif.remove(kimlik);
    }
}
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
